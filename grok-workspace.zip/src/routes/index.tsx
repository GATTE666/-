import { createFileRoute } from "@tanstack/react-router";
import { App } from "@/components/jingyun/app";

export const Route = createFileRoute("/")({ component: App });
