import { createFileRoute } from "@tanstack/react-router";
import { assertPublicUrl } from "@/lib/jingyun/upstream.server";

function safeHeaders(input: unknown): Headers {
  const headers = new Headers();
  if (!input || typeof input !== "object") return headers;
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (typeof value !== "string") continue;
    const name = key.toLowerCase();
    if (["host", "content-length", "connection", "transfer-encoding"].includes(name)) continue;
    headers.set(key, value.slice(0, 2000));
  }
  return headers;
}

function parsePayload(text: string): unknown {
  const trimmed = text.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:") || trimmed.includes("\ndata:")) {
    const chunks = trimmed
      .split(/\r?\n/)
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).trim())
      .filter((line) => line && line !== "[DONE]");
    const parsed = chunks
      .map((line) => {
        try {
          return JSON.parse(line) as unknown;
        } catch {
          return null;
        }
      })
      .filter((item) => item !== null);
    return parsed.at(-1) ?? { raw: trimmed.slice(0, 2000) };
  }
  try {
    return JSON.parse(trimmed) as unknown;
  } catch {
    return { raw: trimmed.slice(0, 2000) };
  }
}

export const Route = createFileRoute("/api/mcp")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => null)) as {
          url?: string;
          headers?: Record<string, string>;
          rpc?: unknown;
        } | null;
        if (!body?.url || body.rpc == null) return Response.json({ error: "缺少 MCP 地址或请求" }, { status: 400 });
        let url: URL;
        try {
          url = assertPublicUrl(body.url);
        } catch (err) {
          return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
        }
        const headers = safeHeaders(body.headers);
        if (!headers.has("content-type")) headers.set("content-type", "application/json");
        if (!headers.has("accept")) headers.set("accept", "application/json, text/event-stream");
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 25_000);
        const onAbort = () => controller.abort();
        request.signal.addEventListener("abort", onAbort);
        try {
          const upstream = await fetch(url, {
            method: "POST",
            headers,
            body: JSON.stringify(body.rpc),
            signal: controller.signal,
          });
          const text = (await upstream.text()).slice(0, 200_000);
          return Response.json({
            ok: upstream.ok,
            status: upstream.status,
            json: parsePayload(text),
            error: upstream.ok ? undefined : `MCP 服务返回 ${upstream.status}`,
          });
        } catch (err) {
          const message = controller.signal.aborted ? "MCP 请求超时" : err instanceof Error ? err.message : "MCP 连接失败";
          return Response.json({ ok: false, error: message }, { status: 502 });
        } finally {
          clearTimeout(timer);
          request.signal.removeEventListener("abort", onAbort);
        }
      },
    },
  },
});
