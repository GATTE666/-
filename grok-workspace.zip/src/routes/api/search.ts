import { createFileRoute } from "@tanstack/react-router";
import { assertPublicUrl, errorText } from "@/lib/jingyun/upstream.server";

export type SearchHit = { title: string; url: string; snippet: string; source: string };

function strip(html: string): string {
  return html
    .replace(/<[^>]+>/g, "")
    .replace(/"/g, '"')
    .replace(/&#039;|'/g, "'")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

async function wiki(query: string, signal: AbortSignal): Promise<SearchHit[]> {
  const endpoint = new URL("https://zh.wikipedia.org/w/api.php");
  endpoint.searchParams.set("action", "query");
  endpoint.searchParams.set("list", "search");
  endpoint.searchParams.set("srsearch", query);
  endpoint.searchParams.set("srlimit", "5");
  endpoint.searchParams.set("format", "json");
  endpoint.searchParams.set("utf8", "1");
  const res = await fetch(endpoint, {
    headers: { Accept: "application/json", "User-Agent": "JingYunAI/1.0 (personal research assistant)" },
    signal,
  });
  if (!res.ok) throw new Error(errorText(res.status, await res.text()));
  const json = (await res.json()) as { query?: { search?: { title: string; snippet: string }[] } };
  return (json.query?.search ?? []).map((item) => ({
    title: item.title,
    url: `https://zh.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, "_"))}`,
    snippet: strip(item.snippet),
    source: "维基百科",
  }));
}

async function tavily(query: string, apiKey: string, signal: AbortSignal): Promise<SearchHit[]> {
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ api_key: apiKey, query, max_results: 6, include_answer: false }),
    signal,
  });
  if (!res.ok) throw new Error(errorText(res.status, await res.text()));
  const json = (await res.json()) as { results?: { title?: string; url?: string; content?: string }[] };
  return (json.results ?? []).map((item) => ({
    title: item.title || item.url || "结果",
    url: item.url || "",
    snippet: (item.content || "").slice(0, 360),
    source: "Tavily",
  }));
}

async function brave(query: string, apiKey: string, signal: AbortSignal): Promise<SearchHit[]> {
  const endpoint = new URL("https://api.search.brave.com/res/v1/web/search");
  endpoint.searchParams.set("q", query);
  endpoint.searchParams.set("count", "6");
  const res = await fetch(endpoint, { headers: { Accept: "application/json", "X-Subscription-Token": apiKey }, signal });
  if (!res.ok) throw new Error(errorText(res.status, await res.text()));
  const json = (await res.json()) as { web?: { results?: { title?: string; url?: string; description?: string }[] } };
  return (json.web?.results ?? []).map((item) => ({
    title: item.title || "结果",
    url: item.url || "",
    snippet: item.description || "",
    source: "Brave",
  }));
}

async function serper(query: string, apiKey: string, signal: AbortSignal): Promise<SearchHit[]> {
  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-KEY": apiKey },
    body: JSON.stringify({ q: query, num: 6 }),
    signal,
  });
  if (!res.ok) throw new Error(errorText(res.status, await res.text()));
  const json = (await res.json()) as { organic?: { title?: string; link?: string; snippet?: string }[] };
  return (json.organic ?? []).map((item) => ({
    title: item.title || "结果",
    url: item.link || "",
    snippet: item.snippet || "",
    source: "Serper",
  }));
}

async function custom(query: string, endpoint: string, apiKey: string, signal: AbortSignal): Promise<SearchHit[]> {
  const url = assertPublicUrl(endpoint);
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
    },
    body: JSON.stringify({ query, q: query }),
    signal,
  });
  if (!res.ok) throw new Error(errorText(res.status, await res.text()));
  const json = (await res.json()) as { results?: { title?: string; url?: string; link?: string; snippet?: string; content?: string }[] };
  return (json.results ?? []).map((item) => ({
    title: item.title || item.url || "结果",
    url: item.url || item.link || "",
    snippet: item.snippet || item.content || "",
    source: "自定义搜索",
  }));
}

export const Route = createFileRoute("/api/search")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => null)) as {
          provider?: string;
          query?: string;
          apiKey?: string;
          endpoint?: string;
        } | null;
        const query = body?.query?.trim() ?? "";
        if (!query) return Response.json({ error: "请输入要搜索的内容" }, { status: 400 });
        if (query.length > 300) return Response.json({ error: "搜索词过长" }, { status: 400 });
        try {
          let results: SearchHit[] = [];
          if (body?.provider === "tavily") {
            if (!body.apiKey) return Response.json({ error: "请填写 Tavily API Key" }, { status: 400 });
            results = await tavily(query, body.apiKey, request.signal);
          } else if (body?.provider === "brave") {
            if (!body.apiKey) return Response.json({ error: "请填写 Brave API Key" }, { status: 400 });
            results = await brave(query, body.apiKey, request.signal);
          } else if (body?.provider === "serper") {
            if (!body.apiKey) return Response.json({ error: "请填写 Serper API Key" }, { status: 400 });
            results = await serper(query, body.apiKey, request.signal);
          } else if (body?.provider === "custom") {
            if (!body.endpoint) return Response.json({ error: "请填写自定义搜索地址" }, { status: 400 });
            results = await custom(query, body.endpoint, body.apiKey || "", request.signal);
          } else {
            results = await wiki(query, request.signal);
          }
          return Response.json({ results: results.filter((item) => item.url).slice(0, 8) });
        } catch (err) {
          return Response.json({ error: err instanceof Error ? err.message : "搜索失败" }, { status: 502 });
        }
      },
    },
  },
});
