import { createFileRoute } from "@tanstack/react-router";
import {
  assertPublicUrl,
  builtinKey,
  errorText,
  imageGenerationsUrl,
  postUpstream,
} from "@/lib/jingyun/upstream.server";

export const Route = createFileRoute("/api/ai/image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => null)) as {
          mode?: "builtin" | "proxy";
          baseUrl?: string;
          apiKey?: string;
          model?: string;
          prompt?: string;
        } | null;
        const prompt = body?.prompt?.trim() ?? "";
        if (!prompt) return Response.json({ error: "请先写提示词" }, { status: 400 });
        if (prompt.length > 800) return Response.json({ error: "提示词过长" }, { status: 400 });
        const builtin = body?.mode === "builtin";
        let url = "https://api.x.ai/v1/images/generations";
        let key = builtinKey();
        let model = "grok-imagine-image";
        if (!builtin) {
          if (!body?.baseUrl || !body.apiKey) return Response.json({ error: "缺少绘图接口或密钥" }, { status: 400 });
          url = imageGenerationsUrl(body.baseUrl);
          try {
            assertPublicUrl(url);
          } catch (err) {
            return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
          }
          key = body.apiKey;
          model = (body.model || "dall-e-3").slice(0, 120);
        } else if (!key) {
          return Response.json({ error: "内置绘图不可用，请填写你自己的绘图接口。" }, { status: 503 });
        }
        let upstream: Response;
        try {
          upstream = await postUpstream(
            url,
            key || "",
            { model, prompt, n: 1, response_format: "url" },
            request.signal,
          );
        } catch (err) {
          return Response.json({ error: err instanceof Error ? err.message : "绘图请求失败" }, { status: 502 });
        }
        if (!upstream.ok) {
          const text = await upstream.text();
          return Response.json({ error: errorText(upstream.status, text) }, { status: 502 });
        }
        const json = (await upstream.json()) as { data?: { url?: string; b64_json?: string }[] };
        const images = (json.data ?? [])
          .map((item) => ({ url: item.url || "", b64: item.b64_json || "" }))
          .filter((item) => item.url || item.b64);
        if (!images.length) return Response.json({ error: "接口没有返回图片" }, { status: 502 });
        return Response.json({ images });
      },
    },
  },
});
