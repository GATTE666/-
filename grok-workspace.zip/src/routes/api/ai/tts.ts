import { createFileRoute } from "@tanstack/react-router";
import { builtinKey, errorText } from "@/lib/jingyun/upstream.server";

export const Route = createFileRoute("/api/ai/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => null)) as { text?: string; voice?: string } | null;
        const text = body?.text?.trim() ?? "";
        if (!text) return Response.json({ error: "没有可朗读的文字" }, { status: 400 });
        const key = builtinKey();
        if (!key) return Response.json({ error: "内置语音不可用，请用本机朗读。" }, { status: 503 });
        const upstream = await fetch("https://api.x.ai/v1/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
          body: JSON.stringify({ text: text.slice(0, 400), voice_id: body?.voice || "eve" }),
          signal: request.signal,
        });
        if (!upstream.ok) {
          const err = await upstream.text();
          return Response.json({ error: errorText(upstream.status, err) }, { status: 502 });
        }
        const buf = await upstream.arrayBuffer();
        return new Response(buf, {
          headers: {
            "Content-Type": upstream.headers.get("content-type") || "audio/mpeg",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
