import { createFileRoute } from "@tanstack/react-router";
import {
  assertPublicUrl,
  builtinKey,
  chatCompletionsUrl,
  clampTokens,
  errorText,
  postUpstream,
  type ChatTurn,
} from "@/lib/jingyun/upstream.server";

type Body = {
  mode?: "builtin" | "proxy";
  baseUrl?: string;
  apiKey?: string;
  model?: string;
  messages?: ChatTurn[];
  maxTokens?: number;
  temperature?: number;
  stream?: boolean;
  tools?: unknown[];
};

function sse(obj: unknown): string {
  return `data: ${JSON.stringify(obj)}\n\n`;
}

export const Route = createFileRoute("/api/ai/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return Response.json({ error: "请求不是 JSON" }, { status: 400 });
        }
        const messages = Array.isArray(body.messages) ? body.messages.slice(-30) : [];
        if (!messages.length) return Response.json({ error: "没有消息" }, { status: 400 });
        const builtin = body.mode === "builtin";
        let url = "https://api.x.ai/v1/chat/completions";
        let key = builtinKey();
        let model = "grok-4.5";
        if (!builtin) {
          if (!body.baseUrl || !body.apiKey || !body.model) {
            return Response.json({ error: "缺少接口地址、密钥或模型名" }, { status: 400 });
          }
          try {
            url = chatCompletionsUrl(body.baseUrl);
            assertPublicUrl(url);
          } catch (err) {
            return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
          }
          key = body.apiKey;
          model = body.model.slice(0, 120);
        } else if (!key) {
          return Response.json({ error: "内置 Grok 在这个环境不可用，请添加你自己的接口。" }, { status: 503 });
        }
        const payload: Record<string, unknown> = {
          model,
          messages,
          temperature: typeof body.temperature === "number" ? Math.min(1.5, Math.max(0, body.temperature)) : 0.7,
          max_tokens: clampTokens(body.maxTokens, builtin),
          stream: body.stream !== false,
        };
        if (Array.isArray(body.tools) && body.tools.length && body.stream === false) {
          payload.tools = body.tools.slice(0, 32);
          payload.tool_choice = "auto";
        }
        let upstream: Response;
        try {
          upstream = await postUpstream(url, key || "", payload, request.signal);
        } catch (err) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          return Response.json({ error: err instanceof Error ? err.message : "连接上游失败" }, { status: 502 });
        }
        if (!upstream.ok) {
          const text = await upstream.text();
          return Response.json({ error: errorText(upstream.status, text) }, { status: 502 });
        }
        if (body.stream === false) {
          const json = (await upstream.json()) as {
            choices?: { message?: { content?: unknown; tool_calls?: { id?: string; function?: { name?: string; arguments?: string } }[] } }[];
          };
          const message = json.choices?.[0]?.message;
          const content = typeof message?.content === "string" ? message.content : "";
          const toolCalls = (message?.tool_calls ?? []).map((call) => ({
            id: call.id || crypto.randomUUID(),
            name: call.function?.name || "",
            arguments: call.function?.arguments || "{}",
          }));
          return Response.json({ content, toolCalls });
        }
        if (!upstream.body) return Response.json({ error: "上游没有返回流" }, { status: 502 });
        const reader = upstream.body.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        let buffer = "";
        const stream = new ReadableStream({
          async pull(controller) {
            const { done, value } = await reader.read();
            if (done) {
              controller.enqueue(encoder.encode("data: [DONE]\n\n"));
              controller.close();
              return;
            }
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split(/\r?\n/);
            buffer = lines.pop() ?? "";
            for (const line of lines) {
              const trimmed = line.trim();
              if (!trimmed.startsWith("data:")) continue;
              const data = trimmed.slice(5).trim();
              if (!data) continue;
              if (data === "[DONE]") {
                controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                continue;
              }
              try {
                const json = JSON.parse(data) as {
                  choices?: { delta?: { content?: string } }[];
                  error?: { message?: string };
                };
                if (json.error?.message) {
                  controller.enqueue(encoder.encode(sse({ error: json.error.message })));
                  continue;
                }
                const delta = json.choices?.[0]?.delta?.content ?? "";
                if (delta) controller.enqueue(encoder.encode(sse({ delta })));
              } catch {
                /* ignore keepalives */
              }
            }
          },
          cancel() {
            void reader.cancel();
          },
        });
        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            "X-Accel-Buffering": "no",
          },
        });
      },
    },
  },
});
