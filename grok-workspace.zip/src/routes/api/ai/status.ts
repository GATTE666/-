import { createFileRoute } from "@tanstack/react-router";
import { builtinKey } from "@/lib/jingyun/upstream.server";

export const Route = createFileRoute("/api/ai/status")({
  server: {
    handlers: {
      GET: async () => Response.json({ builtin: Boolean(builtinKey()) }),
    },
  },
});
