import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import type { HoloAction } from "@/lib/jingyun/types";

export type HoloHandle = {
  setAction: (action: HoloAction) => void;
  setSpeaking: (speaking: boolean) => void;
  resize: () => void;
  dispose: () => void;
};

export function mountHolo(canvas: HTMLCanvasElement): HoloHandle {
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 40);
  camera.position.set(0.15, 1.25, 3.35);
  const controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 1.05, 0);
  controls.enableDamping = !reduced;
  controls.enablePan = false;
  controls.minDistance = 1.8;
  controls.maxDistance = 5.4;
  controls.minPolarAngle = 0.55;
  controls.maxPolarAngle = 1.55;
  controls.update();

  scene.add(new THREE.AmbientLight(0xc5d7e6, 0.55));
  const key = new THREE.DirectionalLight(0xfff6ee, 1.35);
  key.position.set(1.4, 3.2, 2.2);
  scene.add(key);
  const rim = new THREE.DirectionalLight(0x7eb6e8, 1.8);
  rim.position.set(-2.2, 1.6, -1.4);
  scene.add(rim);
  const fill = new THREE.PointLight(0x9ec9ee, 4, 8);
  fill.position.set(0, 0.4, 1.6);
  scene.add(fill);

  const skin = new THREE.MeshPhysicalMaterial({ color: 0xf0cbb8, roughness: 0.52, metalness: 0.02 });
  const hairMat = new THREE.MeshPhysicalMaterial({ color: 0x1a2330, roughness: 0.38, metalness: 0.08, clearcoat: 0.35 });
  const cloth = new THREE.MeshPhysicalMaterial({ color: 0x173044, roughness: 0.62, metalness: 0.04 });
  const shirt = new THREE.MeshPhysicalMaterial({ color: 0xe7eef3, roughness: 0.7 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x101820, roughness: 0.5 });
  const irisMat = new THREE.MeshStandardMaterial({ color: 0x2c6796, roughness: 0.25 });
  const blush = new THREE.MeshBasicMaterial({ color: 0xe7a090, transparent: true, opacity: 0.28 });

  const figure = new THREE.Group();
  scene.add(figure);

  const head = new THREE.Group();
  head.position.set(0, 1.58, 0);
  figure.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.34, 40, 32), skin);
  skull.scale.set(0.96, 1.08, 0.98);
  head.add(skull);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.36, 32, 24), hairMat);
  hair.scale.set(1.02, 1.12, 1.05);
  hair.position.set(0, 0.06, -0.04);
  head.add(hair);
  const bang = new THREE.Mesh(new THREE.SphereGeometry(0.2, 24, 16), hairMat);
  bang.scale.set(1.55, 0.42, 0.7);
  bang.position.set(0, 0.2, 0.22);
  head.add(bang);
  const sideL = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.42, 6, 12), hairMat);
  sideL.position.set(-0.3, -0.05, 0.02);
  head.add(sideL);
  const sideR = sideL.clone();
  sideR.position.x = 0.3;
  head.add(sideR);

  const eyeGeo = new THREE.SphereGeometry(0.055, 20, 16);
  const white = new THREE.MeshStandardMaterial({ color: 0xf7fbff, roughness: 0.2 });
  const eyeL = new THREE.Mesh(eyeGeo, white);
  eyeL.position.set(-0.11, 0.03, 0.28);
  eyeL.scale.set(1.15, 1.25, 0.55);
  const eyeR = eyeL.clone();
  eyeR.position.x = 0.11;
  head.add(eyeL, eyeR);
  const irisGeo = new THREE.SphereGeometry(0.028, 16, 12);
  const irisL = new THREE.Mesh(irisGeo, irisMat);
  irisL.position.set(-0.11, 0.02, 0.318);
  const irisR = irisL.clone();
  irisR.position.x = 0.11;
  head.add(irisL, irisR);
  const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.014, 12, 10), dark);
  const pupilL = pupil.clone();
  pupilL.position.set(-0.11, 0.02, 0.338);
  const pupilR = pupil.clone();
  pupilR.position.set(0.11, 0.02, 0.338);
  head.add(pupilL, pupilR);
  const catchMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const catchL = new THREE.Mesh(new THREE.SphereGeometry(0.008, 8, 8), catchMat);
  catchL.position.set(-0.098, 0.034, 0.346);
  const catchR = catchL.clone();
  catchR.position.x = 0.122;
  head.add(catchL, catchR);
  const lidGeo = new THREE.SphereGeometry(0.062, 16, 10);
  const lidMat = hairMat;
  const lidL = new THREE.Mesh(lidGeo, lidMat);
  lidL.position.set(-0.11, 0.07, 0.29);
  lidL.scale.set(1.2, 0.28, 0.4);
  const lidR = lidL.clone();
  lidR.position.x = 0.11;
  head.add(lidL, lidR);
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(0.045, 16, 12), new THREE.MeshStandardMaterial({ color: 0xc98478, roughness: 0.45 }));
  mouth.position.set(0, -0.16, 0.3);
  mouth.scale.set(1.15, 0.28, 0.35);
  head.add(mouth);
  const cheekL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 10), blush);
  cheekL.position.set(-0.18, -0.05, 0.26);
  const cheekR = cheekL.clone();
  cheekR.position.x = 0.18;
  head.add(cheekL, cheekR);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 10), skin);
  nose.position.set(0, -0.04, 0.33);
  nose.scale.set(0.7, 0.55, 0.7);
  head.add(nose);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.12, 16), skin);
  neck.position.set(0, 1.28, 0);
  figure.add(neck);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.42, 8, 20), shirt);
  torso.position.set(0, 0.92, 0);
  torso.scale.set(0.86, 1, 0.62);
  figure.add(torso);
  const coat = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.46, 8, 20), cloth);
  coat.position.set(0, 0.86, -0.02);
  coat.scale.set(1, 1.05, 0.72);
  figure.add(coat);

  function limb(x: number, y: number, z: number, len: number, radius: number, mat: THREE.Material) {
    const pivot = new THREE.Group();
    pivot.position.set(x, y, z);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, len, 6, 12), mat);
    mesh.position.y = -len / 2 - radius;
    pivot.add(mesh);
    return pivot;
  }
  const armL = limb(-0.34, 1.16, 0, 0.34, 0.055, cloth);
  const armR = limb(0.34, 1.16, 0, 0.34, 0.055, cloth);
  armL.rotation.z = 0.18;
  armR.rotation.z = -0.18;
  const forearmL = limb(0, -0.42, 0, 0.28, 0.048, skin);
  const forearmR = limb(0, -0.42, 0, 0.28, 0.048, skin);
  armL.add(forearmL);
  armR.add(forearmR);
  figure.add(armL, armR);
  const legL = limb(-0.12, 0.52, 0, 0.4, 0.07, dark);
  const legR = limb(0.12, 0.52, 0, 0.4, 0.07, dark);
  figure.add(legL, legR);

  const deck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.72, 0.78, 0.06, 48),
    new THREE.MeshPhysicalMaterial({ color: 0x163044, roughness: 0.3, metalness: 0.2, transparent: true, opacity: 0.85 }),
  );
  deck.position.y = 0.03;
  scene.add(deck);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0x8ec4ea, transparent: true, opacity: 0.45 });
  const ringA = new THREE.Mesh(new THREE.TorusGeometry(0.86, 0.008, 8, 64), ringMat);
  ringA.rotation.x = Math.PI / 2;
  ringA.position.y = 0.12;
  const ringB = ringA.clone();
  ringB.scale.setScalar(1.18);
  ringB.position.y = 1.15;
  scene.add(ringA, ringB);
  const shell = new THREE.Mesh(
    new THREE.CylinderGeometry(1.05, 1.05, 2.5, 48, 1, true),
    new THREE.MeshBasicMaterial({ color: 0xb7dcff, transparent: true, opacity: 0.05, side: THREE.DoubleSide }),
  );
  shell.position.y = 1.15;
  scene.add(shell);
  const points = new THREE.BufferGeometry();
  const count = 80;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 0.75 + Math.random() * 0.35;
    positions[i * 3] = Math.cos(a) * r;
    positions[i * 3 + 1] = Math.random() * 2.3;
    positions[i * 3 + 2] = Math.sin(a) * r;
  }
  points.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const dust = new THREE.Points(points, new THREE.PointsMaterial({ color: 0xc5e4ff, size: 0.015, transparent: true, opacity: 0.7 }));
  scene.add(dust);

  let action: HoloAction = "idle";
  let speaking = false;
  let alive = true;
  const clock = new THREE.Clock();

  function resize() {
    const width = canvas.clientWidth || 320;
    const height = canvas.clientHeight || 420;
    renderer.setSize(width, height, false);
    camera.aspect = width / Math.max(1, height);
    camera.updateProjectionMatrix();
  }
  resize();

  function frame() {
    if (!alive) return;
    const t = clock.getElapsedTime();
    if (!reduced) {
      figure.position.y = Math.sin(t * 1.4) * 0.015;
      head.rotation.y = Math.sin(t * 0.6) * 0.08;
      head.rotation.z = Math.sin(t * 0.4) * 0.03;
      ringA.rotation.z = t * 0.35;
      ringB.rotation.z = -t * 0.22;
      dust.rotation.y = t * 0.08;
    }
    const blink = !reduced && Math.sin(t * 0.55) > 0.97;
    const lidScale = blink ? 1.15 : action === "surprise" ? 0.12 : action === "smile" ? 0.42 : 0.28;
    lidL.scale.y = lidScale;
    lidR.scale.y = lidScale;
    const talk = speaking ? 0.55 + Math.abs(Math.sin(t * 14)) * 0.7 : action === "surprise" ? 0.7 : action === "smile" ? 0.38 : 0.28;
    mouth.scale.y = talk;
    mouth.scale.x = action === "smile" ? 1.45 : 1.15;
    if (action === "wave") {
      armR.rotation.z = -2.2 + Math.sin(t * 6) * 0.25;
      armR.rotation.x = -0.2;
    } else if (action === "think") {
      armR.rotation.z = -0.9;
      armR.rotation.x = -1.1;
      head.rotation.z = 0.12;
    } else {
      armR.rotation.z = -0.18 + Math.sin(t * 1.2) * (reduced ? 0 : 0.04);
      armR.rotation.x = 0;
    }
    armL.rotation.z = 0.18 + Math.sin(t * 1.2 + 1) * (reduced ? 0 : 0.04);
    controls.update();
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  return {
    setAction(next) {
      action = next;
    },
    setSpeaking(next) {
      speaking = next;
    },
    resize,
    dispose() {
      alive = false;
      controls.dispose();
      renderer.dispose();
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose?.();
        const material = mesh.material;
        if (Array.isArray(material)) material.forEach((item) => item.dispose());
        else material?.dispose?.();
      });
    },
  };
}
