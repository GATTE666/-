import { useEffect, useState } from "react";
import { Button, FieldLabel, Panel } from "@/components/jingyun/ui";
import { decryptJson, encryptJson } from "@/lib/jingyun/crypto";
import { testProvider } from "@/lib/jingyun/engine";
import { localVoices } from "@/lib/jingyun/speech";
import { BUILTIN_ID, useJingyun } from "@/lib/jingyun/store";
import type { Persisted, Provider, ThemeId, Transport } from "@/lib/jingyun/types";

const THEMES: { id: ThemeId; label: string }[] = [
  { id: "tide", label: "潮汐" },
  { id: "day", label: "白昼" },
  { id: "ink", label: "墨" },
];

export function SettingsView() {
  const theme = useJingyun((s) => s.theme);
  const providers = useJingyun((s) => s.providers);
  const voice = useJingyun((s) => s.voice);
  const maxTokens = useJingyun((s) => s.maxTokens);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [passphrase, setPassphrase] = useState("");
  const [message, setMessage] = useState("");
  const [testing, setTesting] = useState("");

  useEffect(() => {
    const load = () => setVoices(localVoices());
    load();
    window.speechSynthesis?.addEventListener("voiceschanged", load);
    return () => window.speechSynthesis?.removeEventListener("voiceschanged", load);
  }, []);

  function download(filename: string, text: string) {
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function exportEncrypted() {
    if (passphrase.trim().length < 4) {
      setMessage("口令至少 4 位");
      return;
    }
    const text = await encryptJson(useJingyun.getState().snapshot(), passphrase);
    download("jingyun-backup.json", text);
    setMessage("已导出加密备份");
  }

  function exportPlain() {
    download("jingyun-backup-plain.json", JSON.stringify({ format: "jingyun-backup", v: 1, kdf: "none", state: useJingyun.getState().snapshot() }, null, 2));
    setMessage("已导出明文备份，里面有密钥，别外传");
  }

  async function importFile(file: File) {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as { kdf?: string };
      const data = parsed.kdf === "none" ? (JSON.parse(text) as { state: Persisted }).state : (await decryptJson(text, passphrase)) as Persisted;
      if (!data?.providers || !data.personas || !data.sessions) throw new Error("备份里没有完整数据");
      useJingyun.getState().replacePersisted(data);
      document.documentElement.dataset.theme = data.theme;
      setMessage("已恢复");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "恢复失败");
    }
  }

  function addProvider() {
    const provider: Provider = {
      id: crypto.randomUUID(),
      name: "我的接口",
      kind: "openai",
      baseUrl: "https://api.openai.com/v1",
      apiKey: "",
      models: ["gpt-4o-mini"],
      imageModel: "dall-e-3",
      transport: "proxy",
    };
    useJingyun.getState().upsertProvider(provider);
  }

  function update(provider: Provider, patch: Partial<Provider>) {
    useJingyun.getState().upsertProvider({ ...provider, ...patch });
  }

  return (
    <div className="scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3">
      <Panel>
        <h2 className="mb-2 text-lg font-medium">主题</h2>
        <div className="flex gap-2">
          {THEMES.map((item) => (
            <button key={item.id} type="button" className="chip" aria-pressed={theme === item.id} onClick={() => useJingyun.getState().setTheme(item.id)}>
              {item.label}
            </button>
          ))}
        </div>
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">模型服务商</h2>
        <p className="mb-3 text-sm text-muted">密钥在本机用 AES-GCM 加密后保存。内置 Grok 不需要你的密钥，但会使用应用额度，发布后任何打开的人都能消耗它。只想自己用时，改填自己的接口。</p>
        {providers.map((provider) => (
          <div key={provider.id} className="mb-4 rounded-lg border border-line p-3">
            <FieldLabel>名称</FieldLabel>
            <input className="field mb-2" value={provider.name} disabled={provider.id === BUILTIN_ID} onChange={(ev) => update(provider, { name: ev.target.value })} />
            {provider.kind === "openai" ? (
              <>
                <FieldLabel>接口地址，填到 /v1</FieldLabel>
                <input className="field mb-2" value={provider.baseUrl} onChange={(ev) => update(provider, { baseUrl: ev.target.value })} />
                <FieldLabel>API Key</FieldLabel>
                <input className="field mb-2" type="password" value={provider.apiKey} onChange={(ev) => update(provider, { apiKey: ev.target.value })} />
                <FieldLabel>连接方式</FieldLabel>
                <select className="field mb-2" value={provider.transport} onChange={(ev) => update(provider, { transport: ev.target.value as Transport })}>
                  <option value="proxy">服务器代理（公网，避开跨域）</option>
                  <option value="direct">浏览器直连（本地或允许跨域的地址）</option>
                </select>
                <FieldLabel>模型名，每行一个</FieldLabel>
                <textarea className="field mb-2" value={provider.models.join("\n")} onChange={(ev) => update(provider, { models: ev.target.value.split(/\n+/).map((item) => item.trim()).filter(Boolean) })} />
                <FieldLabel>绘图模型名，可空</FieldLabel>
                <input className="field mb-2" value={provider.imageModel} onChange={(ev) => update(provider, { imageModel: ev.target.value })} />
              </>
            ) : (
              <p className="mb-2 text-sm text-muted">对话模型 grok-4.5，绘图模型 grok-imagine-image。不能改成别的模型来花内置额度。</p>
            )}
            <div className="flex flex-wrap gap-2">
              <Button
                disabled={testing === provider.id}
                onClick={() => {
                  setTesting(provider.id);
                  setMessage("");
                  void testProvider(provider)
                    .then((text) => setMessage(`${provider.name} 有响应：${text}`))
                    .catch((err: unknown) => setMessage(err instanceof Error ? err.message : "测试失败"))
                    .finally(() => setTesting(""));
                }}
              >
                {testing === provider.id ? "测试中" : "测试连接"}
              </Button>
              {provider.id !== BUILTIN_ID ? <Button variant="danger" onClick={() => useJingyun.getState().removeProvider(provider.id)}>删除</Button> : null}
            </div>
          </div>
        ))}
        <Button onClick={addProvider}>添加服务商</Button>
        {message ? <p className="mt-3 text-sm text-muted">{message}</p> : null}
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">回复长度</h2>
        <input className="w-full" type="range" min={128} max={2048} step={64} value={maxTokens} onChange={(ev) => useJingyun.getState().setMaxTokens(Number(ev.target.value))} />
        <p className="text-sm text-muted">内置模型在服务端仍限制为 800。当前设置 {maxTokens}。</p>
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">本机语音</h2>
        <FieldLabel>声音</FieldLabel>
        <select className="field mb-3" value={voice.voiceURI} onChange={(ev) => useJingyun.getState().setVoice({ voiceURI: ev.target.value })}>
          <option value="">系统默认</option>
          {voices.map((item) => <option key={item.voiceURI} value={item.voiceURI}>{item.name} · {item.lang}</option>)}
        </select>
        <FieldLabel>语速 {voice.rate.toFixed(1)}</FieldLabel>
        <input className="mb-2 w-full" type="range" min={0.6} max={1.4} step={0.1} value={voice.rate} onChange={(ev) => useJingyun.getState().setVoice({ rate: Number(ev.target.value) })} />
        <FieldLabel>音高 {voice.pitch.toFixed(1)}</FieldLabel>
        <input className="w-full" type="range" min={0.6} max={1.4} step={0.1} value={voice.pitch} onChange={(ev) => useJingyun.getState().setVoice({ pitch: Number(ev.target.value) })} />
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">备份</h2>
        <FieldLabel>导出或恢复用的口令</FieldLabel>
        <input className="field mb-3" type="password" value={passphrase} onChange={(ev) => setPassphrase(ev.target.value)} />
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" onClick={() => void exportEncrypted()}>加密导出</Button>
          <Button onClick={exportPlain}>明文导出</Button>
          <label className="btn btn-ghost">
            恢复
            <input
              className="sr-only"
              type="file"
              accept="application/json,.json"
              onChange={(ev) => {
                const file = ev.target.files?.[0];
                if (file) void importFile(file);
              }}
            />
          </label>
        </div>
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">交付边界</h2>
        <p className="text-sm text-muted">
          你要的是包名 com.jingyun.ai 的 Kotlin + Jetpack Compose 安装包，以及 GitHub Actions 编出来的 APK。这里给出的是能直接使用的鲸云：对话流式输出、多人设和独立记忆、可旋转的 3D 角色、识图和绘图、文件分析、语音、搜索、MCP、OneBot 都是真的调用。
        </p>
        <ul className="mt-2 list-disc space-y-1 pl-4 text-sm text-muted">
          <li>没有编译 APK，也没有 Android 工程。这个环境只能运行网页应用。</li>
          <li>不能在手机里安装或管理 Termux / PRoot，也不能代替协议端扫码登录 QQ。</li>
          <li>MCP 只支持公网 HTTP，不支持本机 stdio。</li>
          <li>内置模型有长度和每小时自动回复次数限制，避免把额度打空。</li>
        </ul>
      </Panel>
    </div>
  );
}
