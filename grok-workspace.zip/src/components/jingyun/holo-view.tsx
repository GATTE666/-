import { useEffect, useRef } from "react";
import type { HoloHandle } from "@/components/jingyun/holo-scene";
import { Button } from "@/components/jingyun/ui";
import { useJingyun } from "@/lib/jingyun/store";
import type { HoloAction } from "@/lib/jingyun/types";

const ACTIONS: { id: HoloAction; label: string }[] = [
  { id: "idle", label: "待机" },
  { id: "wave", label: "挥手" },
  { id: "think", label: "思考" },
  { id: "smile", label: "微笑" },
  { id: "surprise", label: "惊讶" },
];

export function HoloView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const handleRef = useRef<HoloHandle | null>(null);
  const action = useJingyun((s) => s.holoAction);
  const speaking = useJingyun((s) => s.speaking);
  const generating = useJingyun((s) => s.generating);
  const follow = useJingyun((s) => s.holoFollow);
  const personaName = useJingyun((s) => s.personas.find((item) => item.id === s.activePersonaId)?.name || "鲸云");

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let handle: HoloHandle | null = null;
    const onResize = () => handle?.resize();
    void import("@/components/jingyun/holo-scene").then((mod) => {
      if (dead || !canvasRef.current) return;
      handle = mod.mountHolo(canvasRef.current);
      handle.setAction(useJingyun.getState().holoAction);
      handleRef.current = handle;
      window.addEventListener("resize", onResize);
    });
    return () => {
      dead = true;
      window.removeEventListener("resize", onResize);
      handle?.dispose();
      handleRef.current = null;
    };
  }, []);

  useEffect(() => {
    handleRef.current?.setAction(action);
  }, [action]);

  useEffect(() => {
    handleRef.current?.setSpeaking(follow && (speaking || generating));
  }, [follow, speaking, generating]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="chamber relative min-h-0 flex-1 overflow-hidden">
        <canvas ref={canvasRef} className="h-full w-full touch-none" />
        <div className="scan absolute inset-x-8 top-0 h-16" />
        <div className="pointer-events-none absolute inset-x-0 top-4 text-center">
          <p className="text-sm tracking-wide text-muted">{personaName}</p>
          <p className="text-xs text-subtle">拖动旋转，双指缩放</p>
        </div>
      </div>
      <div className="flex gap-2 overflow-x-auto px-3 py-3">
        {ACTIONS.map((item) => (
          <button key={item.id} type="button" className="chip" aria-pressed={action === item.id} onClick={() => useJingyun.getState().setHoloAction(item.id)}>
            {item.label}
          </button>
        ))}
        <Button aria-pressed={follow} className="chip" onClick={() => useJingyun.getState().setHoloFollow(!follow)}>
          {follow ? "跟随说话" : "不跟随"}
        </Button>
      </div>
    </div>
  );
}
