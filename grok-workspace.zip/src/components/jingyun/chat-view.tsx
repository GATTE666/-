import { Copy, ImagePlus, Mic, Paperclip, Pause, Plus, Send, Square, Volume2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { RichText } from "@/components/jingyun/markdown";
import { Button, cx } from "@/components/jingyun/ui";
import { decideTool, extractMemories, sendInSession, stopGeneration } from "@/lib/jingyun/engine";
import { fileToAttachment } from "@/lib/jingyun/files";
import { pauseSpeech, resumeSpeech, speakCloud, speakLocal, speechInputAvailable, startDictation, stopSpeech } from "@/lib/jingyun/speech";
import { useJingyun } from "@/lib/jingyun/store";
import type { Attachment, TurnMode } from "@/lib/jingyun/types";

const MODES: { id: TurnMode; label: string }[] = [
  { id: null, label: "对话" },
  { id: "write", label: "写作" },
  { id: "code", label: "编程" },
  { id: "translate", label: "翻译" },
];

export function ChatView() {
  const sessions = useJingyun((s) => s.sessions);
  const activeSessionId = useJingyun((s) => s.activeSessionId);
  const personas = useJingyun((s) => s.personas);
  const providers = useJingyun((s) => s.providers);
  const compare = useJingyun((s) => s.compare);
  const compareProviderId = useJingyun((s) => s.compareProviderId);
  const compareModel = useJingyun((s) => s.compareModel);
  const toolsArmed = useJingyun((s) => s.toolsArmed);
  const generating = useJingyun((s) => s.generating);
  const speaking = useJingyun((s) => s.speaking);
  const builtinReady = useJingyun((s) => s.builtinReady);
  const pendingTool = useJingyun((s) => s.pendingTool);
  const session = sessions.find((item) => item.id === activeSessionId) ?? sessions[0];
  const [text, setText] = useState("");
  const [mode, setMode] = useState<TurnMode>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [error, setError] = useState("");
  const [listening, setListening] = useState(false);
  const [note, setNote] = useState("");
  const scroller = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const dictation = useRef<{ stop: () => void } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!stick.current) return;
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [session?.messages, generating, session?.id]);

  async function addFiles(list: FileList | null, imagesOnly = false) {
    if (!list?.length) return;
    setError("");
    const next: Attachment[] = [];
    for (const file of Array.from(list)) {
      if (imagesOnly && !file.type.startsWith("image/")) continue;
      try {
        next.push(await fileToAttachment(file));
      } catch (err) {
        setError(err instanceof Error ? err.message : "文件读取失败");
      }
    }
    setAttachments((curr) => [...curr, ...next].slice(0, 4));
  }

  async function send() {
    if (!session) return;
    setError("");
    const payload = text;
    const files = attachments;
    setText("");
    setAttachments([]);
    try {
      await sendInSession({ sessionId: session.id, text: payload, attachments: files, mode, compare });
    } catch (err) {
      setError(err instanceof Error ? err.message : "发送失败");
    }
  }

  function toggleMic() {
    if (listening) {
      dictation.current?.stop();
      return;
    }
    if (!speechInputAvailable()) {
      setError("这个浏览器没有语音输入。手机 Chrome 通常可用，部分内置浏览器不支持。");
      return;
    }
    setListening(true);
    dictation.current = startDictation({
      onText: (said, final) => {
        setText((curr) => (final ? `${curr}${said}` : curr));
        if (!final) setNote(said);
        else setNote("");
      },
      onError: (message) => setError(message),
      onEnd: () => setListening(false),
    });
  }

  function readMessage(content: string, cloud: boolean) {
    setError("");
    useJingyun.getState().setSpeaking(true);
    const done = () => useJingyun.getState().setSpeaking(false);
    if (cloud) {
      void speakCloud(content, done).catch((err: unknown) => {
        done();
        setError(err instanceof Error ? err.message : "朗读失败");
      });
      return;
    }
    try {
      speakLocal(content, useJingyun.getState().voice, done);
    } catch (err) {
      done();
      setError(err instanceof Error ? err.message : "朗读失败");
    }
  }

  if (!session) return null;
  const persona = personas.find((item) => item.id === session.personaId);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 overflow-x-auto px-3 py-2">
        {sessions.map((item) => (
          <button
            key={item.id}
            type="button"
            className="chip"
            aria-pressed={item.id === session.id}
            onClick={() => useJingyun.getState().selectSession(item.id)}
          >
            {item.origin?.type === "qq" ? "QQ · " : ""}
            {item.title}
          </button>
        ))}
        <button type="button" className="chip" onClick={() => useJingyun.getState().newSession()}>
          <Plus className="mr-1 inline size-4" aria-hidden="true" />
          新对话
        </button>
      </div>
      <div className="flex items-center gap-2 px-3 pb-2">
        <label className="sr-only" htmlFor="persona-select">当前人设</label>
        <select
          id="persona-select"
          className="field max-w-48"
          value={session.personaId}
          onChange={(ev) => useJingyun.getState().setSessionPersona(session.id, ev.target.value)}
        >
          {personas.map((item) => (
            <option key={item.id} value={item.id}>{item.name}</option>
          ))}
        </select>
        <span className="truncate text-sm text-muted">{persona?.model}</span>
        <button type="button" className="ml-auto text-sm text-muted underline-offset-2 hover:underline" onClick={() => useJingyun.getState().clearSession(session.id)}>
          清空
        </button>
      </div>
      {builtinReady === false && persona?.providerId === "builtin" ? (
        <p className="mx-3 mb-2 rounded-sm border border-line px-3 py-2 text-sm text-muted">内置 Grok 当前不可用。到设置里添加你自己的接口地址和密钥。</p>
      ) : null}
      <div
        ref={scroller}
        className="scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-3"
        onScroll={(ev) => {
          const el = ev.currentTarget;
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
        }}
      >
        {session.messages.filter((message) => message.role !== "tool").length === 0 ? (
          <p className="pt-8 text-center text-sm text-muted">这则对话还是空的。写一句，或附上图片和文件。</p>
        ) : null}
        {session.messages.map((message) => {
          if (message.role === "tool") {
            return (
              <p key={message.id} className="rounded-sm border border-line px-3 py-2 text-sm text-muted">
                工具 {message.toolName}：{message.content.slice(0, 280)}
              </p>
            );
          }
          const mine = message.role === "user";
          return (
            <article key={message.id} className={cx("max-w-[92%] rounded-lg px-3 py-2", mine ? "ml-auto bg-accent text-accent-fg" : "bg-elev border border-line")}>
              {message.compareKey ? <p className="mb-1 text-xs opacity-70">模型 {message.compareKey === "a" ? "A" : "B"} · {message.model}</p> : null}
              {message.content ? mine ? <p className="whitespace-pre-wrap break-words">{message.content}</p> : <RichText text={message.content} /> : null}
              {message.pending && !message.content ? <p className="text-sm text-muted">正在写…</p> : null}
              {message.attachments?.map((file) => (
                <p key={file.id} className="mt-1 text-xs opacity-80">
                  {file.kind === "image" ? "图片" : "文件"} · {file.name}
                  {file.dataUrl && file.kind === "image" ? <img src={file.dataUrl} alt={file.name} className="mt-2 max-h-40 rounded-sm" /> : null}
                </p>
              ))}
              {message.error ? <p className="mt-1 text-sm text-danger">{message.error}</p> : null}
              {!mine && message.content && !message.pending ? (
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" className="text-sm text-muted" onClick={() => void navigator.clipboard.writeText(message.content)}>
                    <Copy className="mr-1 inline size-3.5" aria-hidden="true" />复制
                  </button>
                  <button type="button" className="text-sm text-muted" onClick={() => readMessage(message.content, false)}>
                    <Volume2 className="mr-1 inline size-3.5" aria-hidden="true" />朗读
                  </button>
                  <button type="button" className="text-sm text-muted" onClick={() => readMessage(message.content, true)}>
                    Grok 语音
                  </button>
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
      {error ? <p className="px-3 pb-1 text-sm text-danger">{error}</p> : null}
      {note ? <p className="px-3 pb-1 text-sm text-muted">听到：{note}</p> : null}
      {pendingTool ? (
        <div className="mx-3 mb-2 rounded-lg border border-line bg-elev p-3" role="dialog" aria-label="工具权限">
          <p className="text-sm">允许 {pendingTool.serverName} 调用 {pendingTool.tool}？</p>
          <pre className="mt-2 max-h-24 overflow-auto font-mono text-xs text-muted">{pendingTool.args}</pre>
          <div className="mt-2 flex gap-2">
            <Button variant="primary" onClick={() => decideTool(true)}>允许这一次</Button>
            <Button onClick={() => decideTool(false)}>拒绝</Button>
          </div>
        </div>
      ) : null}
      <div className="border-t border-line px-3 py-2">
        <div className="mb-2 flex gap-2 overflow-x-auto">
          {MODES.map((item) => (
            <button key={item.label} type="button" className="chip" aria-pressed={mode === item.id} onClick={() => setMode(item.id)}>
              {item.label}
            </button>
          ))}
          <button type="button" className="chip" aria-pressed={compare} onClick={() => useJingyun.getState().setCompare(!compare)}>对比</button>
          <button type="button" className="chip" aria-pressed={toolsArmed} onClick={() => useJingyun.getState().setToolsArmed(!toolsArmed)}>工具</button>
          <button
            type="button"
            className="chip"
            onClick={() => {
              void extractMemories(session.personaId, session.id)
                .then((count) => setNote(count ? `已写入 ${count} 条记忆` : "这轮没有值得长期记住的内容"))
                .catch((err: unknown) => setError(err instanceof Error ? err.message : "提取失败"));
            }}
          >
            记入记忆
          </button>
        </div>
        {compare ? (
          <div className="mb-2 flex gap-2">
            <select
              className="field"
              value={compareProviderId}
              onChange={(ev) => {
                const provider = providers.find((item) => item.id === ev.target.value);
                useJingyun.getState().setCompareTarget(ev.target.value, provider?.models[0] || "");
              }}
            >
              {providers.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
            </select>
            <select
              className="field"
              value={compareModel}
              onChange={(ev) => useJingyun.getState().setCompareTarget(compareProviderId, ev.target.value)}
            >
              {(providers.find((item) => item.id === useJingyun.getState().compareProviderId)?.models ?? []).map((model) => (
                <option key={model} value={model}>{model}</option>
              ))}
            </select>
          </div>
        ) : null}
        {attachments.length ? (
          <div className="mb-2 flex flex-wrap gap-2">
            {attachments.map((file) => (
              <button key={file.id} type="button" className="chip" onClick={() => setAttachments((curr) => curr.filter((item) => item.id !== file.id))}>
                {file.name} · 移除
              </button>
            ))}
          </div>
        ) : null}
        <div className="flex items-end gap-2">
          <input ref={fileRef} type="file" hidden accept=".txt,.md,.markdown,.pdf,.docx,.csv,.json,.log,text/plain" onChange={(ev) => void addFiles(ev.target.files)} />
          <input ref={imageRef} type="file" hidden accept="image/*" onChange={(ev) => void addFiles(ev.target.files, true)} />
          <button type="button" className="btn btn-ghost size-11 px-0" aria-label="上传文件" onClick={() => fileRef.current?.click()}>
            <Paperclip className="mx-auto size-5" />
          </button>
          <button type="button" className="btn btn-ghost size-11 px-0" aria-label="识图" onClick={() => imageRef.current?.click()}>
            <ImagePlus className="mx-auto size-5" />
          </button>
          <button type="button" className={cx("btn btn-ghost size-11 px-0", listening && "border-focus")} aria-label="语音输入" onClick={toggleMic}>
            <Mic className="mx-auto size-5" />
          </button>
          <textarea
            className="field min-h-11 flex-1 py-2"
            rows={2}
            placeholder="写给鲸云"
            value={text}
            onChange={(ev) => setText(ev.target.value)}
            onKeyDown={(ev) => {
              if (ev.key === "Enter" && !ev.shiftKey && !ev.nativeEvent.isComposing) {
                ev.preventDefault();
                void send();
              }
            }}
          />
          {generating ? (
            <button type="button" className="btn btn-primary size-11 px-0" aria-label="停止生成" onClick={() => stopGeneration()}>
              <Square className="mx-auto size-4" />
            </button>
          ) : (
            <button type="button" className="btn btn-primary size-11 px-0" aria-label="发送" onClick={() => void send()}>
              <Send className="mx-auto size-4" />
            </button>
          )}
        </div>
        <div className="mt-2 flex gap-2">
          {speaking ? (
            <>
              <Button onClick={() => pauseSpeech()}><Pause className="mr-1 inline size-4" />暂停</Button>
              <Button onClick={() => resumeSpeech()}>继续</Button>
              <Button variant="danger" onClick={() => { stopSpeech(); useJingyun.getState().setSpeaking(false); }}>停止朗读</Button>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}
