import { useState } from "react";
import { Button, FieldLabel, Panel } from "@/components/jingyun/ui";
import { apiUrl } from "@/lib/jingyun/api-url";
import { restartBot, startBot, stopBot } from "@/lib/jingyun/bot";
import { sendInSession } from "@/lib/jingyun/engine";
import { fileToAttachment } from "@/lib/jingyun/files";
import { discoverTools } from "@/lib/jingyun/mcp";
import { providerById, useJingyun } from "@/lib/jingyun/store";
import type { Attachment, LabTab, McpServer, SearchProvider, ToolPermission } from "@/lib/jingyun/types";

const TABS: { id: LabTab; label: string }[] = [
  { id: "search", label: "搜索" },
  { id: "image", label: "绘图" },
  { id: "files", label: "文件" },
  { id: "mcp", label: "MCP" },
  { id: "qq", label: "QQ" },
];

type Hit = { title: string; url: string; snippet: string; source: string };

export function LabView() {
  const tab = useJingyun((s) => s.labTab);
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex gap-2 overflow-x-auto px-3 py-2">
        {TABS.map((item) => (
          <button key={item.id} type="button" className="chip" aria-pressed={tab === item.id} onClick={() => useJingyun.getState().setLabTab(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-3 pb-4">
        {tab === "search" ? <SearchPane /> : null}
        {tab === "image" ? <ImagePane /> : null}
        {tab === "files" ? <FilePane /> : null}
        {tab === "mcp" ? <McpPane /> : null}
        {tab === "qq" ? <QqPane /> : null}
      </div>
    </div>
  );
}

function SearchPane() {
  const search = useJingyun((s) => s.search);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Hit[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch(apiUrl("/api/search"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: search.provider, query, apiKey: search.apiKey, endpoint: search.endpoint }),
      });
      const json = (await res.json()) as { results?: Hit[]; error?: string };
      if (!res.ok || json.error) throw new Error(json.error || "搜索失败");
      setHits(json.results ?? []);
      if (!json.results?.length) setError("没有结果。可以换关键词，或改用带密钥的搜索服务。");
    } catch (err) {
      setError(err instanceof Error ? err.message : "搜索失败");
    } finally {
      setBusy(false);
    }
  }

  async function summarize() {
    if (!hits.length) return;
    const state = useJingyun.getState();
    const block = hits.map((hit, i) => `${i + 1}. ${hit.title}\n${hit.url}\n${hit.snippet}`).join("\n\n");
    await sendInSession({
      sessionId: state.activeSessionId,
      text: `请根据这些搜索结果回答「${query}」。给出结论，并保留来源链接。\n\n${block}`,
    });
    state.setView("chat");
  }

  return (
    <div className="space-y-3">
      <Panel>
        <FieldLabel>搜索服务</FieldLabel>
        <select
          className="field mb-3"
          value={search.provider}
          onChange={(ev) => useJingyun.getState().setSearch({ provider: ev.target.value as SearchProvider })}
        >
          <option value="wiki">维基百科（免密钥）</option>
          <option value="tavily">Tavily</option>
          <option value="brave">Brave</option>
          <option value="serper">Serper</option>
          <option value="custom">自定义 JSON 接口</option>
        </select>
        {search.provider !== "wiki" ? (
          <>
            <FieldLabel>API Key</FieldLabel>
            <input className="field mb-3" type="password" value={search.apiKey} onChange={(ev) => useJingyun.getState().setSearch({ apiKey: ev.target.value })} />
          </>
        ) : null}
        {search.provider === "custom" ? (
          <>
            <FieldLabel>接口地址</FieldLabel>
            <input className="field mb-3" placeholder="https://example.com/search" value={search.endpoint} onChange={(ev) => useJingyun.getState().setSearch({ endpoint: ev.target.value })} />
            <p className="mb-3 text-sm text-muted">需要返回 {"{ results: [{ title, url, snippet }] }"}。地址必须是公网。</p>
          </>
        ) : null}
        <FieldLabel>搜索词</FieldLabel>
        <div className="flex gap-2">
          <input className="field" value={query} onChange={(ev) => setQuery(ev.target.value)} onKeyDown={(ev) => { if (ev.key === "Enter") void run(); }} />
          <Button variant="primary" disabled={busy} onClick={() => void run()}>{busy ? "搜索中" : "搜索"}</Button>
        </div>
        {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      </Panel>
      {hits.map((hit) => (
        <Panel key={hit.url}>
          <a href={hit.url} target="_blank" rel="noreferrer" className="font-medium underline-offset-2 hover:underline">{hit.title}</a>
          <p className="mt-1 text-sm text-muted">{hit.snippet}</p>
          <p className="mt-1 text-xs text-subtle">{hit.source}</p>
        </Panel>
      ))}
      {hits.length ? <Button variant="primary" onClick={() => void summarize()}>交给当前人设总结</Button> : null}
    </div>
  );
}

function ImagePane() {
  const personas = useJingyun((s) => s.personas);
  const activePersonaId = useJingyun((s) => s.activePersonaId);
  const persona = personas.find((item) => item.id === activePersonaId) ?? personas[0];
  const provider = persona ? providerById(persona.providerId) : undefined;
  const [prompt, setPrompt] = useState("");
  const [images, setImages] = useState<{ url: string; b64: string }[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    if (!provider) return;
    setBusy(true);
    setError("");
    try {
      const res = await fetch(apiUrl("/api/ai/image"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: provider.kind === "builtin" ? "builtin" : "proxy",
          baseUrl: provider.baseUrl,
          apiKey: provider.apiKey,
          model: provider.imageModel,
          prompt,
        }),
      });
      const json = (await res.json()) as { images?: { url: string; b64: string }[]; error?: string };
      if (!res.ok || json.error) throw new Error(json.error || "绘图失败");
      setImages(json.images ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "绘图失败");
    } finally {
      setBusy(false);
    }
  }

  async function sendImage(image: { url: string; b64: string }) {
    const dataUrl = image.url || (image.b64 ? `data:image/png;base64,${image.b64}` : "");
    if (!dataUrl) return;
    const attachment: Attachment = { id: crypto.randomUUID(), name: "生成的图片", kind: "image", dataUrl };
    const state = useJingyun.getState();
    await sendInSession({ sessionId: state.activeSessionId, text: "请看看这张图。", attachments: [attachment] });
    state.setView("chat");
  }

  return (
    <Panel>
      <p className="mb-3 text-sm text-muted">使用当前人设的服务商。内置走 Grok 绘图；自己的接口走 OpenAI 兼容的 images 接口，模型名在设置里填。</p>
      <textarea className="field mb-3" placeholder="想生成的画面" value={prompt} onChange={(ev) => setPrompt(ev.target.value)} />
      <Button variant="primary" disabled={busy || !prompt.trim()} onClick={() => void run()}>{busy ? "生成中" : "生成图片"}</Button>
      {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      <div className="mt-3 space-y-3">
        {images.map((image, index) => {
          const src = image.url || (image.b64 ? `data:image/png;base64,${image.b64}` : "");
          return (
            <div key={index}>
              {src ? <img src={src} alt="生成结果" className="max-h-80 rounded-lg" /> : null}
              <div className="mt-2 flex gap-2">
                {src ? <a className="btn btn-ghost" href={src} download={`jingyun-${index + 1}.png`}>下载</a> : null}
                <Button onClick={() => void sendImage(image)}>发给对话分析</Button>
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

function FilePane() {
  const [file, setFile] = useState<Attachment | null>(null);
  const [error, setError] = useState("");

  return (
    <Panel>
      <p className="mb-3 text-sm text-muted">支持 PDF、DOCX、TXT、Markdown。旧版二进制 DOC 请先另存为 DOCX。文件在这台设备上解析，不会单独上传保存。</p>
      <input
        className="field mb-3"
        type="file"
        accept=".pdf,.docx,.txt,.md,.markdown"
        onChange={(ev) => {
          const picked = ev.target.files?.[0];
          if (!picked) return;
          void fileToAttachment(picked).then(setFile).catch((err: unknown) => {
            setFile(null);
            setError(err instanceof Error ? err.message : "读取失败");
          });
        }}
      />
      {error ? <p className="mb-2 text-sm text-danger">{error}</p> : null}
      {file?.text ? <pre className="mb-3 max-h-48 overflow-auto whitespace-pre-wrap rounded-sm bg-bg p-3 text-sm">{file.text.slice(0, 1500)}</pre> : null}
      <Button
        variant="primary"
        disabled={!file}
        onClick={() => {
          if (!file) return;
          const state = useJingyun.getState();
          void sendInSession({ sessionId: state.activeSessionId, text: `请总结并分析文件「${file.name}」。`, attachments: [file] }).then(() => state.setView("chat"));
        }}
      >
        让当前人设分析
      </Button>
    </Panel>
  );
}

function McpPane() {
  const servers = useJingyun((s) => s.mcpServers);
  const logs = useJingyun((s) => s.toolLogs);
  const [draft, setDraft] = useState({ name: "", url: "", headerText: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  function add() {
    if (!draft.url.trim()) {
      setError("先填写 MCP 地址");
      return;
    }
    const server: McpServer = {
      id: crypto.randomUUID(),
      name: draft.name.trim() || "MCP",
      url: draft.url.trim(),
      headerText: draft.headerText,
      enabled: true,
      tools: [],
      toolPermission: {},
    };
    useJingyun.getState().upsertMcp(server);
    setDraft({ name: "", url: "", headerText: "" });
  }

  async function discover(server: McpServer) {
    setBusy(server.id);
    setError("");
    try {
      const tools = await discoverTools(server);
      const toolPermission = { ...server.toolPermission };
      for (const tool of tools) if (!toolPermission[tool.name]) toolPermission[tool.name] = "ask";
      useJingyun.getState().upsertMcp({ ...server, tools, toolPermission });
    } catch (err) {
      setError(err instanceof Error ? err.message : "发现工具失败");
    } finally {
      setBusy("");
    }
  }

  function setPerm(server: McpServer, tool: string, permission: ToolPermission) {
    useJingyun.getState().upsertMcp({ ...server, toolPermission: { ...server.toolPermission, [tool]: permission } });
  }

  return (
    <div className="space-y-3">
      <Panel>
        <p className="mb-3 text-sm text-muted">连接公网 HTTP MCP。本地 stdio 服务这里到不了。发现工具后，回对话打开「工具」，模型才能调用。默认每次询问。</p>
        <FieldLabel>名称</FieldLabel>
        <input className="field mb-3" value={draft.name} onChange={(ev) => setDraft({ ...draft, name: ev.target.value })} />
        <FieldLabel>地址</FieldLabel>
        <input className="field mb-3" placeholder="https://example.com/mcp" value={draft.url} onChange={(ev) => setDraft({ ...draft, url: ev.target.value })} />
        <FieldLabel>请求头，一行一个</FieldLabel>
        <textarea className="field mb-3" placeholder={"Authorization: Bearer ..."} value={draft.headerText} onChange={(ev) => setDraft({ ...draft, headerText: ev.target.value })} />
        <Button variant="primary" onClick={add}>添加服务</Button>
        {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
      </Panel>
      {servers.map((server) => (
        <Panel key={server.id}>
          <div className="mb-2 flex items-center justify-between gap-2">
            <h3 className="font-medium">{server.name}</h3>
            <button type="button" className="text-sm text-danger" onClick={() => useJingyun.getState().removeMcp(server.id)}>删除</button>
          </div>
          <p className="mb-2 break-all text-sm text-muted">{server.url}</p>
          <label className="mb-2 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={server.enabled} onChange={(ev) => useJingyun.getState().upsertMcp({ ...server, enabled: ev.target.checked })} />
            启用
          </label>
          <Button disabled={busy === server.id} onClick={() => void discover(server)}>{busy === server.id ? "发现中" : "发现工具"}</Button>
          <ul className="mt-3 space-y-2">
            {server.tools.map((tool) => (
              <li key={tool.name} className="flex items-center justify-between gap-2 text-sm">
                <span>{tool.name}</span>
                <select className="field w-28" value={server.toolPermission[tool.name] || "ask"} onChange={(ev) => setPerm(server, tool.name, ev.target.value as ToolPermission)}>
                  <option value="ask">询问</option>
                  <option value="allow">允许</option>
                  <option value="deny">拒绝</option>
                </select>
              </li>
            ))}
          </ul>
        </Panel>
      ))}
      <Panel>
        <h3 className="mb-2 font-medium">执行记录</h3>
        {logs.length === 0 ? <p className="text-sm text-muted">还没有调用。</p> : null}
        <ul className="space-y-2">
          {[...logs].reverse().slice(0, 20).map((log) => (
            <li key={log.id} className="text-sm">
              <span className={log.ok ? "text-ok" : "text-danger"}>{log.ok ? "成功" : "失败"}</span>
              {" "}{log.server} / {log.tool}
              <p className="text-muted">{log.result.slice(0, 180)}</p>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

function QqPane() {
  const qq = useJingyun((s) => s.qq);
  const status = useJingyun((s) => s.qqStatus);
  const logs = useJingyun((s) => s.qqLogs);
  const personas = useJingyun((s) => s.personas);
  return (
    <div className="space-y-3">
      <Panel>
        <p className="text-sm text-muted">状态：{status.detail}</p>
        <p className="mt-1 text-sm text-subtle">适配器可替换。刷新或离开页面会断开，网页不能在后台常驻。</p>
        <FieldLabel>适配器</FieldLabel>
        <select className="field mb-3" value={qq.adapter} onChange={(ev) => useJingyun.getState().setQq({ adapter: ev.target.value as "onebot11" | "http" })}>
          <option value="onebot11">OneBot 11 正向 WebSocket</option>
          <option value="http">HTTP 事件适配器</option>
        </select>
        {qq.adapter === "onebot11" ? (
          <>
            <FieldLabel>WebSocket 地址</FieldLabel>
            <input className="field mb-3" placeholder="wss://your-napcat.example/onebot" value={qq.wsUrl} onChange={(ev) => useJingyun.getState().setQq({ wsUrl: ev.target.value })} />
            <FieldLabel>Access Token</FieldLabel>
            <input className="field mb-3" type="password" value={qq.accessToken} onChange={(ev) => useJingyun.getState().setQq({ accessToken: ev.target.value })} />
          </>
        ) : (
          <>
            <FieldLabel>事件轮询地址</FieldLabel>
            <input className="field mb-3" placeholder="https://example.com/events" value={qq.pollUrl} onChange={(ev) => useJingyun.getState().setQq({ pollUrl: ev.target.value })} />
            <FieldLabel>发送地址</FieldLabel>
            <input className="field mb-3" placeholder="https://example.com/send" value={qq.sendUrl} onChange={(ev) => useJingyun.getState().setQq({ sendUrl: ev.target.value })} />
            <FieldLabel>请求头</FieldLabel>
            <textarea className="field mb-3" value={qq.httpHeaderText} onChange={(ev) => useJingyun.getState().setQq({ httpHeaderText: ev.target.value })} />
            <p className="mb-3 text-sm text-muted">轮询应返回 {"{ events: [{ id, channel, userId, groupId, text, atBot }] }"}。发送使用 POST，正文含 channel、userId、groupId、text。DSH 本身没有这个固定接口，不能假装已经接上。</p>
          </>
        )}
        <FieldLabel>回复用人设</FieldLabel>
        <select className="field mb-3" value={qq.personaId} onChange={(ev) => useJingyun.getState().setQq({ personaId: ev.target.value })}>
          {personas.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
        <div className="mb-3 space-y-2 text-sm">
          <label className="flex gap-2"><input type="checkbox" checked={qq.privateReply} onChange={(ev) => useJingyun.getState().setQq({ privateReply: ev.target.checked })} />私聊自动回复</label>
          <label className="flex gap-2"><input type="checkbox" checked={qq.groupReply} onChange={(ev) => useJingyun.getState().setQq({ groupReply: ev.target.checked })} />群聊自动回复</label>
          <label className="flex gap-2"><input type="checkbox" checked={qq.atOnly} onChange={(ev) => useJingyun.getState().setQq({ atOnly: ev.target.checked })} />群聊只在 @ 机器人时回复</label>
        </div>
        <FieldLabel>白名单，QQ 号或群号，空则不限制</FieldLabel>
        <input className="field mb-3" value={qq.whitelist} onChange={(ev) => useJingyun.getState().setQq({ whitelist: ev.target.value })} />
        <FieldLabel>黑名单</FieldLabel>
        <input className="field mb-3" value={qq.blacklist} onChange={(ev) => useJingyun.getState().setQq({ blacklist: ev.target.value })} />
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" onClick={() => startBot()}>启动</Button>
          <Button onClick={() => stopBot()}>停止</Button>
          <Button onClick={() => restartBot()}>重启</Button>
        </div>
      </Panel>
      <Panel>
        <h3 className="mb-2 font-medium">做不到的部分</h3>
        <ul className="list-disc space-y-1 pl-4 text-sm text-muted">
          <li>不能在应用里安装 Termux、PRoot Ubuntu 或拉起 NapCat。</li>
          <li>QQ 扫码登录发生在协议端，不在这里。</li>
          <li>反向 WebSocket（让协议端连进来）网页做不了稳定服务。</li>
          <li>要让回复走 DeepSeek Harness，把 DSH 的 OpenAI 兼容地址填进设置里的服务商，再选到人设上。</li>
        </ul>
      </Panel>
      <Panel>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="font-medium">日志</h3>
          <button type="button" className="text-sm text-muted" onClick={() => useJingyun.getState().clearQqLogs()}>清空</button>
        </div>
        <ul className="space-y-1 font-mono text-xs">
          {[...logs].reverse().slice(0, 40).map((log) => (
            <li key={log.id} className={log.level === "error" ? "text-danger" : "text-muted"}>
              {new Date(log.at).toLocaleTimeString()} {log.message}
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
