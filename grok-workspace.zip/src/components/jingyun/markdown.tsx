import type { ReactNode } from "react";

function inline(text: string): ReactNode[] {
  const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\[[^\]]+\]\(https?:\/\/[^)\s]+\))/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  let key = 0;
  while ((match = re.exec(text))) {
    if (match.index > last) nodes.push(text.slice(last, match.index));
    const token = match[0];
    if (token.startsWith("`")) nodes.push(<code key={key++} className="rounded-xs bg-bg px-1 font-mono text-[0.92em]">{token.slice(1, -1)}</code>);
    else if (token.startsWith("**")) nodes.push(<strong key={key++}>{token.slice(2, -2)}</strong>);
    else {
      const label = token.slice(1, token.indexOf("]"));
      const href = token.slice(token.indexOf("(") + 1, -1);
      nodes.push(
        <a key={key++} href={href} target="_blank" rel="noreferrer" className="underline decoration-focus underline-offset-2">
          {label}
        </a>,
      );
    }
    last = match.index + token.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

export function RichText({ text }: { text: string }) {
  const chunks = text.split("```");
  return (
    <div className="space-y-2 break-words">
      {chunks.map((chunk, index) => {
        if (index % 2 === 1) {
          const nl = chunk.indexOf("\n");
          const body = nl >= 0 && chunk.slice(0, nl).length < 16 ? chunk.slice(nl + 1) : chunk;
          return (
            <pre key={index} className="overflow-x-auto rounded-sm bg-bg p-3 font-mono text-sm leading-relaxed">
              {body.replace(/\n$/, "")}
            </pre>
          );
        }
        return chunk.split(/\n{2,}/).map((para, p) => (
          <p key={`${index}-${p}`} className="whitespace-pre-wrap">
            {inline(para)}
          </p>
        ));
      })}
    </div>
  );
}
