import type { ButtonHTMLAttributes, ReactNode } from "react";

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function WhaleMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path
        fill="currentColor"
        d="M5 18.5c.4-5.2 5.2-9.5 11.2-9.5 2.7 0 4.6.8 6.4.8 1.6 0 2.8-1.2 4.1-1.2 1.8 0 2.8 1.6 2.3 3.2-.7 2.2-2.6 3-3.4 4.6-.9 1.8-.4 4.1-2.2 5.6-2.2 1.8-5.2 2.5-8.2 2.2-4.6-.4-9.8-2.2-10.2-5.7Z"
      />
      <circle cx="22.2" cy="13.2" r="0.8" fill="var(--jy-bg)" />
    </svg>
  );
}

export function Button({
  variant = "ghost",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" }) {
  return <button type="button" className={cx("btn", `btn-${variant}`, className)} {...props} />;
}

export function Panel({ className, children }: { className?: string; children: ReactNode }) {
  return <section className={cx("panel p-4", className)}>{children}</section>;
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return <label className="mb-1 block text-sm font-medium text-muted">{children}</label>;
}
