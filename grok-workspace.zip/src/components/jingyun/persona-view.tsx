import { useEffect, useState } from "react";
import { Button, FieldLabel, Panel } from "@/components/jingyun/ui";
import { BUILTIN_ID, useJingyun } from "@/lib/jingyun/store";
import type { Persona } from "@/lib/jingyun/types";

export function PersonaView() {
  const personas = useJingyun((s) => s.personas);
  const providers = useJingyun((s) => s.providers);
  const activePersonaId = useJingyun((s) => s.activePersonaId);
  const [selected, setSelected] = useState(activePersonaId);
  const current = personas.find((item) => item.id === selected) ?? personas[0];
  const [draft, setDraft] = useState<Persona | null>(current ?? null);
  const [memoryText, setMemoryText] = useState("");
  const [editing, setEditing] = useState<string | null>(null);

  useEffect(() => {
    const next = useJingyun.getState().personas.find((item) => item.id === selected);
    if (next) setDraft({ ...next, memories: next.memories });
  }, [selected]);

  if (!current || !draft) return null;

  function create() {
    const id = crypto.randomUUID();
    const persona: Persona = {
      id,
      name: "新人设",
      personality: "",
      systemPrompt: "你是一个清楚、诚实的助手。",
      providerId: BUILTIN_ID,
      model: "grok-4.5",
      voiceURI: "",
      memories: [],
    };
    useJingyun.getState().upsertPersona(persona);
    setSelected(id);
  }

  const provider = providers.find((item) => item.id === draft.providerId) ?? providers[0];

  return (
    <div className="scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3">
      <div className="flex gap-2 overflow-x-auto">
        {personas.map((item) => (
          <button key={item.id} type="button" className="chip" aria-pressed={item.id === current.id} onClick={() => setSelected(item.id)}>
            {item.name}
          </button>
        ))}
        <Button onClick={create}>新建</Button>
      </div>
      <Panel>
        <FieldLabel>名字</FieldLabel>
        <input className="field mb-3" value={draft.name} onChange={(ev) => setDraft({ ...draft, name: ev.target.value })} />
        <FieldLabel>性格</FieldLabel>
        <input className="field mb-3" value={draft.personality} onChange={(ev) => setDraft({ ...draft, personality: ev.target.value })} />
        <FieldLabel>提示词</FieldLabel>
        <textarea className="field mb-3" value={draft.systemPrompt} onChange={(ev) => setDraft({ ...draft, systemPrompt: ev.target.value })} />
        <FieldLabel>服务商</FieldLabel>
        <select
          className="field mb-3"
          value={draft.providerId}
          onChange={(ev) => {
            const next = providers.find((item) => item.id === ev.target.value);
            setDraft({ ...draft, providerId: ev.target.value, model: next?.models[0] || draft.model });
          }}
        >
          {providers.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
        <FieldLabel>模型</FieldLabel>
        <select className="field mb-3" value={draft.model} onChange={(ev) => setDraft({ ...draft, model: ev.target.value })}>
          {(provider?.models.length ? provider.models : [draft.model]).map((model) => <option key={model} value={model}>{model}</option>)}
        </select>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="primary"
            onClick={() => useJingyun.getState().upsertPersona({ ...draft, memories: current.memories })}
          >
            保存人设
          </Button>
          <Button variant="danger" onClick={() => useJingyun.getState().removePersona(current.id)}>删除</Button>
        </div>
      </Panel>
      <Panel>
        <h2 className="mb-2 text-lg font-medium">长期记忆</h2>
        <p className="mb-3 text-sm text-muted">只属于这个人设。对话里点「记入记忆」也会写到这里。</p>
        <div className="mb-3 flex gap-2">
          <input className="field" value={memoryText} placeholder="写一条要记住的事实" onChange={(ev) => setMemoryText(ev.target.value)} />
          <Button
            variant="primary"
            onClick={() => {
              if (!memoryText.trim()) return;
              useJingyun.getState().addMemory(current.id, memoryText.trim());
              setMemoryText("");
            }}
          >
            添加
          </Button>
        </div>
        <ul className="space-y-2">
          {current.memories.length === 0 ? <li className="text-sm text-muted">还没有记忆。</li> : null}
          {current.memories.map((memory) => (
            <li key={memory.id} className="rounded-sm border border-line p-2">
              {editing === memory.id ? (
                <input
                  className="field"
                  defaultValue={memory.text}
                  onBlur={(ev) => {
                    useJingyun.getState().updateMemory(current.id, { ...memory, text: ev.target.value });
                    setEditing(null);
                  }}
                />
              ) : (
                <p className="text-sm">{memory.text}</p>
              )}
              <div className="mt-2 flex gap-2">
                <button type="button" className="text-sm text-muted" onClick={() => setEditing(memory.id)}>编辑</button>
                <button type="button" className="text-sm text-danger" onClick={() => useJingyun.getState().removeMemory(current.id, memory.id)}>删除</button>
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
