import { Box, Layers, MessageCircle, Settings, UserRound } from "lucide-react";
import { useEffect } from "react";
import { ChatView } from "@/components/jingyun/chat-view";
import { HoloView } from "@/components/jingyun/holo-view";
import { LabView } from "@/components/jingyun/lab-view";
import { PersonaView } from "@/components/jingyun/persona-view";
import { SettingsView } from "@/components/jingyun/settings-view";
import { WhaleMark, cx } from "@/components/jingyun/ui";
import { apiUrl } from "@/lib/jingyun/api-url";
import { useJingyun } from "@/lib/jingyun/store";
import type { ViewId } from "@/lib/jingyun/types";

const NAV: { id: ViewId; label: string; icon: typeof MessageCircle }[] = [
  { id: "chat", label: "对话", icon: MessageCircle },
  { id: "persona", label: "人设", icon: UserRound },
  { id: "holo", label: "全息", icon: Box },
  { id: "lab", label: "能力", icon: Layers },
  { id: "settings", label: "设置", icon: Settings },
];

export function App() {
  const view = useJingyun((s) => s.view);
  const theme = useJingyun((s) => s.theme);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    void useJingyun.persist.rehydrate();
    void fetch(apiUrl("/api/ai/status"))
      .then((res) => res.json())
      .then((data: { builtin?: boolean }) => useJingyun.getState().setBuiltinReady(Boolean(data.builtin)))
      .catch(() => useJingyun.getState().setBuiltinReady(false));
  }, []);

  return (
    <div className="mx-auto flex h-dvh max-w-6xl">
      <aside className="hidden w-52 shrink-0 flex-col border-r border-line px-3 py-4 md:flex">
        <div className="mb-6 flex items-center gap-2 px-2">
          <WhaleMark className="size-8 text-fg" />
          <div>
            <p className="text-lg font-medium leading-tight">鲸云</p>
            <p className="text-xs text-subtle">JingYun</p>
          </div>
        </div>
        {NAV.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              className={cx("mb-1 flex min-h-11 items-center gap-2 rounded-sm px-3 text-left", view === item.id ? "bg-accent text-accent-fg" : "text-muted")}
              onClick={() => useJingyun.getState().setView(item.id)}
            >
              <Icon className="size-5" aria-hidden="true" />
              {item.label}
            </button>
          );
        })}
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-line px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 md:hidden">
          <WhaleMark className="size-7 text-fg" />
          <p className="font-medium">鲸云</p>
        </header>
        <main className="flex min-h-0 flex-1 flex-col">
          <div className={view === "chat" ? "flex min-h-0 flex-1 flex-col" : "hidden"}><ChatView /></div>
          {view === "persona" ? <PersonaView /> : null}
          {view === "holo" ? <HoloView /> : null}
          <div className={view === "lab" ? "flex min-h-0 flex-1 flex-col" : "hidden"}><LabView /></div>
          {view === "settings" ? <SettingsView /> : null}
        </main>
        <nav className="grid grid-cols-5 border-t border-line pb-[env(safe-area-inset-bottom)] md:hidden" aria-label="主要">
          {NAV.map((item) => {
            const Icon = item.icon;
            const on = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className={cx("flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs", on ? "text-fg" : "text-subtle")}
                onClick={() => useJingyun.getState().setView(item.id)}
              >
                <Icon className="size-5" aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
