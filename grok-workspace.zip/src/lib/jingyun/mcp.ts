import { apiUrl } from "@/lib/jingyun/api-url";
import type { McpServer, McpTool } from "@/lib/jingyun/types";

function headersFrom(text: string): Record<string, string> {
  const headers: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    const i = line.indexOf(":");
    if (i < 1) continue;
    headers[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return headers;
}

async function rpc(server: Pick<McpServer, "url" | "headerText">, method: string, params: unknown, id?: number): Promise<unknown> {
  const payload = id === undefined ? { jsonrpc: "2.0", method, params } : { jsonrpc: "2.0", id, method, params };
  const res = await fetch(apiUrl("/api/mcp"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: server.url, headers: headersFrom(server.headerText), rpc: payload }),
  });
  const json = (await res.json()) as { ok?: boolean; error?: string; json?: { error?: { message?: string }; result?: unknown } | null };
  if (!res.ok || json.ok === false) throw new Error(json.error || "MCP 请求失败");
  const envelope = json.json;
  if (!envelope || typeof envelope !== "object") throw new Error("MCP 没有返回 JSON");
  if ("error" in envelope && envelope.error) throw new Error(envelope.error.message || "MCP 拒绝了请求");
  return "result" in envelope ? envelope.result : envelope;
}

export async function discoverTools(server: Pick<McpServer, "url" | "headerText">): Promise<McpTool[]> {
  await rpc(
    server,
    "initialize",
    {
      protocolVersion: "2024-11-05",
      capabilities: {},
      clientInfo: { name: "jingyun", version: "1.0.0" },
    },
    1,
  );
  await rpc(server, "notifications/initialized", {}).catch(() => undefined);
  const result = (await rpc(server, "tools/list", {}, 2)) as { tools?: McpTool[] };
  return (result.tools ?? []).map((tool) => ({
    name: tool.name,
    description: tool.description || "",
    inputSchema: tool.inputSchema ?? { type: "object", properties: {} },
  }));
}

export async function callTool(server: Pick<McpServer, "url" | "headerText">, name: string, args: unknown): Promise<string> {
  const result = (await rpc(server, "tools/call", { name, arguments: args }, Date.now() % 1_000_000)) as {
    content?: { type?: string; text?: string }[];
    isError?: boolean;
  };
  if (Array.isArray(result?.content)) {
    const text = result.content.map((item) => item.text || JSON.stringify(item)).join("\n");
    return text.slice(0, 8000) || (result.isError ? "工具返回了错误" : "工具没有返回文字");
  }
  return JSON.stringify(result).slice(0, 8000);
}

export function toolFunctionName(tool: string): string {
  const clean = tool.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 60);
  return clean || "tool";
}
