const PREFIX = "enc:v1:";
const DEVICE_KEY = "jingyun-device-key";

function b64(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}

function unb64(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function idb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("jingyun", 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains("kv")) req.result.createObjectStore("kv");
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGet(key: string): Promise<string | null> {
  if (typeof indexedDB === "undefined") return null;
  const db = await idb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("kv", "readonly");
    const req = tx.objectStore("kv").get(key);
    req.onsuccess = () => resolve((req.result as string | undefined) ?? null);
    req.onerror = () => reject(req.error);
  });
}

async function idbSet(key: string, value: string): Promise<void> {
  if (typeof indexedDB === "undefined") return;
  const db = await idb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction("kv", "readwrite");
    tx.objectStore("kv").put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

let keyPromise: Promise<CryptoKey> | null = null;

async function deviceKey(): Promise<CryptoKey> {
  if (!keyPromise) keyPromise = loadDeviceKey();
  return keyPromise;
}

async function loadDeviceKey(): Promise<CryptoKey> {
  const existing = await idbGet(DEVICE_KEY);
  if (existing) {
    const raw = unb64(existing);
    return crypto.subtle.importKey("raw", raw.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt", "decrypt"]);
  }
  const raw = crypto.getRandomValues(new Uint8Array(32));
  await idbSet(DEVICE_KEY, b64(raw));
  return crypto.subtle.importKey("raw", raw.buffer as ArrayBuffer, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function seal(plain: string): Promise<string> {
  if (!plain) return "";
  if (plain.startsWith(PREFIX)) return plain;
  const key = await deviceKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plain),
  );
  return `${PREFIX}${b64(iv)}.${b64(new Uint8Array(cipher))}`;
}

export async function openSecret(stored: string): Promise<string> {
  if (!stored) return "";
  if (!stored.startsWith(PREFIX)) return stored;
  const body = stored.slice(PREFIX.length);
  const [ivB, dataB] = body.split(".");
  if (!ivB || !dataB) return "";
  try {
    const key = await deviceKey();
    const iv = unb64(ivB);
    const data = unb64(dataB);
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
      key,
      data.buffer as ArrayBuffer,
    );
    return new TextDecoder().decode(plain);
  } catch {
    return "";
  }
}

async function derive(passphrase: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(passphrase), "PBKDF2", false, [
    "deriveKey",
  ]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: salt.buffer as ArrayBuffer, iterations, hash: "SHA-256" },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

export async function encryptJson(value: unknown, passphrase: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const iterations = 100_000;
  const key = await derive(passphrase, salt, iterations);
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(JSON.stringify(value)),
  );
  return JSON.stringify({
    format: "jingyun-backup",
    v: 1,
    kdf: "pbkdf2-aes-gcm",
    iterations,
    salt: b64(salt),
    iv: b64(iv),
    data: b64(new Uint8Array(cipher)),
  });
}

export async function decryptJson(text: string, passphrase: string): Promise<unknown> {
  const parsed = JSON.parse(text) as {
    format?: string;
    kdf?: string;
    iterations?: number;
    salt?: string;
    iv?: string;
    data?: string;
    state?: unknown;
  };
  if (parsed.format !== "jingyun-backup") throw new Error("这不是鲸云备份文件");
  if (parsed.kdf === "none") return parsed.state;
  if (!parsed.salt || !parsed.iv || !parsed.data) throw new Error("备份缺少加密字段");
  const key = await derive(passphrase, unb64(parsed.salt), parsed.iterations || 100_000);
  const iv = unb64(parsed.iv);
  const data = unb64(parsed.data);
  try {
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
      key,
      data.buffer as ArrayBuffer,
    );
    return JSON.parse(new TextDecoder().decode(plain));
  } catch {
    throw new Error("口令不对，或文件已损坏");
  }
}
