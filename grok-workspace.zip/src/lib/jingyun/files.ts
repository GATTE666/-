import type { Attachment } from "@/lib/jingyun/types";

const TEXT_EXT = new Set(["txt", "md", "markdown", "csv", "json", "log"]);

function ext(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

export async function compressImage(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("图片无法读取"));
      el.src = url;
    });
    const max = 1280;
    const scale = Math.min(1, max / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("无法处理图片");
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.72);
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function pdfText(buf: ArrayBuffer): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const worker = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")) as { default: string };
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buf) }).promise;
  const pages: string[] = [];
  const count = Math.min(doc.numPages, 30);
  for (let i = 1; i <= count; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const line = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (line) pages.push(line);
  }
  return pages.join("\n\n");
}

async function docxText(buf: ArrayBuffer): Promise<string> {
  const mod = await import("mammoth");
  const mammoth = (mod.default ?? mod) as {
    extractRawText: (input: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string }>;
  };
  const result = await mammoth.extractRawText({ arrayBuffer: buf });
  return result.value || "";
}

export async function fileToAttachment(file: File): Promise<Attachment> {
  if (file.size > 15 * 1024 * 1024) throw new Error(`${file.name} 超过 15MB`);
  const id = crypto.randomUUID();
  const kind = file.type.startsWith("image/") ? "image" : "text";
  if (kind === "image") {
    return { id, name: file.name, kind, dataUrl: await compressImage(file) };
  }
  const extension = ext(file.name);
  if (extension === "doc") throw new Error("旧版 .doc 不能直接读，请另存为 .docx");
  let text = "";
  if (extension === "pdf") text = await pdfText(await file.arrayBuffer());
  else if (extension === "docx") text = await docxText(await file.arrayBuffer());
  else if (TEXT_EXT.has(extension) || file.type.startsWith("text/")) text = await file.text();
  else throw new Error(`还不支持 ${file.name}。可用 TXT、Markdown、PDF、DOCX 和常见图片。`);
  text = text.replace(/\u0000/g, "").trim();
  if (!text) throw new Error(`${file.name} 里没有读出文字`);
  if (text.length > 20_000) text = `${text.slice(0, 20_000)}\n\n[已截断，只保留前 20000 字]`;
  return { id, name: file.name, kind: "text", text };
}
