export type ThemeId = "tide" | "day" | "ink";
export type Transport = "proxy" | "direct";
export type ToolPermission = "ask" | "allow" | "deny";
export type ViewId = "chat" | "persona" | "holo" | "lab" | "settings";
export type LabTab = "search" | "image" | "files" | "mcp" | "qq";
export type TurnMode = "write" | "code" | "translate" | null;
export type HoloAction = "idle" | "wave" | "think" | "smile" | "surprise";
export type BotAdapterId = "onebot11" | "http";

export type Provider = {
  id: string;
  name: string;
  kind: "builtin" | "openai";
  baseUrl: string;
  apiKey: string;
  models: string[];
  imageModel: string;
  transport: Transport;
};

export type Memory = {
  id: string;
  text: string;
  createdAt: number;
};

export type Persona = {
  id: string;
  name: string;
  personality: string;
  systemPrompt: string;
  providerId: string;
  model: string;
  voiceURI: string;
  memories: Memory[];
};

export type Attachment = {
  id: string;
  name: string;
  kind: "image" | "text";
  text?: string;
  dataUrl?: string;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "tool";
  content: string;
  attachments?: Attachment[];
  model?: string;
  providerId?: string;
  compareKey?: "a" | "b";
  createdAt: number;
  pending?: boolean;
  error?: string;
  toolName?: string;
};

export type Session = {
  id: string;
  title: string;
  personaId: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  origin?: { type: "qq"; peer: string };
};

export type McpTool = {
  name: string;
  description: string;
  inputSchema: unknown;
};

export type McpServer = {
  id: string;
  name: string;
  url: string;
  headerText: string;
  enabled: boolean;
  tools: McpTool[];
  toolPermission: Record<string, ToolPermission>;
};

export type ToolLog = {
  id: string;
  at: number;
  server: string;
  tool: string;
  args: string;
  result: string;
  ok: boolean;
};

export type QqConfig = {
  adapter: BotAdapterId;
  wsUrl: string;
  accessToken: string;
  pollUrl: string;
  sendUrl: string;
  httpHeaderText: string;
  privateReply: boolean;
  groupReply: boolean;
  atOnly: boolean;
  whitelist: string;
  blacklist: string;
  personaId: string;
};

export type QqLog = {
  id: string;
  at: number;
  level: "info" | "error";
  message: string;
};

export type BotStatus = {
  state: "stopped" | "connecting" | "online" | "error";
  detail: string;
  selfId?: string;
  nickname?: string;
};

export type SearchProvider = "wiki" | "tavily" | "brave" | "serper" | "custom";

export type SearchConfig = {
  provider: SearchProvider;
  apiKey: string;
  endpoint: string;
};

export type VoiceConfig = {
  rate: number;
  pitch: number;
  voiceURI: string;
};

export type PendingTool = {
  id: string;
  serverName: string;
  tool: string;
  args: string;
};

export type Persisted = {
  theme: ThemeId;
  providers: Provider[];
  personas: Persona[];
  sessions: Session[];
  activePersonaId: string;
  activeSessionId: string;
  mcpServers: McpServer[];
  toolLogs: ToolLog[];
  qq: QqConfig;
  qqLogs: QqLog[];
  search: SearchConfig;
  voice: VoiceConfig;
  maxTokens: number;
  holoFollow: boolean;
};
