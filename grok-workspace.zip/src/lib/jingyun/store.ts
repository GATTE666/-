import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { openSecret, seal } from "@/lib/jingyun/crypto";
import { kvGet, kvSet } from "@/lib/jingyun/idb";
import type {
  BotStatus,
  HoloAction,
  LabTab,
  McpServer,
  Memory,
  PendingTool,
  Persisted,
  Persona,
  Provider,
  QqConfig,
  QqLog,
  SearchConfig,
  Session,
  ThemeId,
  ToolLog,
  ViewId,
  VoiceConfig,
  ChatMessage,
} from "@/lib/jingyun/types";

export const BUILTIN_ID = "builtin";

const now = () => Date.now();

function seed(): Persisted {
  const personaId = "persona-jingyun";
  const coderId = "persona-coder";
  const sessionId = "session-welcome";
  const t = now();
  return {
    theme: "tide",
    providers: [
      {
        id: BUILTIN_ID,
        name: "内置 Grok",
        kind: "builtin",
        baseUrl: "https://api.x.ai/v1",
        apiKey: "",
        models: ["grok-4.5"],
        imageModel: "grok-imagine-image",
        transport: "proxy",
      },
    ],
    personas: [
      {
        id: personaId,
        name: "鲸云",
        personality: "克制、清楚，先给结论",
        systemPrompt:
          "你是鲸云，一个冷静可靠的中文全能助手。先给结论，再补充必要细节。代码要能运行。不确定就直说。不要假装调用了你没有的工具，也不要编造来源。",
        providerId: BUILTIN_ID,
        model: "grok-4.5",
        voiceURI: "",
        memories: [],
      },
      {
        id: coderId,
        name: "工程搭档",
        personality: "直接、较真、少客套",
        systemPrompt:
          "你是工程搭档。优先给出可运行的实现和失败时怎么查。指出风险，不堆砌概念。默认用中文解释，代码和标识符保持原文。",
        providerId: BUILTIN_ID,
        model: "grok-4.5",
        voiceURI: "",
        memories: [],
      },
    ],
    sessions: [
      {
        id: sessionId,
        title: "开始",
        personaId,
        createdAt: t,
        updatedAt: t,
        messages: [
          {
            id: "welcome",
            role: "assistant",
            content:
              "我是鲸云。可以直接对话、写作、编程和翻译。\n\n人设和长期记忆在「人设」。全息舱里的角色可以旋转、缩放，也会跟着说话。搜索、文件、绘图、MCP 和 QQ 在「能力」。密钥只留在这台设备上。",
            createdAt: t,
            model: "grok-4.5",
            providerId: BUILTIN_ID,
          },
        ],
      },
    ],
    activePersonaId: personaId,
    activeSessionId: sessionId,
    mcpServers: [],
    toolLogs: [],
    qq: {
      adapter: "onebot11",
      wsUrl: "",
      accessToken: "",
      pollUrl: "",
      sendUrl: "",
      httpHeaderText: "",
      privateReply: true,
      groupReply: true,
      atOnly: true,
      whitelist: "",
      blacklist: "",
      personaId,
    },
    qqLogs: [],
    search: { provider: "wiki", apiKey: "", endpoint: "" },
    voice: { rate: 1, pitch: 1, voiceURI: "" },
    maxTokens: 800,
    holoFollow: true,
  };
}

type Runtime = {
  hydrated: boolean;
  view: ViewId;
  labTab: LabTab;
  compare: boolean;
  compareProviderId: string;
  compareModel: string;
  toolsArmed: boolean;
  generating: boolean;
  speaking: boolean;
  holoAction: HoloAction;
  builtinReady: boolean | null;
  qqStatus: BotStatus;
  pendingTool: PendingTool | null;
};

type Actions = {
  setHydrated: (v: boolean) => void;
  setView: (view: ViewId) => void;
  setLabTab: (tab: LabTab) => void;
  setTheme: (theme: ThemeId) => void;
  setBuiltinReady: (v: boolean) => void;
  setCompare: (v: boolean) => void;
  setCompareTarget: (providerId: string, model: string) => void;
  setToolsArmed: (v: boolean) => void;
  setGenerating: (v: boolean) => void;
  setSpeaking: (v: boolean) => void;
  setHoloAction: (action: HoloAction) => void;
  setHoloFollow: (v: boolean) => void;
  setMaxTokens: (n: number) => void;
  setVoice: (patch: Partial<VoiceConfig>) => void;
  setSearch: (patch: Partial<SearchConfig>) => void;
  setQq: (patch: Partial<QqConfig>) => void;
  setQqStatus: (status: BotStatus) => void;
  pushQqLog: (level: QqLog["level"], message: string) => void;
  clearQqLogs: () => void;
  upsertProvider: (provider: Provider) => void;
  removeProvider: (id: string) => void;
  upsertPersona: (persona: Persona) => void;
  removePersona: (id: string) => void;
  addMemory: (personaId: string, text: string) => void;
  updateMemory: (personaId: string, memory: Memory) => void;
  removeMemory: (personaId: string, memoryId: string) => void;
  newSession: (personaId?: string) => string;
  selectSession: (id: string) => void;
  renameSession: (id: string, title: string) => void;
  removeSession: (id: string) => void;
  clearSession: (id: string) => void;
  setSessionPersona: (id: string, personaId: string) => void;
  appendMessage: (sessionId: string, message: ChatMessage) => void;
  patchMessage: (sessionId: string, messageId: string, patch: Partial<ChatMessage>) => void;
  findOrCreateQqSession: (peer: string, title: string, personaId: string) => string;
  upsertMcp: (server: McpServer) => void;
  removeMcp: (id: string) => void;
  pushToolLog: (log: ToolLog) => void;
  setPendingTool: (tool: PendingTool | null) => void;
  replacePersisted: (data: Persisted) => void;
  snapshot: () => Persisted;
};

export type JingyunStore = Persisted & Runtime & Actions;

const initial = seed();

async function sealState(raw: string): Promise<string> {
  const wrapped = JSON.parse(raw) as { state: Persisted; version?: number };
  const state = structuredClone(wrapped.state);
  state.providers = await Promise.all(
    state.providers.map(async (item) => ({ ...item, apiKey: await seal(item.apiKey) })),
  );
  state.search = { ...state.search, apiKey: await seal(state.search.apiKey) };
  state.qq = { ...state.qq, accessToken: await seal(state.qq.accessToken) };
  wrapped.state = state;
  return JSON.stringify(wrapped);
}

async function openState(raw: string): Promise<string> {
  const wrapped = JSON.parse(raw) as { state: Persisted; version?: number };
  const state = wrapped.state;
  state.providers = await Promise.all(
    (state.providers ?? []).map(async (item) => ({ ...item, apiKey: await openSecret(item.apiKey || "") })),
  );
  if (state.search) state.search.apiKey = await openSecret(state.search.apiKey || "");
  if (state.qq) state.qq.accessToken = await openSecret(state.qq.accessToken || "");
  wrapped.state = state;
  return JSON.stringify(wrapped);
}

let writeChain: Promise<void> = Promise.resolve();

const storage = {
  getItem: async (name: string) => {
    const raw = await kvGet(name);
    if (!raw) return null;
    try {
      return await openState(raw);
    } catch {
      return null;
    }
  },
  setItem: async (name: string, value: string) => {
    writeChain = writeChain.then(async () => {
      await kvSet(name, await sealState(value));
    });
    await writeChain;
  },
  removeItem: async (name: string) => {
    await kvSet(name, "");
  },
};

function trimLogs<T>(items: T[], max = 120): T[] {
  return items.length > max ? items.slice(items.length - max) : items;
}

export const useJingyun = create<JingyunStore>()(
  persist(
    (set, get) => ({
      ...initial,
      hydrated: false,
      view: "chat",
      labTab: "search",
      compare: false,
      compareProviderId: BUILTIN_ID,
      compareModel: "grok-4.5",
      toolsArmed: false,
      generating: false,
      speaking: false,
      holoAction: "idle",
      builtinReady: null,
      qqStatus: { state: "stopped", detail: "未连接" },
      pendingTool: null,
      setHydrated: (hydrated) => set({ hydrated }),
      setView: (view) => set({ view }),
      setLabTab: (labTab) => set({ labTab, view: "lab" }),
      setTheme: (theme) => set({ theme }),
      setBuiltinReady: (builtinReady) => set({ builtinReady }),
      setCompare: (compare) => set({ compare }),
      setCompareTarget: (compareProviderId, compareModel) => set({ compareProviderId, compareModel }),
      setToolsArmed: (toolsArmed) => set({ toolsArmed }),
      setGenerating: (generating) => set({ generating }),
      setSpeaking: (speaking) => set({ speaking }),
      setHoloAction: (holoAction) => set({ holoAction }),
      setHoloFollow: (holoFollow) => set({ holoFollow }),
      setMaxTokens: (maxTokens) => set({ maxTokens }),
      setVoice: (patch) => set({ voice: { ...get().voice, ...patch } }),
      setSearch: (patch) => set({ search: { ...get().search, ...patch } }),
      setQq: (patch) => set({ qq: { ...get().qq, ...patch } }),
      setQqStatus: (qqStatus) => set({ qqStatus }),
      pushQqLog: (level, message) =>
        set({
          qqLogs: trimLogs([...get().qqLogs, { id: crypto.randomUUID(), at: now(), level, message }]),
        }),
      clearQqLogs: () => set({ qqLogs: [] }),
      upsertProvider: (provider) =>
        set({
          providers: get().providers.some((item) => item.id === provider.id)
            ? get().providers.map((item) => (item.id === provider.id ? provider : item))
            : [...get().providers, provider],
        }),
      removeProvider: (id) => {
        if (id === BUILTIN_ID) return;
        set({ providers: get().providers.filter((item) => item.id !== id) });
      },
      upsertPersona: (persona) =>
        set({
          personas: get().personas.some((item) => item.id === persona.id)
            ? get().personas.map((item) => (item.id === persona.id ? persona : item))
            : [...get().personas, persona],
          activePersonaId: persona.id,
        }),
      removePersona: (id) => {
        const personas = get().personas.filter((item) => item.id !== id);
        if (!personas.length) return;
        set({
          personas,
          activePersonaId: get().activePersonaId === id ? personas[0].id : get().activePersonaId,
        });
      },
      addMemory: (personaId, text) =>
        set({
          personas: get().personas.map((item) =>
            item.id === personaId
              ? { ...item, memories: [...item.memories, { id: crypto.randomUUID(), text, createdAt: now() }] }
              : item,
          ),
        }),
      updateMemory: (personaId, memory) =>
        set({
          personas: get().personas.map((item) =>
            item.id === personaId
              ? { ...item, memories: item.memories.map((entry) => (entry.id === memory.id ? memory : entry)) }
              : item,
          ),
        }),
      removeMemory: (personaId, memoryId) =>
        set({
          personas: get().personas.map((item) =>
            item.id === personaId ? { ...item, memories: item.memories.filter((entry) => entry.id !== memoryId) } : item,
          ),
        }),
      newSession: (personaId) => {
        const id = crypto.randomUUID();
        const t = now();
        const session: Session = {
          id,
          title: "新的对话",
          personaId: personaId || get().activePersonaId,
          createdAt: t,
          updatedAt: t,
          messages: [],
        };
        set({ sessions: [session, ...get().sessions], activeSessionId: id, activePersonaId: session.personaId });
        return id;
      },
      selectSession: (id) => {
        const session = get().sessions.find((item) => item.id === id);
        set({ activeSessionId: id, activePersonaId: session?.personaId || get().activePersonaId });
      },
      renameSession: (id, title) =>
        set({
          sessions: get().sessions.map((item) => (item.id === id ? { ...item, title, updatedAt: now() } : item)),
        }),
      removeSession: (id) => {
        const sessions = get().sessions.filter((item) => item.id !== id);
        if (!sessions.length) {
          const t = now();
          const sid = crypto.randomUUID();
          set({
            sessions: [
              {
                id: sid,
                title: "新的对话",
                personaId: get().activePersonaId,
                createdAt: t,
                updatedAt: t,
                messages: [],
              },
            ],
            activeSessionId: sid,
          });
          return;
        }
        set({
          sessions,
          activeSessionId: get().activeSessionId === id ? sessions[0].id : get().activeSessionId,
        });
      },
      clearSession: (id) =>
        set({
          sessions: get().sessions.map((item) =>
            item.id === id ? { ...item, messages: [], updatedAt: now() } : item,
          ),
        }),
      setSessionPersona: (id, personaId) =>
        set({
          activePersonaId: personaId,
          sessions: get().sessions.map((item) => (item.id === id ? { ...item, personaId, updatedAt: now() } : item)),
        }),
      appendMessage: (sessionId, message) =>
        set({
          sessions: get().sessions.map((item) =>
            item.id === sessionId
              ? { ...item, updatedAt: now(), messages: [...item.messages, message].slice(-200) }
              : item,
          ),
        }),
      patchMessage: (sessionId, messageId, patch) =>
        set({
          sessions: get().sessions.map((item) =>
            item.id === sessionId
              ? {
                  ...item,
                  updatedAt: now(),
                  messages: item.messages.map((message) => (message.id === messageId ? { ...message, ...patch } : message)),
                }
              : item,
          ),
        }),
      findOrCreateQqSession: (peer, title, personaId) => {
        const existing = get().sessions.find((item) => item.origin?.type === "qq" && item.origin.peer === peer);
        if (existing) return existing.id;
        const id = crypto.randomUUID();
        const t = now();
        const session: Session = {
          id,
          title,
          personaId,
          createdAt: t,
          updatedAt: t,
          messages: [],
          origin: { type: "qq", peer },
        };
        set({ sessions: [session, ...get().sessions] });
        return id;
      },
      upsertMcp: (server) =>
        set({
          mcpServers: get().mcpServers.some((item) => item.id === server.id)
            ? get().mcpServers.map((item) => (item.id === server.id ? server : item))
            : [...get().mcpServers, server],
        }),
      removeMcp: (id) => set({ mcpServers: get().mcpServers.filter((item) => item.id !== id) }),
      pushToolLog: (log) => set({ toolLogs: trimLogs([...get().toolLogs, log]) }),
      setPendingTool: (pendingTool) => set({ pendingTool }),
      replacePersisted: (data) => set({ ...data }),
      snapshot: () => {
        const s = get();
        return {
          theme: s.theme,
          providers: s.providers,
          personas: s.personas,
          sessions: s.sessions,
          activePersonaId: s.activePersonaId,
          activeSessionId: s.activeSessionId,
          mcpServers: s.mcpServers,
          toolLogs: s.toolLogs,
          qq: s.qq,
          qqLogs: s.qqLogs,
          search: s.search,
          voice: s.voice,
          maxTokens: s.maxTokens,
          holoFollow: s.holoFollow,
        };
      },
    }),
    {
      name: "jingyun",
      skipHydration: true,
      storage: createJSONStorage(() => storage),
      partialize: (state) => ({
        theme: state.theme,
        providers: state.providers,
        personas: state.personas,
        sessions: state.sessions,
        activePersonaId: state.activePersonaId,
        activeSessionId: state.activeSessionId,
        mcpServers: state.mcpServers,
        toolLogs: state.toolLogs,
        qq: state.qq,
        qqLogs: state.qqLogs,
        search: state.search,
        voice: state.voice,
        maxTokens: state.maxTokens,
        holoFollow: state.holoFollow,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

export function personaById(id: string): Persona | undefined {
  return useJingyun.getState().personas.find((item) => item.id === id);
}

export function providerById(id: string): Provider | undefined {
  return useJingyun.getState().providers.find((item) => item.id === id);
}
