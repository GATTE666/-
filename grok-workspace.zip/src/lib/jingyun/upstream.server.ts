const PRIVATE =
  /^(localhost|.*\.localhost|.*\.local|metadata\.google\.internal|0\.0\.0\.0|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|169\.254\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+)$/i;

export function assertPublicUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("地址不是合法的 URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("只允许 http 或 https");
  if (url.username || url.password) throw new Error("不要把账号写进地址");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  if (PRIVATE.test(host) || host === "::1" || host.toLowerCase().startsWith("fe80:") || host.toLowerCase().startsWith("fc") || host.toLowerCase().startsWith("fd")) {
    throw new Error("服务器不能访问内网或本机地址。本地接口请改用「浏览器直连」。");
  }
  return url;
}

export function chatCompletionsUrl(baseUrl: string): string {
  let base = baseUrl.trim().replace(/\/+$/, "");
  if (base.endsWith("/chat/completions")) return base;
  return `${base}/chat/completions`;
}

export function imageGenerationsUrl(baseUrl: string): string {
  let base = baseUrl.trim().replace(/\/+$/, "");
  if (base.endsWith("/images/generations")) return base;
  if (base.endsWith("/chat/completions")) base = base.slice(0, -"/chat/completions".length);
  return `${base}/images/generations`;
}

export function builtinKey(): string | null {
  const key = process.env.XAI_API_KEY;
  return key && key.trim() ? key.trim() : null;
}

export type ChatTurn = {
  role: string;
  content: unknown;
  tool_call_id?: string;
  tool_calls?: unknown;
};

export async function postUpstream(
  url: string,
  apiKey: string,
  body: unknown,
  signal: AbortSignal,
): Promise<Response> {
  return fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    signal,
  });
}

export function clampTokens(n: unknown, builtin: boolean): number {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.floor(n) : builtin ? 800 : 1200;
  return Math.max(64, Math.min(v, builtin ? 800 : 4096));
}

export function errorText(status: number, body: string): string {
  const clean = body.replace(/\s+/g, " ").slice(0, 420);
  return `上游返回 ${status}${clean ? `：${clean}` : ""}`;
}
