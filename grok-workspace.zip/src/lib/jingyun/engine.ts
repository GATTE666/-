import { completeChat, streamChat, type ApiMessage, type ChatRequest } from "@/lib/jingyun/chat-client";
import { callTool, toolFunctionName } from "@/lib/jingyun/mcp";
import { personaById, providerById, useJingyun } from "@/lib/jingyun/store";
import type { Attachment, ChatMessage, Persona, Provider, Session, TurnMode } from "@/lib/jingyun/types";

const MODE: Record<Exclude<TurnMode, null>, string> = {
  write: "这一轮是写作。给出可以直接使用的成稿，语言跟随用户。",
  code: "这一轮是编程。给出能运行的代码，并简短说明如何运行。不要省略关键部分。",
  translate: "这一轮是翻译。保留专名。用户没指定目标语言时译成中文。",
};

let toolWait: ((ok: boolean) => void) | null = null;
let activeAbort: AbortController | null = null;
const qqStamps: number[] = [];

export function stopGeneration(): void {
  activeAbort?.abort();
}

export function decideTool(ok: boolean): void {
  const wait = toolWait;
  toolWait = null;
  useJingyun.getState().setPendingTool(null);
  wait?.(ok);
}

function providerRequest(provider: Provider, model: string): Pick<ChatRequest, "mode" | "baseUrl" | "apiKey" | "model"> {
  if (provider.kind === "builtin") return { mode: "builtin", model: "grok-4.5" };
  return {
    mode: provider.transport === "direct" ? "direct" : "proxy",
    baseUrl: provider.baseUrl,
    apiKey: provider.apiKey,
    model,
  };
}

function visibleHistory(session: Session): ChatMessage[] {
  return session.messages.filter(
    (message) => message.role !== "tool" && !message.pending && !message.error && (message.content || message.attachments?.length),
  );
}

function toApi(persona: Persona, history: ChatMessage[], mode: TurnMode): ApiMessage[] {
  const memories = persona.memories.map((item) => `- ${item.text}`).join("\n");
  const system = [
    persona.systemPrompt,
    persona.personality ? `性格：${persona.personality}` : "",
    memories ? `长期记忆（用户可更正）：\n${memories}` : "",
    mode ? MODE[mode] : "",
  ]
    .filter(Boolean)
    .join("\n\n");
  const messages: ApiMessage[] = [{ role: "system", content: system }];
  for (const message of history.slice(-20)) {
    if (message.role === "user") {
      const files = (message.attachments ?? [])
        .filter((item) => item.kind === "text" && item.text)
        .map((item) => `【文件 ${item.name}】\n${item.text}`)
        .join("\n\n");
      const text = [message.content, files].filter(Boolean).join("\n\n") || "请看附件";
      const images = (message.attachments ?? []).filter((item) => item.kind === "image" && item.dataUrl);
      if (images.length) {
        messages.push({
          role: "user",
          content: [
            { type: "text", text },
            ...images.map((item) => ({ type: "image_url", image_url: { url: item.dataUrl } })),
          ],
        });
      } else {
        messages.push({ role: "user", content: text });
      }
    } else if (message.role === "assistant") {
      messages.push({ role: "assistant", content: message.content });
    }
  }
  return messages;
}

function throttlePatch(sessionId: string, messageId: string) {
  let text = "";
  let timer = 0;
  const flush = (extra?: Partial<ChatMessage>) => {
    useJingyun.getState().patchMessage(sessionId, messageId, { content: text, ...extra });
  };
  return {
    push(delta: string) {
      text += delta;
      if (!timer) timer = window.setTimeout(() => {
        timer = 0;
        flush();
      }, 80);
    },
    async done(extra?: Partial<ChatMessage>) {
      if (timer) window.clearTimeout(timer);
      flush(extra);
      return text;
    },
    text: () => text,
  };
}

async function approve(serverName: string, tool: string, args: string, permission: "ask" | "allow" | "deny"): Promise<boolean> {
  if (permission === "deny") return false;
  if (permission === "allow") return true;
  useJingyun.getState().setPendingTool({ id: crypto.randomUUID(), serverName, tool, args });
  return new Promise((resolve) => {
    toolWait = resolve;
  });
}

function openAiTools() {
  const servers = useJingyun.getState().mcpServers.filter((item) => item.enabled && item.tools.length);
  const tools: unknown[] = [];
  const map = new Map<string, { serverId: string; tool: string }>();
  const used = new Set<string>();
  for (const server of servers) {
    for (const tool of server.tools) {
      if (server.toolPermission[tool.name] === "deny") continue;
      let name = toolFunctionName(tool.name);
      while (used.has(name)) name = `${name.slice(0, 50)}_${used.size}`;
      used.add(name);
      map.set(name, { serverId: server.id, tool: tool.name });
      tools.push({
        type: "function",
        function: {
          name,
          description: tool.description || tool.name,
          parameters: tool.inputSchema || { type: "object", properties: {} },
        },
      });
    }
  }
  return { tools, map };
}

async function runTools(
  sessionId: string,
  messageId: string,
  persona: Persona,
  provider: Provider,
  model: string,
  baseMessages: ApiMessage[],
  signal: AbortSignal,
): Promise<void> {
  const bag = throttlePatch(sessionId, messageId);
  const thread = [...baseMessages];
  const { tools, map } = openAiTools();
  if (!tools.length) {
    await bag.done({ pending: false, error: "没有可调用的工具。先在能力里连接 MCP 并发现工具。" });
    return;
  }
  for (let round = 0; round < 3; round++) {
    if (signal.aborted) throw new DOMException("已停止", "AbortError");
    bag.push("");
    useJingyun.getState().patchMessage(sessionId, messageId, { content: round === 0 ? "正在判断是否需要工具…" : bag.text() });
    const result = await completeChat(
      { ...providerRequest(provider, model), messages: thread, maxTokens: useJingyun.getState().maxTokens, tools },
      signal,
    );
    if (!result.toolCalls.length) {
      await bag.done({ content: result.content || "（没有返回内容）", pending: false });
      return;
    }
    thread.push({
      role: "assistant",
      content: result.content || "",
      tool_calls: result.toolCalls.map((call) => ({
        id: call.id,
        type: "function",
        function: { name: call.name, arguments: call.arguments },
      })),
    });
    for (const call of result.toolCalls) {
      const target = map.get(call.name);
      const server = target ? useJingyun.getState().mcpServers.find((item) => item.id === target.serverId) : undefined;
      let output = "找不到这个工具。";
      let ok = false;
      if (server && target) {
        const permission = server.toolPermission[target.tool] || "ask";
        const allowed = await approve(server.name, target.tool, call.arguments, permission);
        if (!allowed) output = "用户拒绝了这次工具调用。";
        else {
          useJingyun.getState().patchMessage(sessionId, messageId, { content: `正在调用 ${target.tool}…` });
          try {
            const args = JSON.parse(call.arguments || "{}") as unknown;
            output = await callTool(server, target.tool, args);
            ok = true;
          } catch (err) {
            output = err instanceof Error ? err.message : "工具执行失败";
          }
        }
      }
      useJingyun.getState().pushToolLog({
        id: crypto.randomUUID(),
        at: Date.now(),
        server: server?.name || "未知",
        tool: target?.tool || call.name,
        args: call.arguments,
        result: output.slice(0, 2000),
        ok,
      });
      useJingyun.getState().appendMessage(sessionId, {
        id: crypto.randomUUID(),
        role: "tool",
        toolName: target?.tool || call.name,
        content: output.slice(0, 2000),
        createdAt: Date.now(),
      });
      thread.push({ role: "tool", tool_call_id: call.id, content: output });
    }
  }
  await bag.done({ content: "工具调用已达到 3 轮上限，已停止继续调用。", pending: false, error: "达到工具轮次上限" });
}

async function streamSlot(
  session: Session,
  persona: Persona,
  provider: Provider,
  model: string,
  mode: TurnMode,
  compareKey: "a" | "b" | undefined,
  signal: AbortSignal,
  withTools: boolean,
): Promise<void> {
  const history = visibleHistory(useJingyun.getState().sessions.find((item) => item.id === session.id) || session).filter(
    (message) => !message.compareKey || message.compareKey === compareKey,
  );
  const messageId = crypto.randomUUID();
  useJingyun.getState().appendMessage(session.id, {
    id: messageId,
    role: "assistant",
    content: "",
    pending: true,
    model,
    providerId: provider.id,
    compareKey,
    createdAt: Date.now(),
  });
  const messages = toApi(persona, history, mode);
  try {
    if (withTools && !compareKey) {
      await runTools(session.id, messageId, persona, provider, model, messages, signal);
      return;
    }
    const bag = throttlePatch(session.id, messageId);
    await streamChat(
      { ...providerRequest(provider, model), messages, maxTokens: useJingyun.getState().maxTokens },
      (delta) => bag.push(delta),
      signal,
    );
    const text = await bag.done({ pending: false });
    if (!text.trim()) useJingyun.getState().patchMessage(session.id, messageId, { content: "（没有返回内容）", pending: false });
  } catch (err) {
    const aborted = err instanceof DOMException && err.name === "AbortError";
    const message = useJingyun.getState().sessions.find((item) => item.id === session.id)?.messages.find((item) => item.id === messageId);
    useJingyun.getState().patchMessage(session.id, messageId, {
      pending: false,
      error: aborted ? undefined : err instanceof Error ? err.message : "生成失败",
      content: message?.content || (aborted ? "已停止" : ""),
    });
  }
}

export async function sendInSession(options: {
  sessionId: string;
  text: string;
  attachments?: Attachment[];
  mode?: TurnMode;
  compare?: boolean;
}): Promise<void> {
  const text = options.text.trim();
  const attachments = options.attachments ?? [];
  if (!text && !attachments.length) return;
  const state = useJingyun.getState();
  const session = state.sessions.find((item) => item.id === options.sessionId);
  if (!session) throw new Error("会话不存在");
  const persona = personaById(session.personaId);
  if (!persona) throw new Error("人设不存在");
  const provider = providerById(persona.providerId);
  if (!provider) throw new Error("人设绑定的服务商不存在");
  if (provider.kind !== "builtin" && !provider.apiKey) throw new Error(`请先在设置里填写「${provider.name}」的密钥`);
  state.appendMessage(session.id, {
    id: crypto.randomUUID(),
    role: "user",
    content: text,
    attachments,
    createdAt: Date.now(),
  });
  if (session.title === "新的对话" || session.title === "开始") {
    state.renameSession(session.id, (text || attachments[0]?.name || "对话").slice(0, 24));
  }
  const slots: { provider: Provider; model: string; compareKey?: "a" | "b" }[] = [
    { provider, model: persona.model || provider.models[0] || "grok-4.5", compareKey: options.compare ? "a" : undefined },
  ];
  if (options.compare) {
    const other = providerById(state.compareProviderId);
    if (!other) throw new Error("对比模型的服务商不存在");
    if (other.kind !== "builtin" && !other.apiKey) throw new Error(`请先填写「${other.name}」的密钥`);
    slots.push({ provider: other, model: state.compareModel, compareKey: "b" });
  }
  activeAbort?.abort();
  const controller = new AbortController();
  activeAbort = controller;
  state.setGenerating(true);
  try {
    await Promise.all(
      slots.map((slot) =>
        streamSlot(session, persona, slot.provider, slot.model, options.mode ?? null, slot.compareKey, controller.signal, state.toolsArmed),
      ),
    );
  } finally {
    if (activeAbort === controller) activeAbort = null;
    useJingyun.getState().setGenerating(false);
  }
}

export async function answerForBot(personaId: string, peer: string, title: string, text: string): Promise<string> {
  const cutoff = Date.now() - 3_600_000;
  while (qqStamps.length && qqStamps[0] < cutoff) qqStamps.shift();
  if (qqStamps.length >= 30) throw new Error("这一小时的自动回复已达 30 条上限，避免刷额度");
  const persona = personaById(personaId);
  if (!persona) throw new Error("QQ 使用的人设不存在");
  const provider = providerById(persona.providerId);
  if (!provider) throw new Error("人设没有可用的模型");
  if (provider.kind !== "builtin" && !provider.apiKey) throw new Error("人设的接口还没有密钥");
  const sessionId = useJingyun.getState().findOrCreateQqSession(peer, title, personaId);
  useJingyun.getState().appendMessage(sessionId, {
    id: crypto.randomUUID(),
    role: "user",
    content: text,
    createdAt: Date.now(),
  });
  const session = useJingyun.getState().sessions.find((item) => item.id === sessionId);
  const messages = toApi(persona, session ? visibleHistory(session) : [], null);
  const result = await completeChat({
    ...providerRequest(provider, persona.model),
    messages,
    maxTokens: Math.min(500, useJingyun.getState().maxTokens),
  });
  const content = result.content.trim();
  if (!content) throw new Error("模型没有返回可发送的文字");
  qqStamps.push(Date.now());
  useJingyun.getState().appendMessage(sessionId, {
    id: crypto.randomUUID(),
    role: "assistant",
    content,
    model: persona.model,
    providerId: provider.id,
    createdAt: Date.now(),
  });
  return content;
}

export async function extractMemories(personaId: string, sessionId: string): Promise<number> {
  const persona = personaById(personaId);
  const session = useJingyun.getState().sessions.find((item) => item.id === sessionId);
  const provider = persona ? providerById(persona.providerId) : undefined;
  if (!persona || !session || !provider) throw new Error("缺少人设或会话");
  const transcript = visibleHistory(session)
    .slice(-12)
    .map((message) => `${message.role === "user" ? "用户" : "助手"}：${message.content}`)
    .join("\n")
    .slice(0, 6000);
  if (!transcript) return 0;
  const result = await completeChat({
    ...providerRequest(provider, persona.model),
    maxTokens: 300,
    temperature: 0.2,
    messages: [
      {
        role: "system",
        content: "只输出 JSON 数组，元素是简短中文事实。最多 3 条。只保留对以后有用的用户信息或约定。没有就输出 []。不要 Markdown。",
      },
      { role: "user", content: transcript },
    ],
  });
  const start = result.content.indexOf("[");
  const end = result.content.lastIndexOf("]");
  if (start < 0 || end < start) throw new Error("模型没有返回记忆列表");
  const parsed = JSON.parse(result.content.slice(start, end + 1)) as unknown;
  if (!Array.isArray(parsed)) throw new Error("记忆格式不对");
  const facts = parsed.filter((item): item is string => typeof item === "string" && item.trim().length > 0).slice(0, 3);
  for (const fact of facts) useJingyun.getState().addMemory(personaId, fact.trim());
  return facts.length;
}

export async function testProvider(provider: Provider): Promise<string> {
  const model = provider.kind === "builtin" ? "grok-4.5" : provider.models[0];
  if (!model) throw new Error("先写一个模型名");
  const result = await completeChat({
    ...providerRequest(provider, model),
    maxTokens: 32,
    messages: [
      { role: "system", content: "只回复一个字：好" },
      { role: "user", content: "在吗" },
    ],
  });
  return result.content.trim() || "（空回复）";
}
