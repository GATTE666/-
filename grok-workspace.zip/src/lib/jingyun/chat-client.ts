import { apiUrl } from "@/lib/jingyun/api-url";

export type ApiMessage = {
  role: string;
  content: unknown;
  tool_call_id?: string;
  tool_calls?: unknown;
};

export type ChatRequest = {
  mode: "builtin" | "proxy" | "direct";
  baseUrl?: string;
  apiKey?: string;
  model: string;
  messages: ApiMessage[];
  maxTokens?: number;
  temperature?: number;
  tools?: unknown[];
};

export type ToolCall = { id: string; name: string; arguments: string };

function parseSse(chunk: string, onDelta: (delta: string) => void): string {
  const parts = chunk.split(/\n\n/);
  const rest = parts.pop() ?? "";
  for (const part of parts) {
    const line = part
      .split(/\r?\n/)
      .map((item) => item.trim())
      .find((item) => item.startsWith("data:"));
    if (!line) continue;
    const data = line.slice(5).trim();
    if (!data || data === "[DONE]") continue;
    const json = JSON.parse(data) as { delta?: string; error?: string; choices?: { delta?: { content?: string } }[] };
    if (json.error) throw new Error(json.error);
    const delta = json.delta || json.choices?.[0]?.delta?.content || "";
    if (delta) onDelta(delta);
  }
  return rest;
}

async function readError(res: Response): Promise<string> {
  try {
    const json = (await res.json()) as { error?: string };
    return json.error || `请求失败 ${res.status}`;
  } catch {
    return `请求失败 ${res.status}`;
  }
}

export async function streamChat(req: ChatRequest, onDelta: (delta: string) => void, signal: AbortSignal): Promise<void> {
  if (req.mode === "direct") {
    if (!req.baseUrl || !req.apiKey) throw new Error("直连需要地址和密钥");
    let base = req.baseUrl.trim().replace(/\/+$/, "");
    if (!base.endsWith("/chat/completions")) base += "/chat/completions";
    const res = await fetch(base, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${req.apiKey}` },
      body: JSON.stringify({
        model: req.model,
        messages: req.messages,
        stream: true,
        max_tokens: req.maxTokens ?? 1200,
        temperature: req.temperature ?? 0.7,
      }),
      signal,
    });
    if (!res.ok) throw new Error(await readError(res));
    if (!res.body) throw new Error("浏览器没有拿到流式响应");
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      buf = parseSse(buf, onDelta);
    }
    if (buf.trim()) parseSse(`${buf}\n\n`, onDelta);
    return;
  }
  const res = await fetch(apiUrl("/api/ai/chat"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...req, stream: true }),
    signal,
  });
  if (!res.ok) throw new Error(await readError(res));
  if (!res.body) throw new Error("没有流式响应");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    buf = parseSse(buf, onDelta);
  }
  if (buf.trim()) parseSse(`${buf}\n\n`, onDelta);
}

export async function completeChat(req: ChatRequest, signal?: AbortSignal): Promise<{ content: string; toolCalls: ToolCall[] }> {
  if (req.mode === "direct") {
    if (!req.baseUrl || !req.apiKey) throw new Error("直连需要地址和密钥");
    let base = req.baseUrl.trim().replace(/\/+$/, "");
    if (!base.endsWith("/chat/completions")) base += "/chat/completions";
    const res = await fetch(base, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${req.apiKey}` },
      body: JSON.stringify({
        model: req.model,
        messages: req.messages,
        stream: false,
        max_tokens: req.maxTokens ?? 800,
        temperature: req.temperature ?? 0.7,
        ...(req.tools?.length ? { tools: req.tools, tool_choice: "auto" } : {}),
      }),
      signal,
    });
    if (!res.ok) throw new Error(await readError(res));
    const json = (await res.json()) as {
      choices?: { message?: { content?: string; tool_calls?: { id?: string; function?: { name?: string; arguments?: string } }[] } }[];
      error?: { message?: string };
    };
    if (json.error?.message) throw new Error(json.error.message);
    const message = json.choices?.[0]?.message;
    return {
      content: message?.content || "",
      toolCalls: (message?.tool_calls ?? []).map((call) => ({
        id: call.id || crypto.randomUUID(),
        name: call.function?.name || "",
        arguments: call.function?.arguments || "{}",
      })),
    };
  }
  const res = await fetch(apiUrl("/api/ai/chat"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...req, stream: false }),
    signal,
  });
  if (!res.ok) throw new Error(await readError(res));
  const json = (await res.json()) as { content?: string; toolCalls?: ToolCall[]; error?: string };
  if (json.error) throw new Error(json.error);
  return { content: json.content || "", toolCalls: json.toolCalls || [] };
}
