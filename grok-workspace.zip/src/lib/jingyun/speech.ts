import { apiUrl } from "@/lib/jingyun/api-url";

type Rec = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((ev: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

type RecCtor = new () => Rec;

function ctor(): RecCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as Window & { SpeechRecognition?: RecCtor; webkitSpeechRecognition?: RecCtor };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export function speechInputAvailable(): boolean {
  return Boolean(ctor());
}

export function startDictation(handlers: {
  onText: (text: string, final: boolean) => void;
  onError: (message: string) => void;
  onEnd: () => void;
}): { stop: () => void } {
  const Ctor = ctor();
  if (!Ctor) {
    handlers.onError("这台设备的浏览器没有语音识别");
    handlers.onEnd();
    return { stop() {} };
  }
  const rec = new Ctor();
  rec.lang = "zh-CN";
  rec.interimResults = true;
  rec.continuous = false;
  rec.onresult = (ev) => {
    let text = "";
    let final = false;
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      text += ev.results[i][0]?.transcript ?? "";
      if (ev.results[i].isFinal) final = true;
    }
    handlers.onText(text, final);
  };
  rec.onerror = (ev) => {
    const map: Record<string, string> = {
      "not-allowed": "没有麦克风权限",
      "no-speech": "没有听到声音",
      network: "语音识别需要网络，这次失败了",
      aborted: "已停止",
    };
    handlers.onError(map[ev.error] || `语音识别失败：${ev.error}`);
  };
  rec.onend = () => handlers.onEnd();
  rec.start();
  return { stop: () => rec.stop() };
}

let cloudAudio: HTMLAudioElement | null = null;
let cloudUrl = "";

export function localVoices(): SpeechSynthesisVoice[] {
  if (typeof speechSynthesis === "undefined") return [];
  return speechSynthesis.getVoices();
}

export function stopSpeech(): void {
  if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
  if (cloudAudio) {
    cloudAudio.pause();
    cloudAudio.src = "";
    cloudAudio = null;
  }
  if (cloudUrl) {
    URL.revokeObjectURL(cloudUrl);
    cloudUrl = "";
  }
}

export function pauseSpeech(): void {
  if (cloudAudio && !cloudAudio.paused) {
    cloudAudio.pause();
    return;
  }
  if (typeof speechSynthesis !== "undefined" && speechSynthesis.speaking) speechSynthesis.pause();
}

export function resumeSpeech(): void {
  if (cloudAudio && cloudAudio.paused && cloudAudio.src) {
    void cloudAudio.play();
    return;
  }
  if (typeof speechSynthesis !== "undefined") speechSynthesis.resume();
}

export function speakLocal(text: string, voice: { rate: number; pitch: number; voiceURI: string }, onEnd: () => void): void {
  if (typeof speechSynthesis === "undefined") {
    onEnd();
    throw new Error("这台设备不能本机朗读");
  }
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text.slice(0, 4000));
  utter.lang = "zh-CN";
  utter.rate = voice.rate;
  utter.pitch = voice.pitch;
  const match = speechSynthesis.getVoices().find((item) => item.voiceURI === voice.voiceURI);
  if (match) utter.voice = match;
  utter.onend = onEnd;
  utter.onerror = onEnd;
  speechSynthesis.speak(utter);
}

export async function speakCloud(text: string, onEnd: () => void): Promise<void> {
  stopSpeech();
  const res = await fetch(apiUrl("/api/ai/tts"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: text.slice(0, 400), voice: "eve" }),
  });
  if (!res.ok) {
    const json = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(json.error || "语音合成失败");
  }
  const blob = await res.blob();
  cloudUrl = URL.createObjectURL(blob);
  cloudAudio = new Audio(cloudUrl);
  cloudAudio.onended = () => {
    onEnd();
    stopSpeech();
  };
  await cloudAudio.play();
}
