import { answerForBot } from "@/lib/jingyun/engine";
import { useJingyun } from "@/lib/jingyun/store";
import type { BotStatus, QqConfig } from "@/lib/jingyun/types";

type Inbound = {
  id: string;
  channel: "private" | "group";
  userId: string;
  groupId?: string;
  text: string;
  atBot: boolean;
  selfId?: string;
  nickname?: string;
};

type Hooks = {
  onStatus: (status: BotStatus) => void;
  onLog: (level: "info" | "error", message: string) => void;
  onMessage: (message: Inbound) => void;
};

const seen = new Set<string>();

function remember(id: string): boolean {
  if (!id || seen.has(id)) return false;
  seen.add(id);
  if (seen.size > 500) seen.delete(seen.values().next().value || "");
  return true;
}

function tokens(value: string): string[] {
  return value.split(/[\s,，]+/).map((item) => item.trim()).filter(Boolean);
}

function allow(cfg: QqConfig, message: Inbound): boolean {
  if (message.selfId && message.userId === message.selfId) return false;
  const black = tokens(cfg.blacklist);
  if (black.includes(message.userId) || (message.groupId && black.includes(message.groupId))) return false;
  const white = tokens(cfg.whitelist);
  if (white.length && !white.includes(message.userId) && !(message.groupId && white.includes(message.groupId))) return false;
  if (message.channel === "private") return cfg.privateReply;
  if (!cfg.groupReply) return false;
  if (cfg.atOnly && !message.atBot) return false;
  return true;
}

async function handleInbound(message: Inbound): Promise<void> {
  const cfg = useJingyun.getState().qq;
  if (!allow(cfg, message)) return;
  if (!message.text.trim()) return;
  const peer = message.channel === "group" ? `g:${message.groupId}` : `u:${message.userId}`;
  const title = message.channel === "group" ? `QQ 群 ${message.groupId}` : `QQ ${message.userId}`;
  useJingyun.getState().pushQqLog("info", `收到${message.channel === "group" ? "群" : "私"}消息 ${message.userId}：${message.text.slice(0, 80)}`);
  try {
    const reply = await answerForBot(cfg.personaId, peer, title, message.text);
    await runtime.send(message, reply);
    useJingyun.getState().pushQqLog("info", `已回复 ${message.userId}`);
  } catch (err) {
    useJingyun.getState().pushQqLog("error", err instanceof Error ? err.message : "回复失败");
  }
}

function textOf(message: unknown, raw: string): string {
  if (typeof message === "string") return message.replace(/\[CQ:[^\]]+\]/g, "").trim();
  if (Array.isArray(message)) {
    return message
      .map((seg) => {
        if (!seg || typeof seg !== "object") return "";
        const item = seg as { type?: string; data?: { text?: string } };
        return item.type === "text" ? item.data?.text || "" : "";
      })
      .join("")
      .trim();
  }
  return raw.replace(/\[CQ:[^\]]+\]/g, "").trim();
}

function atBot(message: unknown, raw: string, selfId: string): boolean {
  if (selfId && (raw.includes(`[CQ:at,qq=${selfId}]`) || raw.includes(`[CQ:at,qq=${selfId},`))) return true;
  if (!Array.isArray(message)) return false;
  return message.some((seg) => {
    if (!seg || typeof seg !== "object") return false;
    const item = seg as { type?: string; data?: { qq?: string | number } };
    return item.type === "at" && String(item.data?.qq ?? "") === selfId;
  });
}

class OneBotAdapter {
  private ws: WebSocket | null = null;
  private desired = false;
  private delay = 2000;
  private timer = 0;
  private selfId = "";

  start(cfg: QqConfig, hooks: Hooks): void {
    this.stopSocket();
    this.desired = true;
    this.delay = 2000;
    if (!cfg.wsUrl.trim()) {
      hooks.onStatus({ state: "error", detail: "先填写 OneBot WebSocket 地址" });
      this.desired = false;
      return;
    }
    let url: URL;
    try {
      url = new URL(cfg.wsUrl.trim());
    } catch {
      hooks.onStatus({ state: "error", detail: "WebSocket 地址不合法" });
      this.desired = false;
      return;
    }
    if (url.protocol !== "ws:" && url.protocol !== "wss:") {
      hooks.onStatus({ state: "error", detail: "地址需要以 ws:// 或 wss:// 开头" });
      this.desired = false;
      return;
    }
    if (location.protocol === "https:" && url.protocol === "ws:") {
      hooks.onStatus({ state: "error", detail: "当前是 https 页面，浏览器会拦截 ws://。请改用 wss://。" });
      this.desired = false;
      return;
    }
    if (cfg.accessToken && !url.searchParams.has("access_token")) url.searchParams.set("access_token", cfg.accessToken);
    this.open(url.toString(), hooks);
  }

  stop(): void {
    this.desired = false;
    this.stopSocket();
    useJingyun.getState().setQqStatus({ state: "stopped", detail: "已停止" });
  }

  private stopSocket(): void {
    window.clearTimeout(this.timer);
    this.ws?.close();
    this.ws = null;
  }

  private open(url: string, hooks: Hooks): void {
    hooks.onStatus({ state: "connecting", detail: "正在连接 OneBot…" });
    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch (err) {
      hooks.onStatus({ state: "error", detail: err instanceof Error ? err.message : "无法创建连接" });
      return;
    }
    this.ws = ws;
    ws.onopen = () => {
      this.delay = 2000;
      hooks.onStatus({ state: "online", detail: "已连接，等待登录信息" });
      hooks.onLog("info", "OneBot 已连接");
      ws.send(JSON.stringify({ action: "get_login_info", params: {}, echo: "login" }));
    };
    ws.onmessage = (ev) => {
      this.onFrame(String(ev.data), hooks);
    };
    ws.onerror = () => hooks.onLog("error", "WebSocket 出错");
    ws.onclose = () => {
      if (!this.desired) return;
      hooks.onStatus({ state: "error", detail: `${Math.round(this.delay / 1000)} 秒后重连` });
      this.timer = window.setTimeout(() => {
        if (this.desired) this.open(url, hooks);
      }, this.delay);
      this.delay = Math.min(this.delay * 2, 30_000);
    };
  }

  private onFrame(raw: string, hooks: Hooks): void {
    let frame: Record<string, unknown>;
    try {
      frame = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return;
    }
    if (frame.echo === "login" || frame.echo === "send") {
      const data = frame.data as { user_id?: number | string; nickname?: string } | undefined;
      if (frame.echo === "login" && data?.user_id) {
        this.selfId = String(data.user_id);
        hooks.onStatus({
          state: "online",
          detail: data.nickname ? `${data.nickname}（${this.selfId}）` : `QQ ${this.selfId}`,
          selfId: this.selfId,
          nickname: data.nickname,
        });
      }
      if (frame.echo === "send" && frame.status && frame.status !== "ok" && frame.retcode && frame.retcode !== 0) {
        hooks.onLog("error", `发送失败：${JSON.stringify(frame).slice(0, 180)}`);
      }
      return;
    }
    if (frame.post_type === "meta_event") return;
    if (frame.post_type !== "message") return;
    const selfId = String(frame.self_id ?? this.selfId ?? "");
    if (selfId) this.selfId = selfId;
    const messageType = frame.message_type === "group" ? "group" : "private";
    const id = String(frame.message_id ?? "");
    if (!remember(id)) return;
    const message: Inbound = {
      id,
      channel: messageType,
      userId: String(frame.user_id ?? ""),
      groupId: frame.group_id ? String(frame.group_id) : undefined,
      text: textOf(frame.message, String(frame.raw_message ?? "")),
      atBot: atBot(frame.message, String(frame.raw_message ?? ""), selfId),
      selfId,
    };
    hooks.onMessage(message);
  }

  send(message: Inbound, text: string): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) throw new Error("OneBot 不在线，回复没有发出");
    const action = message.channel === "group" ? "send_group_msg" : "send_private_msg";
    const params = message.channel === "group"
      ? { group_id: Number(message.groupId), message: text }
      : { user_id: Number(message.userId), message: text };
    this.ws.send(JSON.stringify({ action, params, echo: "send" }));
  }
}

class HttpAdapter {
  private desired = false;
  private timer = 0;

  start(cfg: QqConfig, hooks: Hooks): void {
    this.stop();
    if (!cfg.pollUrl || !cfg.sendUrl) {
      hooks.onStatus({ state: "error", detail: "请填写事件轮询地址和发送地址" });
      return;
    }
    this.desired = true;
    hooks.onStatus({ state: "online", detail: "正在轮询 HTTP 事件" });
    hooks.onLog("info", "HTTP 适配器已启动");
    const tick = async () => {
      if (!this.desired) return;
      try {
        const res = await fetch(cfg.pollUrl, { headers: headerMap(cfg.httpHeaderText) });
        if (!res.ok) throw new Error(`轮询返回 ${res.status}`);
        const json = (await res.json()) as { events?: Inbound[] };
        for (const event of json.events ?? []) {
          if (!event?.id || !remember(String(event.id))) continue;
          hooks.onMessage({
            id: String(event.id),
            channel: event.channel === "group" ? "group" : "private",
            userId: String(event.userId ?? ""),
            groupId: event.groupId ? String(event.groupId) : undefined,
            text: String(event.text ?? ""),
            atBot: Boolean(event.atBot),
          });
        }
      } catch (err) {
        hooks.onStatus({ state: "error", detail: err instanceof Error ? err.message : "轮询失败" });
        hooks.onLog("error", err instanceof Error ? err.message : "轮询失败");
      }
      if (this.desired) this.timer = window.setTimeout(() => void tick(), 3000);
    };
    void tick();
  }

  stop(): void {
    this.desired = false;
    window.clearTimeout(this.timer);
    useJingyun.getState().setQqStatus({ state: "stopped", detail: "已停止" });
  }

  async send(cfg: QqConfig, message: Inbound, text: string): Promise<void> {
    const res = await fetch(cfg.sendUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headerMap(cfg.httpHeaderText) },
      body: JSON.stringify({
        channel: message.channel,
        userId: message.userId,
        groupId: message.groupId,
        text,
      }),
    });
    if (!res.ok) throw new Error(`发送接口返回 ${res.status}`);
  }
}

function headerMap(text: string): Record<string, string> {
  const headers: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    const i = line.indexOf(":");
    if (i > 0) headers[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return headers;
}

const onebot = new OneBotAdapter();
const http = new HttpAdapter();

const runtime = {
  async send(message: Inbound, text: string) {
    const cfg = useJingyun.getState().qq;
    if (cfg.adapter === "http") await http.send(cfg, message, text);
    else onebot.send(message, text);
  },
};

function hooks(): Hooks {
  return {
    onStatus: (status) => useJingyun.getState().setQqStatus(status),
    onLog: (level, message) => useJingyun.getState().pushQqLog(level, message),
    onMessage: (message) => void handleInbound(message),
  };
}

export function startBot(): void {
  const cfg = useJingyun.getState().qq;
  stopBot(false);
  if (cfg.adapter === "http") http.start(cfg, hooks());
  else onebot.start(cfg, hooks());
}

export function stopBot(log = true): void {
  onebot.stop();
  http.stop();
  if (log) useJingyun.getState().pushQqLog("info", "桥接已停止");
}

export function restartBot(): void {
  useJingyun.getState().pushQqLog("info", "正在重启");
  startBot();
}
