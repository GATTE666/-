import { S as TorusGeometry, _ as Points, a as BufferGeometry, b as Scene, c as CylinderGeometry, d as Mesh, f as MeshBasicMaterial, g as PointLight, h as PerspectiveCamera, i as BufferAttribute, l as DirectionalLight, m as MeshStandardMaterial, n as WebGLRenderer, o as CapsuleGeometry, p as MeshPhysicalMaterial, r as AmbientLight, s as Clock, t as OrbitControls, u as Group, v as PointsMaterial, x as SphereGeometry, y as SRGBColorSpace } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/holo-scene-DFTjn9__.js
function mountHolo(canvas) {
	const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const renderer = new WebGLRenderer({
		canvas,
		antialias: true,
		alpha: true
	});
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
	renderer.setClearColor(0, 0);
	renderer.outputColorSpace = SRGBColorSpace;
	const scene = new Scene();
	const camera = new PerspectiveCamera(32, 1, .1, 40);
	camera.position.set(.15, 1.25, 3.35);
	const controls = new OrbitControls(camera, canvas);
	controls.target.set(0, 1.05, 0);
	controls.enableDamping = !reduced;
	controls.enablePan = false;
	controls.minDistance = 1.8;
	controls.maxDistance = 5.4;
	controls.minPolarAngle = .55;
	controls.maxPolarAngle = 1.55;
	controls.update();
	scene.add(new AmbientLight(12965862, .55));
	const key = new DirectionalLight(16774894, 1.35);
	key.position.set(1.4, 3.2, 2.2);
	scene.add(key);
	const rim = new DirectionalLight(8304360, 1.8);
	rim.position.set(-2.2, 1.6, -1.4);
	scene.add(rim);
	const fill = new PointLight(10406382, 4, 8);
	fill.position.set(0, .4, 1.6);
	scene.add(fill);
	const skin = new MeshPhysicalMaterial({
		color: 15780792,
		roughness: .52,
		metalness: .02
	});
	const hairMat = new MeshPhysicalMaterial({
		color: 1712944,
		roughness: .38,
		metalness: .08,
		clearcoat: .35
	});
	const cloth = new MeshPhysicalMaterial({
		color: 1519684,
		roughness: .62,
		metalness: .04
	});
	const shirt = new MeshPhysicalMaterial({
		color: 15199987,
		roughness: .7
	});
	const dark = new MeshStandardMaterial({
		color: 1054752,
		roughness: .5
	});
	const irisMat = new MeshStandardMaterial({
		color: 2910102,
		roughness: .25
	});
	const blush = new MeshBasicMaterial({
		color: 15179920,
		transparent: true,
		opacity: .28
	});
	const figure = new Group();
	scene.add(figure);
	const head = new Group();
	head.position.set(0, 1.58, 0);
	figure.add(head);
	const skull = new Mesh(new SphereGeometry(.34, 40, 32), skin);
	skull.scale.set(.96, 1.08, .98);
	head.add(skull);
	const hair = new Mesh(new SphereGeometry(.36, 32, 24), hairMat);
	hair.scale.set(1.02, 1.12, 1.05);
	hair.position.set(0, .06, -.04);
	head.add(hair);
	const bang = new Mesh(new SphereGeometry(.2, 24, 16), hairMat);
	bang.scale.set(1.55, .42, .7);
	bang.position.set(0, .2, .22);
	head.add(bang);
	const sideL = new Mesh(new CapsuleGeometry(.08, .42, 6, 12), hairMat);
	sideL.position.set(-.3, -.05, .02);
	head.add(sideL);
	const sideR = sideL.clone();
	sideR.position.x = .3;
	head.add(sideR);
	const eyeGeo = new SphereGeometry(.055, 20, 16);
	const white = new MeshStandardMaterial({
		color: 16251903,
		roughness: .2
	});
	const eyeL = new Mesh(eyeGeo, white);
	eyeL.position.set(-.11, .03, .28);
	eyeL.scale.set(1.15, 1.25, .55);
	const eyeR = eyeL.clone();
	eyeR.position.x = .11;
	head.add(eyeL, eyeR);
	const irisGeo = new SphereGeometry(.028, 16, 12);
	const irisL = new Mesh(irisGeo, irisMat);
	irisL.position.set(-.11, .02, .318);
	const irisR = irisL.clone();
	irisR.position.x = .11;
	head.add(irisL, irisR);
	const pupil = new Mesh(new SphereGeometry(.014, 12, 10), dark);
	const pupilL = pupil.clone();
	pupilL.position.set(-.11, .02, .338);
	const pupilR = pupil.clone();
	pupilR.position.set(.11, .02, .338);
	head.add(pupilL, pupilR);
	const catchMat = new MeshBasicMaterial({ color: 16777215 });
	const catchL = new Mesh(new SphereGeometry(.008, 8, 8), catchMat);
	catchL.position.set(-.098, .034, .346);
	const catchR = catchL.clone();
	catchR.position.x = .122;
	head.add(catchL, catchR);
	const lidGeo = new SphereGeometry(.062, 16, 10);
	const lidL = new Mesh(lidGeo, hairMat);
	lidL.position.set(-.11, .07, .29);
	lidL.scale.set(1.2, .28, .4);
	const lidR = lidL.clone();
	lidR.position.x = .11;
	head.add(lidL, lidR);
	const mouth = new Mesh(new SphereGeometry(.045, 16, 12), new MeshStandardMaterial({
		color: 13206648,
		roughness: .45
	}));
	mouth.position.set(0, -.16, .3);
	mouth.scale.set(1.15, .28, .35);
	head.add(mouth);
	const cheekL = new Mesh(new SphereGeometry(.05, 12, 10), blush);
	cheekL.position.set(-.18, -.05, .26);
	const cheekR = cheekL.clone();
	cheekR.position.x = .18;
	head.add(cheekL, cheekR);
	const nose = new Mesh(new SphereGeometry(.03, 12, 10), skin);
	nose.position.set(0, -.04, .33);
	nose.scale.set(.7, .55, .7);
	head.add(nose);
	const neck = new Mesh(new CylinderGeometry(.07, .08, .12, 16), skin);
	neck.position.set(0, 1.28, 0);
	figure.add(neck);
	const torso = new Mesh(new CapsuleGeometry(.28, .42, 8, 20), shirt);
	torso.position.set(0, .92, 0);
	torso.scale.set(.86, 1, .62);
	figure.add(torso);
	const coat = new Mesh(new CapsuleGeometry(.34, .46, 8, 20), cloth);
	coat.position.set(0, .86, -.02);
	coat.scale.set(1, 1.05, .72);
	figure.add(coat);
	function limb(x, y, z, len, radius, mat) {
		const pivot = new Group();
		pivot.position.set(x, y, z);
		const mesh = new Mesh(new CapsuleGeometry(radius, len, 6, 12), mat);
		mesh.position.y = -len / 2 - radius;
		pivot.add(mesh);
		return pivot;
	}
	const armL = limb(-.34, 1.16, 0, .34, .055, cloth);
	const armR = limb(.34, 1.16, 0, .34, .055, cloth);
	armL.rotation.z = .18;
	armR.rotation.z = -.18;
	const forearmL = limb(0, -.42, 0, .28, .048, skin);
	const forearmR = limb(0, -.42, 0, .28, .048, skin);
	armL.add(forearmL);
	armR.add(forearmR);
	figure.add(armL, armR);
	const legL = limb(-.12, .52, 0, .4, .07, dark);
	const legR = limb(.12, .52, 0, .4, .07, dark);
	figure.add(legL, legR);
	const deck = new Mesh(new CylinderGeometry(.72, .78, .06, 48), new MeshPhysicalMaterial({
		color: 1454148,
		roughness: .3,
		metalness: .2,
		transparent: true,
		opacity: .85
	}));
	deck.position.y = .03;
	scene.add(deck);
	const ringMat = new MeshBasicMaterial({
		color: 9356522,
		transparent: true,
		opacity: .45
	});
	const ringA = new Mesh(new TorusGeometry(.86, .008, 8, 64), ringMat);
	ringA.rotation.x = Math.PI / 2;
	ringA.position.y = .12;
	const ringB = ringA.clone();
	ringB.scale.setScalar(1.18);
	ringB.position.y = 1.15;
	scene.add(ringA, ringB);
	const shell = new Mesh(new CylinderGeometry(1.05, 1.05, 2.5, 48, 1, true), new MeshBasicMaterial({
		color: 12049663,
		transparent: true,
		opacity: .05,
		side: 2
	}));
	shell.position.y = 1.15;
	scene.add(shell);
	const points = new BufferGeometry();
	const count = 80;
	const positions = /* @__PURE__ */ new Float32Array(240);
	for (let i = 0; i < count; i++) {
		const a = Math.random() * Math.PI * 2;
		const r = .75 + Math.random() * .35;
		positions[i * 3] = Math.cos(a) * r;
		positions[i * 3 + 1] = Math.random() * 2.3;
		positions[i * 3 + 2] = Math.sin(a) * r;
	}
	points.setAttribute("position", new BufferAttribute(positions, 3));
	const dust = new Points(points, new PointsMaterial({
		color: 12969215,
		size: .015,
		transparent: true,
		opacity: .7
	}));
	scene.add(dust);
	let action = "idle";
	let speaking = false;
	let alive = true;
	const clock = new Clock();
	function resize() {
		const width = canvas.clientWidth || 320;
		const height = canvas.clientHeight || 420;
		renderer.setSize(width, height, false);
		camera.aspect = width / Math.max(1, height);
		camera.updateProjectionMatrix();
	}
	resize();
	function frame() {
		if (!alive) return;
		const t = clock.getElapsedTime();
		if (!reduced) {
			figure.position.y = Math.sin(t * 1.4) * .015;
			head.rotation.y = Math.sin(t * .6) * .08;
			head.rotation.z = Math.sin(t * .4) * .03;
			ringA.rotation.z = t * .35;
			ringB.rotation.z = -t * .22;
			dust.rotation.y = t * .08;
		}
		const lidScale = !reduced && Math.sin(t * .55) > .97 ? 1.15 : action === "surprise" ? .12 : action === "smile" ? .42 : .28;
		lidL.scale.y = lidScale;
		lidR.scale.y = lidScale;
		const talk = speaking ? .55 + Math.abs(Math.sin(t * 14)) * .7 : action === "surprise" ? .7 : action === "smile" ? .38 : .28;
		mouth.scale.y = talk;
		mouth.scale.x = action === "smile" ? 1.45 : 1.15;
		if (action === "wave") {
			armR.rotation.z = -2.2 + Math.sin(t * 6) * .25;
			armR.rotation.x = -.2;
		} else if (action === "think") {
			armR.rotation.z = -.9;
			armR.rotation.x = -1.1;
			head.rotation.z = .12;
		} else {
			armR.rotation.z = -.18 + Math.sin(t * 1.2) * (reduced ? 0 : .04);
			armR.rotation.x = 0;
		}
		armL.rotation.z = .18 + Math.sin(t * 1.2 + 1) * (reduced ? 0 : .04);
		controls.update();
		renderer.render(scene, camera);
		requestAnimationFrame(frame);
	}
	requestAnimationFrame(frame);
	return {
		setAction(next) {
			action = next;
		},
		setSpeaking(next) {
			speaking = next;
		},
		resize,
		dispose() {
			alive = false;
			controls.dispose();
			renderer.dispose();
			scene.traverse((obj) => {
				const mesh = obj;
				mesh.geometry?.dispose?.();
				const material = mesh.material;
				if (Array.isArray(material)) material.forEach((item) => item.dispose());
				else material?.dispose?.();
			});
		}
	};
}
//#endregion
export { mountHolo };
