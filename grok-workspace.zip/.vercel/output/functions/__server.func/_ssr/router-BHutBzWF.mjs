import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BHutBzWF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-BBSy1lCl.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content"
			},
			{ title: "鲸云 JingYun" },
			{
				name: "description",
				content: "鲸云 JingYun，本地优先的全能 AI 助手。"
			},
			{
				name: "theme-color",
				content: "#071018"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;600&family=Outfit:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "zh-CN",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-B1up5XHv.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var PRIVATE = /^(localhost|.*\.localhost|.*\.local|metadata\.google\.internal|0\.0\.0\.0|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|169\.254\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.\d+\.\d+)$/i;
function assertPublicUrl(raw) {
	let url;
	try {
		url = new URL(raw);
	} catch {
		throw new Error("地址不是合法的 URL");
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("只允许 http 或 https");
	if (url.username || url.password) throw new Error("不要把账号写进地址");
	const host = url.hostname.replace(/^\[|\]$/g, "");
	if (PRIVATE.test(host) || host === "::1" || host.toLowerCase().startsWith("fe80:") || host.toLowerCase().startsWith("fc") || host.toLowerCase().startsWith("fd")) throw new Error("服务器不能访问内网或本机地址。本地接口请改用「浏览器直连」。");
	return url;
}
function chatCompletionsUrl(baseUrl) {
	let base = baseUrl.trim().replace(/\/+$/, "");
	if (base.endsWith("/chat/completions")) return base;
	return `${base}/chat/completions`;
}
function imageGenerationsUrl(baseUrl) {
	let base = baseUrl.trim().replace(/\/+$/, "");
	if (base.endsWith("/images/generations")) return base;
	if (base.endsWith("/chat/completions")) base = base.slice(0, -17);
	return `${base}/images/generations`;
}
function builtinKey() {
	const key = process.env.XAI_API_KEY;
	return key && key.trim() ? key.trim() : null;
}
async function postUpstream(url, apiKey, body, signal) {
	return fetch(url, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body),
		signal
	});
}
function clampTokens(n, builtin) {
	return Math.max(64, Math.min(typeof n === "number" && Number.isFinite(n) ? Math.floor(n) : builtin ? 800 : 1200, builtin ? 800 : 4096));
}
function errorText(status, body) {
	const clean = body.replace(/\s+/g, " ").slice(0, 420);
	return `上游返回 ${status}${clean ? `：${clean}` : ""}`;
}
function safeHeaders(input) {
	const headers = new Headers();
	if (!input || typeof input !== "object") return headers;
	for (const [key, value] of Object.entries(input)) {
		if (typeof value !== "string") continue;
		const name = key.toLowerCase();
		if ([
			"host",
			"content-length",
			"connection",
			"transfer-encoding"
		].includes(name)) continue;
		headers.set(key, value.slice(0, 2e3));
	}
	return headers;
}
function parsePayload(text) {
	const trimmed = text.trim();
	if (!trimmed) return null;
	if (trimmed.startsWith("data:") || trimmed.includes("\ndata:")) return trimmed.split(/\r?\n/).filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trim()).filter((line) => line && line !== "[DONE]").map((line) => {
		try {
			return JSON.parse(line);
		} catch {
			return null;
		}
	}).filter((item) => item !== null).at(-1) ?? { raw: trimmed.slice(0, 2e3) };
	try {
		return JSON.parse(trimmed);
	} catch {
		return { raw: trimmed.slice(0, 2e3) };
	}
}
var Route$5 = createFileRoute("/api/mcp")({ server: { handlers: { POST: async ({ request }) => {
	const body = await request.json().catch(() => null);
	if (!body?.url || body.rpc == null) return Response.json({ error: "缺少 MCP 地址或请求" }, { status: 400 });
	let url;
	try {
		url = assertPublicUrl(body.url);
	} catch (err) {
		return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
	}
	const headers = safeHeaders(body.headers);
	if (!headers.has("content-type")) headers.set("content-type", "application/json");
	if (!headers.has("accept")) headers.set("accept", "application/json, text/event-stream");
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), 25e3);
	const onAbort = () => controller.abort();
	request.signal.addEventListener("abort", onAbort);
	try {
		const upstream = await fetch(url, {
			method: "POST",
			headers,
			body: JSON.stringify(body.rpc),
			signal: controller.signal
		});
		const text = (await upstream.text()).slice(0, 2e5);
		return Response.json({
			ok: upstream.ok,
			status: upstream.status,
			json: parsePayload(text),
			error: upstream.ok ? void 0 : `MCP 服务返回 ${upstream.status}`
		});
	} catch (err) {
		const message = controller.signal.aborted ? "MCP 请求超时" : err instanceof Error ? err.message : "MCP 连接失败";
		return Response.json({
			ok: false,
			error: message
		}, { status: 502 });
	} finally {
		clearTimeout(timer);
		request.signal.removeEventListener("abort", onAbort);
	}
} } } });
function strip(html) {
	return html.replace(/<[^>]+>/g, "").replace(/"/g, "\"").replace(/&#039;|'/g, "'").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/\s+/g, " ").trim();
}
async function wiki(query, signal) {
	const endpoint = new URL("https://zh.wikipedia.org/w/api.php");
	endpoint.searchParams.set("action", "query");
	endpoint.searchParams.set("list", "search");
	endpoint.searchParams.set("srsearch", query);
	endpoint.searchParams.set("srlimit", "5");
	endpoint.searchParams.set("format", "json");
	endpoint.searchParams.set("utf8", "1");
	const res = await fetch(endpoint, {
		headers: {
			Accept: "application/json",
			"User-Agent": "JingYunAI/1.0 (personal research assistant)"
		},
		signal
	});
	if (!res.ok) throw new Error(errorText(res.status, await res.text()));
	return ((await res.json()).query?.search ?? []).map((item) => ({
		title: item.title,
		url: `https://zh.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, "_"))}`,
		snippet: strip(item.snippet),
		source: "维基百科"
	}));
}
async function tavily(query, apiKey, signal) {
	const res = await fetch("https://api.tavily.com/search", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			api_key: apiKey,
			query,
			max_results: 6,
			include_answer: false
		}),
		signal
	});
	if (!res.ok) throw new Error(errorText(res.status, await res.text()));
	return ((await res.json()).results ?? []).map((item) => ({
		title: item.title || item.url || "结果",
		url: item.url || "",
		snippet: (item.content || "").slice(0, 360),
		source: "Tavily"
	}));
}
async function brave(query, apiKey, signal) {
	const endpoint = new URL("https://api.search.brave.com/res/v1/web/search");
	endpoint.searchParams.set("q", query);
	endpoint.searchParams.set("count", "6");
	const res = await fetch(endpoint, {
		headers: {
			Accept: "application/json",
			"X-Subscription-Token": apiKey
		},
		signal
	});
	if (!res.ok) throw new Error(errorText(res.status, await res.text()));
	return ((await res.json()).web?.results ?? []).map((item) => ({
		title: item.title || "结果",
		url: item.url || "",
		snippet: item.description || "",
		source: "Brave"
	}));
}
async function serper(query, apiKey, signal) {
	const res = await fetch("https://google.serper.dev/search", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-API-KEY": apiKey
		},
		body: JSON.stringify({
			q: query,
			num: 6
		}),
		signal
	});
	if (!res.ok) throw new Error(errorText(res.status, await res.text()));
	return ((await res.json()).organic ?? []).map((item) => ({
		title: item.title || "结果",
		url: item.link || "",
		snippet: item.snippet || "",
		source: "Serper"
	}));
}
async function custom(query, endpoint, apiKey, signal) {
	const url = assertPublicUrl(endpoint);
	const res = await fetch(url, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			...apiKey ? { Authorization: `Bearer ${apiKey}` } : {}
		},
		body: JSON.stringify({
			query,
			q: query
		}),
		signal
	});
	if (!res.ok) throw new Error(errorText(res.status, await res.text()));
	return ((await res.json()).results ?? []).map((item) => ({
		title: item.title || item.url || "结果",
		url: item.url || item.link || "",
		snippet: item.snippet || item.content || "",
		source: "自定义搜索"
	}));
}
var Route$4 = createFileRoute("/api/search")({ server: { handlers: { POST: async ({ request }) => {
	const body = await request.json().catch(() => null);
	const query = body?.query?.trim() ?? "";
	if (!query) return Response.json({ error: "请输入要搜索的内容" }, { status: 400 });
	if (query.length > 300) return Response.json({ error: "搜索词过长" }, { status: 400 });
	try {
		let results = [];
		if (body?.provider === "tavily") {
			if (!body.apiKey) return Response.json({ error: "请填写 Tavily API Key" }, { status: 400 });
			results = await tavily(query, body.apiKey, request.signal);
		} else if (body?.provider === "brave") {
			if (!body.apiKey) return Response.json({ error: "请填写 Brave API Key" }, { status: 400 });
			results = await brave(query, body.apiKey, request.signal);
		} else if (body?.provider === "serper") {
			if (!body.apiKey) return Response.json({ error: "请填写 Serper API Key" }, { status: 400 });
			results = await serper(query, body.apiKey, request.signal);
		} else if (body?.provider === "custom") {
			if (!body.endpoint) return Response.json({ error: "请填写自定义搜索地址" }, { status: 400 });
			results = await custom(query, body.endpoint, body.apiKey || "", request.signal);
		} else results = await wiki(query, request.signal);
		return Response.json({ results: results.filter((item) => item.url).slice(0, 8) });
	} catch (err) {
		return Response.json({ error: err instanceof Error ? err.message : "搜索失败" }, { status: 502 });
	}
} } } });
function sse(obj) {
	return `data: ${JSON.stringify(obj)}\n\n`;
}
var Route$3 = createFileRoute("/api/ai/chat")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({ error: "请求不是 JSON" }, { status: 400 });
	}
	const messages = Array.isArray(body.messages) ? body.messages.slice(-30) : [];
	if (!messages.length) return Response.json({ error: "没有消息" }, { status: 400 });
	const builtin = body.mode === "builtin";
	let url = "https://api.x.ai/v1/chat/completions";
	let key = builtinKey();
	let model = "grok-4.5";
	if (!builtin) {
		if (!body.baseUrl || !body.apiKey || !body.model) return Response.json({ error: "缺少接口地址、密钥或模型名" }, { status: 400 });
		try {
			url = chatCompletionsUrl(body.baseUrl);
			assertPublicUrl(url);
		} catch (err) {
			return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
		}
		key = body.apiKey;
		model = body.model.slice(0, 120);
	} else if (!key) return Response.json({ error: "内置 Grok 在这个环境不可用，请添加你自己的接口。" }, { status: 503 });
	const payload = {
		model,
		messages,
		temperature: typeof body.temperature === "number" ? Math.min(1.5, Math.max(0, body.temperature)) : .7,
		max_tokens: clampTokens(body.maxTokens, builtin),
		stream: body.stream !== false
	};
	if (Array.isArray(body.tools) && body.tools.length && body.stream === false) {
		payload.tools = body.tools.slice(0, 32);
		payload.tool_choice = "auto";
	}
	let upstream;
	try {
		upstream = await postUpstream(url, key || "", payload, request.signal);
	} catch (err) {
		if (request.signal.aborted) return new Response(null, { status: 499 });
		return Response.json({ error: err instanceof Error ? err.message : "连接上游失败" }, { status: 502 });
	}
	if (!upstream.ok) {
		const text = await upstream.text();
		return Response.json({ error: errorText(upstream.status, text) }, { status: 502 });
	}
	if (body.stream === false) {
		const message = (await upstream.json()).choices?.[0]?.message;
		const content = typeof message?.content === "string" ? message.content : "";
		const toolCalls = (message?.tool_calls ?? []).map((call) => ({
			id: call.id || crypto.randomUUID(),
			name: call.function?.name || "",
			arguments: call.function?.arguments || "{}"
		}));
		return Response.json({
			content,
			toolCalls
		});
	}
	if (!upstream.body) return Response.json({ error: "上游没有返回流" }, { status: 502 });
	const reader = upstream.body.getReader();
	const decoder = new TextDecoder();
	const encoder = new TextEncoder();
	let buffer = "";
	const stream = new ReadableStream({
		async pull(controller) {
			const { done, value } = await reader.read();
			if (done) {
				controller.enqueue(encoder.encode("data: [DONE]\n\n"));
				controller.close();
				return;
			}
			buffer += decoder.decode(value, { stream: true });
			const lines = buffer.split(/\r?\n/);
			buffer = lines.pop() ?? "";
			for (const line of lines) {
				const trimmed = line.trim();
				if (!trimmed.startsWith("data:")) continue;
				const data = trimmed.slice(5).trim();
				if (!data) continue;
				if (data === "[DONE]") {
					controller.enqueue(encoder.encode("data: [DONE]\n\n"));
					continue;
				}
				try {
					const json = JSON.parse(data);
					if (json.error?.message) {
						controller.enqueue(encoder.encode(sse({ error: json.error.message })));
						continue;
					}
					const delta = json.choices?.[0]?.delta?.content ?? "";
					if (delta) controller.enqueue(encoder.encode(sse({ delta })));
				} catch {}
			}
		},
		cancel() {
			reader.cancel();
		}
	});
	return new Response(stream, { headers: {
		"Content-Type": "text/event-stream; charset=utf-8",
		"Cache-Control": "no-cache, no-transform",
		"X-Accel-Buffering": "no"
	} });
} } } });
var Route$2 = createFileRoute("/api/ai/image")({ server: { handlers: { POST: async ({ request }) => {
	const body = await request.json().catch(() => null);
	const prompt = body?.prompt?.trim() ?? "";
	if (!prompt) return Response.json({ error: "请先写提示词" }, { status: 400 });
	if (prompt.length > 800) return Response.json({ error: "提示词过长" }, { status: 400 });
	const builtin = body?.mode === "builtin";
	let url = "https://api.x.ai/v1/images/generations";
	let key = builtinKey();
	let model = "grok-imagine-image";
	if (!builtin) {
		if (!body?.baseUrl || !body.apiKey) return Response.json({ error: "缺少绘图接口或密钥" }, { status: 400 });
		url = imageGenerationsUrl(body.baseUrl);
		try {
			assertPublicUrl(url);
		} catch (err) {
			return Response.json({ error: err instanceof Error ? err.message : "地址无效" }, { status: 400 });
		}
		key = body.apiKey;
		model = (body.model || "dall-e-3").slice(0, 120);
	} else if (!key) return Response.json({ error: "内置绘图不可用，请填写你自己的绘图接口。" }, { status: 503 });
	let upstream;
	try {
		upstream = await postUpstream(url, key || "", {
			model,
			prompt,
			n: 1,
			response_format: "url"
		}, request.signal);
	} catch (err) {
		return Response.json({ error: err instanceof Error ? err.message : "绘图请求失败" }, { status: 502 });
	}
	if (!upstream.ok) {
		const text = await upstream.text();
		return Response.json({ error: errorText(upstream.status, text) }, { status: 502 });
	}
	const images = ((await upstream.json()).data ?? []).map((item) => ({
		url: item.url || "",
		b64: item.b64_json || ""
	})).filter((item) => item.url || item.b64);
	if (!images.length) return Response.json({ error: "接口没有返回图片" }, { status: 502 });
	return Response.json({ images });
} } } });
var Route$1 = createFileRoute("/api/ai/status")({ server: { handlers: { GET: async () => Response.json({ builtin: Boolean(builtinKey()) }) } } });
var Route = createFileRoute("/api/ai/tts")({ server: { handlers: { POST: async ({ request }) => {
	const body = await request.json().catch(() => null);
	const text = body?.text?.trim() ?? "";
	if (!text) return Response.json({ error: "没有可朗读的文字" }, { status: 400 });
	const key = builtinKey();
	if (!key) return Response.json({ error: "内置语音不可用，请用本机朗读。" }, { status: 503 });
	const upstream = await fetch("https://api.x.ai/v1/tts", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${key}`
		},
		body: JSON.stringify({
			text: text.slice(0, 400),
			voice_id: body?.voice || "eve"
		}),
		signal: request.signal
	});
	if (!upstream.ok) {
		const err = await upstream.text();
		return Response.json({ error: errorText(upstream.status, err) }, { status: 502 });
	}
	const buf = await upstream.arrayBuffer();
	return new Response(buf, { headers: {
		"Content-Type": upstream.headers.get("content-type") || "audio/mpeg",
		"Cache-Control": "no-store"
	} });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ApiMcpRoute: Route$5.update({
		id: "/api/mcp",
		path: "/api/mcp",
		getParentRoute: () => Route$7
	}),
	ApiSearchRoute: Route$4.update({
		id: "/api/search",
		path: "/api/search",
		getParentRoute: () => Route$7
	}),
	ApiAiChatRoute: Route$3.update({
		id: "/api/ai/chat",
		path: "/api/ai/chat",
		getParentRoute: () => Route$7
	}),
	ApiAiImageRoute: Route$2.update({
		id: "/api/ai/image",
		path: "/api/ai/image",
		getParentRoute: () => Route$7
	}),
	ApiAiStatusRoute: Route$1.update({
		id: "/api/ai/status",
		path: "/api/ai/status",
		getParentRoute: () => Route$7
	}),
	ApiAiTtsRoute: Route.update({
		id: "/api/ai/tts",
		path: "/api/ai/tts",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { previewPathPrefix as n, router_exports as t };
