import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as Pause, d as MessageCircle, f as Layers, h as Box, i as Square, l as Paperclip, m as Copy, n as UserRound, o as Send, p as ImagePlus, s as Plus, t as Volume2, u as Mic } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-BHutBzWF.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B1up5XHv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function inline(text) {
	const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\[[^\]]+\]\(https?:\/\/[^)\s]+\))/g;
	const nodes = [];
	let last = 0;
	let match;
	let key = 0;
	while (match = re.exec(text)) {
		if (match.index > last) nodes.push(text.slice(last, match.index));
		const token = match[0];
		if (token.startsWith("`")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-xs bg-bg px-1 font-mono text-[0.92em]",
			children: token.slice(1, -1)
		}, key++));
		else if (token.startsWith("**")) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: token.slice(2, -2) }, key++));
		else {
			const label = token.slice(1, token.indexOf("]"));
			const href = token.slice(token.indexOf("(") + 1, -1);
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				target: "_blank",
				rel: "noreferrer",
				className: "underline decoration-focus underline-offset-2",
				children: label
			}, key++));
		}
		last = match.index + token.length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return nodes;
}
function RichText({ text }) {
	const chunks = text.split("```");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 break-words",
		children: chunks.map((chunk, index) => {
			if (index % 2 === 1) {
				const nl = chunk.indexOf("\n");
				const body = nl >= 0 && chunk.slice(0, nl).length < 16 ? chunk.slice(nl + 1) : chunk;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto rounded-sm bg-bg p-3 font-mono text-sm leading-relaxed",
					children: body.replace(/\n$/, "")
				}, index);
			}
			return chunk.split(/\n{2,}/).map((para, p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap",
				children: inline(para)
			}, `${index}-${p}`));
		})
	});
}
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
function WhaleMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M5 18.5c.4-5.2 5.2-9.5 11.2-9.5 2.7 0 4.6.8 6.4.8 1.6 0 2.8-1.2 4.1-1.2 1.8 0 2.8 1.6 2.3 3.2-.7 2.2-2.6 3-3.4 4.6-.9 1.8-.4 4.1-2.2 5.6-2.2 1.8-5.2 2.5-8.2 2.2-4.6-.4-9.8-2.2-10.2-5.7Z"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "22.2",
			cy: "13.2",
			r: "0.8",
			fill: "var(--jy-bg)"
		})]
	});
}
function Button({ variant = "ghost", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cx("btn", `btn-${variant}`, className),
		...props
	});
}
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cx("panel p-4", className),
		children
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "mb-1 block text-sm font-medium text-muted",
		children
	});
}
function apiUrl(path) {
	if (typeof window === "undefined") return path;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? `${prefix}${path}` : path;
}
function parseSse(chunk, onDelta) {
	const parts = chunk.split(/\n\n/);
	const rest = parts.pop() ?? "";
	for (const part of parts) {
		const line = part.split(/\r?\n/).map((item) => item.trim()).find((item) => item.startsWith("data:"));
		if (!line) continue;
		const data = line.slice(5).trim();
		if (!data || data === "[DONE]") continue;
		const json = JSON.parse(data);
		if (json.error) throw new Error(json.error);
		const delta = json.delta || json.choices?.[0]?.delta?.content || "";
		if (delta) onDelta(delta);
	}
	return rest;
}
async function readError(res) {
	try {
		return (await res.json()).error || `请求失败 ${res.status}`;
	} catch {
		return `请求失败 ${res.status}`;
	}
}
async function streamChat(req, onDelta, signal) {
	if (req.mode === "direct") {
		if (!req.baseUrl || !req.apiKey) throw new Error("直连需要地址和密钥");
		let base = req.baseUrl.trim().replace(/\/+$/, "");
		if (!base.endsWith("/chat/completions")) base += "/chat/completions";
		const res = await fetch(base, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${req.apiKey}`
			},
			body: JSON.stringify({
				model: req.model,
				messages: req.messages,
				stream: true,
				max_tokens: req.maxTokens ?? 1200,
				temperature: req.temperature ?? .7
			}),
			signal
		});
		if (!res.ok) throw new Error(await readError(res));
		if (!res.body) throw new Error("浏览器没有拿到流式响应");
		const reader = res.body.getReader();
		const decoder = new TextDecoder();
		let buf = "";
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			buf += decoder.decode(value, { stream: true });
			buf = parseSse(buf, onDelta);
		}
		if (buf.trim()) parseSse(`${buf}\n\n`, onDelta);
		return;
	}
	const res = await fetch(apiUrl("/api/ai/chat"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...req,
			stream: true
		}),
		signal
	});
	if (!res.ok) throw new Error(await readError(res));
	if (!res.body) throw new Error("没有流式响应");
	const reader = res.body.getReader();
	const decoder = new TextDecoder();
	let buf = "";
	while (true) {
		const { done, value } = await reader.read();
		if (done) break;
		buf += decoder.decode(value, { stream: true });
		buf = parseSse(buf, onDelta);
	}
	if (buf.trim()) parseSse(`${buf}\n\n`, onDelta);
}
async function completeChat(req, signal) {
	if (req.mode === "direct") {
		if (!req.baseUrl || !req.apiKey) throw new Error("直连需要地址和密钥");
		let base = req.baseUrl.trim().replace(/\/+$/, "");
		if (!base.endsWith("/chat/completions")) base += "/chat/completions";
		const res = await fetch(base, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${req.apiKey}`
			},
			body: JSON.stringify({
				model: req.model,
				messages: req.messages,
				stream: false,
				max_tokens: req.maxTokens ?? 800,
				temperature: req.temperature ?? .7,
				...req.tools?.length ? {
					tools: req.tools,
					tool_choice: "auto"
				} : {}
			}),
			signal
		});
		if (!res.ok) throw new Error(await readError(res));
		const json = await res.json();
		if (json.error?.message) throw new Error(json.error.message);
		const message = json.choices?.[0]?.message;
		return {
			content: message?.content || "",
			toolCalls: (message?.tool_calls ?? []).map((call) => ({
				id: call.id || crypto.randomUUID(),
				name: call.function?.name || "",
				arguments: call.function?.arguments || "{}"
			}))
		};
	}
	const res = await fetch(apiUrl("/api/ai/chat"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...req,
			stream: false
		}),
		signal
	});
	if (!res.ok) throw new Error(await readError(res));
	const json = await res.json();
	if (json.error) throw new Error(json.error);
	return {
		content: json.content || "",
		toolCalls: json.toolCalls || []
	};
}
function headersFrom(text) {
	const headers = {};
	for (const line of text.split(/\r?\n/)) {
		const i = line.indexOf(":");
		if (i < 1) continue;
		headers[line.slice(0, i).trim()] = line.slice(i + 1).trim();
	}
	return headers;
}
async function rpc(server, method, params, id) {
	const payload = id === void 0 ? {
		jsonrpc: "2.0",
		method,
		params
	} : {
		jsonrpc: "2.0",
		id,
		method,
		params
	};
	const res = await fetch(apiUrl("/api/mcp"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			url: server.url,
			headers: headersFrom(server.headerText),
			rpc: payload
		})
	});
	const json = await res.json();
	if (!res.ok || json.ok === false) throw new Error(json.error || "MCP 请求失败");
	const envelope = json.json;
	if (!envelope || typeof envelope !== "object") throw new Error("MCP 没有返回 JSON");
	if ("error" in envelope && envelope.error) throw new Error(envelope.error.message || "MCP 拒绝了请求");
	return "result" in envelope ? envelope.result : envelope;
}
async function discoverTools(server) {
	await rpc(server, "initialize", {
		protocolVersion: "2024-11-05",
		capabilities: {},
		clientInfo: {
			name: "jingyun",
			version: "1.0.0"
		}
	}, 1);
	await rpc(server, "notifications/initialized", {}).catch(() => void 0);
	return ((await rpc(server, "tools/list", {}, 2)).tools ?? []).map((tool) => ({
		name: tool.name,
		description: tool.description || "",
		inputSchema: tool.inputSchema ?? {
			type: "object",
			properties: {}
		}
	}));
}
async function callTool(server, name, args) {
	const result = await rpc(server, "tools/call", {
		name,
		arguments: args
	}, Date.now() % 1e6);
	if (Array.isArray(result?.content)) return result.content.map((item) => item.text || JSON.stringify(item)).join("\n").slice(0, 8e3) || (result.isError ? "工具返回了错误" : "工具没有返回文字");
	return JSON.stringify(result).slice(0, 8e3);
}
function toolFunctionName(tool) {
	return tool.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 60) || "tool";
}
var PREFIX = "enc:v1:";
var DEVICE_KEY = "jingyun-device-key";
function b64(bytes) {
	let s = "";
	for (const b of bytes) s += String.fromCharCode(b);
	return btoa(s);
}
function unb64(s) {
	const bin = atob(s);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
async function idb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open("jingyun", 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains("kv")) req.result.createObjectStore("kv");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function idbGet(key) {
	if (typeof indexedDB === "undefined") return null;
	const db = await idb();
	return new Promise((resolve, reject) => {
		const req = db.transaction("kv", "readonly").objectStore("kv").get(key);
		req.onsuccess = () => resolve(req.result ?? null);
		req.onerror = () => reject(req.error);
	});
}
async function idbSet(key, value) {
	if (typeof indexedDB === "undefined") return;
	const db = await idb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction("kv", "readwrite");
		tx.objectStore("kv").put(value, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
var keyPromise = null;
async function deviceKey() {
	if (!keyPromise) keyPromise = loadDeviceKey();
	return keyPromise;
}
async function loadDeviceKey() {
	const existing = await idbGet(DEVICE_KEY);
	if (existing) {
		const raw = unb64(existing);
		return crypto.subtle.importKey("raw", raw.buffer, "AES-GCM", false, ["encrypt", "decrypt"]);
	}
	const raw = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(32));
	await idbSet(DEVICE_KEY, b64(raw));
	return crypto.subtle.importKey("raw", raw.buffer, "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function seal(plain) {
	if (!plain) return "";
	if (plain.startsWith(PREFIX)) return plain;
	const key = await deviceKey();
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, new TextEncoder().encode(plain));
	return `${PREFIX}${b64(iv)}.${b64(new Uint8Array(cipher))}`;
}
async function openSecret(stored) {
	if (!stored) return "";
	if (!stored.startsWith(PREFIX)) return stored;
	const [ivB, dataB] = stored.slice(7).split(".");
	if (!ivB || !dataB) return "";
	try {
		const key = await deviceKey();
		const iv = unb64(ivB);
		const data = unb64(dataB);
		const plain = await crypto.subtle.decrypt({
			name: "AES-GCM",
			iv: iv.buffer
		}, key, data.buffer);
		return new TextDecoder().decode(plain);
	} catch {
		return "";
	}
}
async function derive(passphrase, salt, iterations) {
	const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(passphrase), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt: salt.buffer,
		iterations,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function encryptJson(value, passphrase) {
	const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const iterations = 1e5;
	const key = await derive(passphrase, salt, iterations);
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, new TextEncoder().encode(JSON.stringify(value)));
	return JSON.stringify({
		format: "jingyun-backup",
		v: 1,
		kdf: "pbkdf2-aes-gcm",
		iterations,
		salt: b64(salt),
		iv: b64(iv),
		data: b64(new Uint8Array(cipher))
	});
}
async function decryptJson(text, passphrase) {
	const parsed = JSON.parse(text);
	if (parsed.format !== "jingyun-backup") throw new Error("这不是鲸云备份文件");
	if (parsed.kdf === "none") return parsed.state;
	if (!parsed.salt || !parsed.iv || !parsed.data) throw new Error("备份缺少加密字段");
	const key = await derive(passphrase, unb64(parsed.salt), parsed.iterations || 1e5);
	const iv = unb64(parsed.iv);
	const data = unb64(parsed.data);
	try {
		const plain = await crypto.subtle.decrypt({
			name: "AES-GCM",
			iv: iv.buffer
		}, key, data.buffer);
		return JSON.parse(new TextDecoder().decode(plain));
	} catch {
		throw new Error("口令不对，或文件已损坏");
	}
}
var memory = /* @__PURE__ */ new Map();
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open("jingyun", 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains("kv")) req.result.createObjectStore("kv");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function kvGet(key) {
	if (typeof indexedDB === "undefined") return memory.get(key) ?? null;
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const req = db.transaction("kv", "readonly").objectStore("kv").get(key);
		req.onsuccess = () => resolve(req.result ?? null);
		req.onerror = () => reject(req.error);
	});
}
async function kvSet(key, value) {
	if (typeof indexedDB === "undefined") {
		memory.set(key, value);
		return;
	}
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction("kv", "readwrite");
		tx.objectStore("kv").put(value, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
var BUILTIN_ID = "builtin";
var now = () => Date.now();
function seed() {
	const personaId = "persona-jingyun";
	const coderId = "persona-coder";
	const sessionId = "session-welcome";
	const t = now();
	return {
		theme: "tide",
		providers: [{
			id: BUILTIN_ID,
			name: "内置 Grok",
			kind: "builtin",
			baseUrl: "https://api.x.ai/v1",
			apiKey: "",
			models: ["grok-4.5"],
			imageModel: "grok-imagine-image",
			transport: "proxy"
		}],
		personas: [{
			id: personaId,
			name: "鲸云",
			personality: "克制、清楚，先给结论",
			systemPrompt: "你是鲸云，一个冷静可靠的中文全能助手。先给结论，再补充必要细节。代码要能运行。不确定就直说。不要假装调用了你没有的工具，也不要编造来源。",
			providerId: BUILTIN_ID,
			model: "grok-4.5",
			voiceURI: "",
			memories: []
		}, {
			id: coderId,
			name: "工程搭档",
			personality: "直接、较真、少客套",
			systemPrompt: "你是工程搭档。优先给出可运行的实现和失败时怎么查。指出风险，不堆砌概念。默认用中文解释，代码和标识符保持原文。",
			providerId: BUILTIN_ID,
			model: "grok-4.5",
			voiceURI: "",
			memories: []
		}],
		sessions: [{
			id: sessionId,
			title: "开始",
			personaId,
			createdAt: t,
			updatedAt: t,
			messages: [{
				id: "welcome",
				role: "assistant",
				content: "我是鲸云。可以直接对话、写作、编程和翻译。\n\n人设和长期记忆在「人设」。全息舱里的角色可以旋转、缩放，也会跟着说话。搜索、文件、绘图、MCP 和 QQ 在「能力」。密钥只留在这台设备上。",
				createdAt: t,
				model: "grok-4.5",
				providerId: BUILTIN_ID
			}]
		}],
		activePersonaId: personaId,
		activeSessionId: sessionId,
		mcpServers: [],
		toolLogs: [],
		qq: {
			adapter: "onebot11",
			wsUrl: "",
			accessToken: "",
			pollUrl: "",
			sendUrl: "",
			httpHeaderText: "",
			privateReply: true,
			groupReply: true,
			atOnly: true,
			whitelist: "",
			blacklist: "",
			personaId
		},
		qqLogs: [],
		search: {
			provider: "wiki",
			apiKey: "",
			endpoint: ""
		},
		voice: {
			rate: 1,
			pitch: 1,
			voiceURI: ""
		},
		maxTokens: 800,
		holoFollow: true
	};
}
var initial = seed();
async function sealState(raw) {
	const wrapped = JSON.parse(raw);
	const state = structuredClone(wrapped.state);
	state.providers = await Promise.all(state.providers.map(async (item) => ({
		...item,
		apiKey: await seal(item.apiKey)
	})));
	state.search = {
		...state.search,
		apiKey: await seal(state.search.apiKey)
	};
	state.qq = {
		...state.qq,
		accessToken: await seal(state.qq.accessToken)
	};
	wrapped.state = state;
	return JSON.stringify(wrapped);
}
async function openState(raw) {
	const wrapped = JSON.parse(raw);
	const state = wrapped.state;
	state.providers = await Promise.all((state.providers ?? []).map(async (item) => ({
		...item,
		apiKey: await openSecret(item.apiKey || "")
	})));
	if (state.search) state.search.apiKey = await openSecret(state.search.apiKey || "");
	if (state.qq) state.qq.accessToken = await openSecret(state.qq.accessToken || "");
	wrapped.state = state;
	return JSON.stringify(wrapped);
}
var writeChain = Promise.resolve();
var storage = {
	getItem: async (name) => {
		const raw = await kvGet(name);
		if (!raw) return null;
		try {
			return await openState(raw);
		} catch {
			return null;
		}
	},
	setItem: async (name, value) => {
		writeChain = writeChain.then(async () => {
			await kvSet(name, await sealState(value));
		});
		await writeChain;
	},
	removeItem: async (name) => {
		await kvSet(name, "");
	}
};
function trimLogs(items, max = 120) {
	return items.length > max ? items.slice(items.length - max) : items;
}
var useJingyun = create()(persist((set, get) => ({
	...initial,
	hydrated: false,
	view: "chat",
	labTab: "search",
	compare: false,
	compareProviderId: BUILTIN_ID,
	compareModel: "grok-4.5",
	toolsArmed: false,
	generating: false,
	speaking: false,
	holoAction: "idle",
	builtinReady: null,
	qqStatus: {
		state: "stopped",
		detail: "未连接"
	},
	pendingTool: null,
	setHydrated: (hydrated) => set({ hydrated }),
	setView: (view) => set({ view }),
	setLabTab: (labTab) => set({
		labTab,
		view: "lab"
	}),
	setTheme: (theme) => set({ theme }),
	setBuiltinReady: (builtinReady) => set({ builtinReady }),
	setCompare: (compare) => set({ compare }),
	setCompareTarget: (compareProviderId, compareModel) => set({
		compareProviderId,
		compareModel
	}),
	setToolsArmed: (toolsArmed) => set({ toolsArmed }),
	setGenerating: (generating) => set({ generating }),
	setSpeaking: (speaking) => set({ speaking }),
	setHoloAction: (holoAction) => set({ holoAction }),
	setHoloFollow: (holoFollow) => set({ holoFollow }),
	setMaxTokens: (maxTokens) => set({ maxTokens }),
	setVoice: (patch) => set({ voice: {
		...get().voice,
		...patch
	} }),
	setSearch: (patch) => set({ search: {
		...get().search,
		...patch
	} }),
	setQq: (patch) => set({ qq: {
		...get().qq,
		...patch
	} }),
	setQqStatus: (qqStatus) => set({ qqStatus }),
	pushQqLog: (level, message) => set({ qqLogs: trimLogs([...get().qqLogs, {
		id: crypto.randomUUID(),
		at: now(),
		level,
		message
	}]) }),
	clearQqLogs: () => set({ qqLogs: [] }),
	upsertProvider: (provider) => set({ providers: get().providers.some((item) => item.id === provider.id) ? get().providers.map((item) => item.id === provider.id ? provider : item) : [...get().providers, provider] }),
	removeProvider: (id) => {
		if (id === "builtin") return;
		set({ providers: get().providers.filter((item) => item.id !== id) });
	},
	upsertPersona: (persona) => set({
		personas: get().personas.some((item) => item.id === persona.id) ? get().personas.map((item) => item.id === persona.id ? persona : item) : [...get().personas, persona],
		activePersonaId: persona.id
	}),
	removePersona: (id) => {
		const personas = get().personas.filter((item) => item.id !== id);
		if (!personas.length) return;
		set({
			personas,
			activePersonaId: get().activePersonaId === id ? personas[0].id : get().activePersonaId
		});
	},
	addMemory: (personaId, text) => set({ personas: get().personas.map((item) => item.id === personaId ? {
		...item,
		memories: [...item.memories, {
			id: crypto.randomUUID(),
			text,
			createdAt: now()
		}]
	} : item) }),
	updateMemory: (personaId, memory) => set({ personas: get().personas.map((item) => item.id === personaId ? {
		...item,
		memories: item.memories.map((entry) => entry.id === memory.id ? memory : entry)
	} : item) }),
	removeMemory: (personaId, memoryId) => set({ personas: get().personas.map((item) => item.id === personaId ? {
		...item,
		memories: item.memories.filter((entry) => entry.id !== memoryId)
	} : item) }),
	newSession: (personaId) => {
		const id = crypto.randomUUID();
		const t = now();
		const session = {
			id,
			title: "新的对话",
			personaId: personaId || get().activePersonaId,
			createdAt: t,
			updatedAt: t,
			messages: []
		};
		set({
			sessions: [session, ...get().sessions],
			activeSessionId: id,
			activePersonaId: session.personaId
		});
		return id;
	},
	selectSession: (id) => {
		set({
			activeSessionId: id,
			activePersonaId: get().sessions.find((item) => item.id === id)?.personaId || get().activePersonaId
		});
	},
	renameSession: (id, title) => set({ sessions: get().sessions.map((item) => item.id === id ? {
		...item,
		title,
		updatedAt: now()
	} : item) }),
	removeSession: (id) => {
		const sessions = get().sessions.filter((item) => item.id !== id);
		if (!sessions.length) {
			const t = now();
			const sid = crypto.randomUUID();
			set({
				sessions: [{
					id: sid,
					title: "新的对话",
					personaId: get().activePersonaId,
					createdAt: t,
					updatedAt: t,
					messages: []
				}],
				activeSessionId: sid
			});
			return;
		}
		set({
			sessions,
			activeSessionId: get().activeSessionId === id ? sessions[0].id : get().activeSessionId
		});
	},
	clearSession: (id) => set({ sessions: get().sessions.map((item) => item.id === id ? {
		...item,
		messages: [],
		updatedAt: now()
	} : item) }),
	setSessionPersona: (id, personaId) => set({
		activePersonaId: personaId,
		sessions: get().sessions.map((item) => item.id === id ? {
			...item,
			personaId,
			updatedAt: now()
		} : item)
	}),
	appendMessage: (sessionId, message) => set({ sessions: get().sessions.map((item) => item.id === sessionId ? {
		...item,
		updatedAt: now(),
		messages: [...item.messages, message].slice(-200)
	} : item) }),
	patchMessage: (sessionId, messageId, patch) => set({ sessions: get().sessions.map((item) => item.id === sessionId ? {
		...item,
		updatedAt: now(),
		messages: item.messages.map((message) => message.id === messageId ? {
			...message,
			...patch
		} : message)
	} : item) }),
	findOrCreateQqSession: (peer, title, personaId) => {
		const existing = get().sessions.find((item) => item.origin?.type === "qq" && item.origin.peer === peer);
		if (existing) return existing.id;
		const id = crypto.randomUUID();
		const t = now();
		set({ sessions: [{
			id,
			title,
			personaId,
			createdAt: t,
			updatedAt: t,
			messages: [],
			origin: {
				type: "qq",
				peer
			}
		}, ...get().sessions] });
		return id;
	},
	upsertMcp: (server) => set({ mcpServers: get().mcpServers.some((item) => item.id === server.id) ? get().mcpServers.map((item) => item.id === server.id ? server : item) : [...get().mcpServers, server] }),
	removeMcp: (id) => set({ mcpServers: get().mcpServers.filter((item) => item.id !== id) }),
	pushToolLog: (log) => set({ toolLogs: trimLogs([...get().toolLogs, log]) }),
	setPendingTool: (pendingTool) => set({ pendingTool }),
	replacePersisted: (data) => set({ ...data }),
	snapshot: () => {
		const s = get();
		return {
			theme: s.theme,
			providers: s.providers,
			personas: s.personas,
			sessions: s.sessions,
			activePersonaId: s.activePersonaId,
			activeSessionId: s.activeSessionId,
			mcpServers: s.mcpServers,
			toolLogs: s.toolLogs,
			qq: s.qq,
			qqLogs: s.qqLogs,
			search: s.search,
			voice: s.voice,
			maxTokens: s.maxTokens,
			holoFollow: s.holoFollow
		};
	}
}), {
	name: "jingyun",
	skipHydration: true,
	storage: createJSONStorage(() => storage),
	partialize: (state) => ({
		theme: state.theme,
		providers: state.providers,
		personas: state.personas,
		sessions: state.sessions,
		activePersonaId: state.activePersonaId,
		activeSessionId: state.activeSessionId,
		mcpServers: state.mcpServers,
		toolLogs: state.toolLogs,
		qq: state.qq,
		qqLogs: state.qqLogs,
		search: state.search,
		voice: state.voice,
		maxTokens: state.maxTokens,
		holoFollow: state.holoFollow
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
function personaById(id) {
	return useJingyun.getState().personas.find((item) => item.id === id);
}
function providerById(id) {
	return useJingyun.getState().providers.find((item) => item.id === id);
}
var MODE = {
	write: "这一轮是写作。给出可以直接使用的成稿，语言跟随用户。",
	code: "这一轮是编程。给出能运行的代码，并简短说明如何运行。不要省略关键部分。",
	translate: "这一轮是翻译。保留专名。用户没指定目标语言时译成中文。"
};
var toolWait = null;
var activeAbort = null;
var qqStamps = [];
function stopGeneration() {
	activeAbort?.abort();
}
function decideTool(ok) {
	const wait = toolWait;
	toolWait = null;
	useJingyun.getState().setPendingTool(null);
	wait?.(ok);
}
function providerRequest(provider, model) {
	if (provider.kind === "builtin") return {
		mode: "builtin",
		model: "grok-4.5"
	};
	return {
		mode: provider.transport === "direct" ? "direct" : "proxy",
		baseUrl: provider.baseUrl,
		apiKey: provider.apiKey,
		model
	};
}
function visibleHistory(session) {
	return session.messages.filter((message) => message.role !== "tool" && !message.pending && !message.error && (message.content || message.attachments?.length));
}
function toApi(persona, history, mode) {
	const memories = persona.memories.map((item) => `- ${item.text}`).join("\n");
	const messages = [{
		role: "system",
		content: [
			persona.systemPrompt,
			persona.personality ? `性格：${persona.personality}` : "",
			memories ? `长期记忆（用户可更正）：\n${memories}` : "",
			mode ? MODE[mode] : ""
		].filter(Boolean).join("\n\n")
	}];
	for (const message of history.slice(-20)) if (message.role === "user") {
		const files = (message.attachments ?? []).filter((item) => item.kind === "text" && item.text).map((item) => `【文件 ${item.name}】\n${item.text}`).join("\n\n");
		const text = [message.content, files].filter(Boolean).join("\n\n") || "请看附件";
		const images = (message.attachments ?? []).filter((item) => item.kind === "image" && item.dataUrl);
		if (images.length) messages.push({
			role: "user",
			content: [{
				type: "text",
				text
			}, ...images.map((item) => ({
				type: "image_url",
				image_url: { url: item.dataUrl }
			}))]
		});
		else messages.push({
			role: "user",
			content: text
		});
	} else if (message.role === "assistant") messages.push({
		role: "assistant",
		content: message.content
	});
	return messages;
}
function throttlePatch(sessionId, messageId) {
	let text = "";
	let timer = 0;
	const flush = (extra) => {
		useJingyun.getState().patchMessage(sessionId, messageId, {
			content: text,
			...extra
		});
	};
	return {
		push(delta) {
			text += delta;
			if (!timer) timer = window.setTimeout(() => {
				timer = 0;
				flush();
			}, 80);
		},
		async done(extra) {
			if (timer) window.clearTimeout(timer);
			flush(extra);
			return text;
		},
		text: () => text
	};
}
async function approve(serverName, tool, args, permission) {
	if (permission === "deny") return false;
	if (permission === "allow") return true;
	useJingyun.getState().setPendingTool({
		id: crypto.randomUUID(),
		serverName,
		tool,
		args
	});
	return new Promise((resolve) => {
		toolWait = resolve;
	});
}
function openAiTools() {
	const servers = useJingyun.getState().mcpServers.filter((item) => item.enabled && item.tools.length);
	const tools = [];
	const map = /* @__PURE__ */ new Map();
	const used = /* @__PURE__ */ new Set();
	for (const server of servers) for (const tool of server.tools) {
		if (server.toolPermission[tool.name] === "deny") continue;
		let name = toolFunctionName(tool.name);
		while (used.has(name)) name = `${name.slice(0, 50)}_${used.size}`;
		used.add(name);
		map.set(name, {
			serverId: server.id,
			tool: tool.name
		});
		tools.push({
			type: "function",
			function: {
				name,
				description: tool.description || tool.name,
				parameters: tool.inputSchema || {
					type: "object",
					properties: {}
				}
			}
		});
	}
	return {
		tools,
		map
	};
}
async function runTools(sessionId, messageId, persona, provider, model, baseMessages, signal) {
	const bag = throttlePatch(sessionId, messageId);
	const thread = [...baseMessages];
	const { tools, map } = openAiTools();
	if (!tools.length) {
		await bag.done({
			pending: false,
			error: "没有可调用的工具。先在能力里连接 MCP 并发现工具。"
		});
		return;
	}
	for (let round = 0; round < 3; round++) {
		if (signal.aborted) throw new DOMException("已停止", "AbortError");
		bag.push("");
		useJingyun.getState().patchMessage(sessionId, messageId, { content: round === 0 ? "正在判断是否需要工具…" : bag.text() });
		const result = await completeChat({
			...providerRequest(provider, model),
			messages: thread,
			maxTokens: useJingyun.getState().maxTokens,
			tools
		}, signal);
		if (!result.toolCalls.length) {
			await bag.done({
				content: result.content || "（没有返回内容）",
				pending: false
			});
			return;
		}
		thread.push({
			role: "assistant",
			content: result.content || "",
			tool_calls: result.toolCalls.map((call) => ({
				id: call.id,
				type: "function",
				function: {
					name: call.name,
					arguments: call.arguments
				}
			}))
		});
		for (const call of result.toolCalls) {
			const target = map.get(call.name);
			const server = target ? useJingyun.getState().mcpServers.find((item) => item.id === target.serverId) : void 0;
			let output = "找不到这个工具。";
			let ok = false;
			if (server && target) {
				const permission = server.toolPermission[target.tool] || "ask";
				if (!await approve(server.name, target.tool, call.arguments, permission)) output = "用户拒绝了这次工具调用。";
				else {
					useJingyun.getState().patchMessage(sessionId, messageId, { content: `正在调用 ${target.tool}…` });
					try {
						const args = JSON.parse(call.arguments || "{}");
						output = await callTool(server, target.tool, args);
						ok = true;
					} catch (err) {
						output = err instanceof Error ? err.message : "工具执行失败";
					}
				}
			}
			useJingyun.getState().pushToolLog({
				id: crypto.randomUUID(),
				at: Date.now(),
				server: server?.name || "未知",
				tool: target?.tool || call.name,
				args: call.arguments,
				result: output.slice(0, 2e3),
				ok
			});
			useJingyun.getState().appendMessage(sessionId, {
				id: crypto.randomUUID(),
				role: "tool",
				toolName: target?.tool || call.name,
				content: output.slice(0, 2e3),
				createdAt: Date.now()
			});
			thread.push({
				role: "tool",
				tool_call_id: call.id,
				content: output
			});
		}
	}
	await bag.done({
		content: "工具调用已达到 3 轮上限，已停止继续调用。",
		pending: false,
		error: "达到工具轮次上限"
	});
}
async function streamSlot(session, persona, provider, model, mode, compareKey, signal, withTools) {
	const history = visibleHistory(useJingyun.getState().sessions.find((item) => item.id === session.id) || session).filter((message) => !message.compareKey || message.compareKey === compareKey);
	const messageId = crypto.randomUUID();
	useJingyun.getState().appendMessage(session.id, {
		id: messageId,
		role: "assistant",
		content: "",
		pending: true,
		model,
		providerId: provider.id,
		compareKey,
		createdAt: Date.now()
	});
	const messages = toApi(persona, history, mode);
	try {
		if (withTools && !compareKey) {
			await runTools(session.id, messageId, persona, provider, model, messages, signal);
			return;
		}
		const bag = throttlePatch(session.id, messageId);
		await streamChat({
			...providerRequest(provider, model),
			messages,
			maxTokens: useJingyun.getState().maxTokens
		}, (delta) => bag.push(delta), signal);
		if (!(await bag.done({ pending: false })).trim()) useJingyun.getState().patchMessage(session.id, messageId, {
			content: "（没有返回内容）",
			pending: false
		});
	} catch (err) {
		const aborted = err instanceof DOMException && err.name === "AbortError";
		const message = useJingyun.getState().sessions.find((item) => item.id === session.id)?.messages.find((item) => item.id === messageId);
		useJingyun.getState().patchMessage(session.id, messageId, {
			pending: false,
			error: aborted ? void 0 : err instanceof Error ? err.message : "生成失败",
			content: message?.content || (aborted ? "已停止" : "")
		});
	}
}
async function sendInSession(options) {
	const text = options.text.trim();
	const attachments = options.attachments ?? [];
	if (!text && !attachments.length) return;
	const state = useJingyun.getState();
	const session = state.sessions.find((item) => item.id === options.sessionId);
	if (!session) throw new Error("会话不存在");
	const persona = personaById(session.personaId);
	if (!persona) throw new Error("人设不存在");
	const provider = providerById(persona.providerId);
	if (!provider) throw new Error("人设绑定的服务商不存在");
	if (provider.kind !== "builtin" && !provider.apiKey) throw new Error(`请先在设置里填写「${provider.name}」的密钥`);
	state.appendMessage(session.id, {
		id: crypto.randomUUID(),
		role: "user",
		content: text,
		attachments,
		createdAt: Date.now()
	});
	if (session.title === "新的对话" || session.title === "开始") state.renameSession(session.id, (text || attachments[0]?.name || "对话").slice(0, 24));
	const slots = [{
		provider,
		model: persona.model || provider.models[0] || "grok-4.5",
		compareKey: options.compare ? "a" : void 0
	}];
	if (options.compare) {
		const other = providerById(state.compareProviderId);
		if (!other) throw new Error("对比模型的服务商不存在");
		if (other.kind !== "builtin" && !other.apiKey) throw new Error(`请先填写「${other.name}」的密钥`);
		slots.push({
			provider: other,
			model: state.compareModel,
			compareKey: "b"
		});
	}
	activeAbort?.abort();
	const controller = new AbortController();
	activeAbort = controller;
	state.setGenerating(true);
	try {
		await Promise.all(slots.map((slot) => streamSlot(session, persona, slot.provider, slot.model, options.mode ?? null, slot.compareKey, controller.signal, state.toolsArmed)));
	} finally {
		if (activeAbort === controller) activeAbort = null;
		useJingyun.getState().setGenerating(false);
	}
}
async function answerForBot(personaId, peer, title, text) {
	const cutoff = Date.now() - 36e5;
	while (qqStamps.length && qqStamps[0] < cutoff) qqStamps.shift();
	if (qqStamps.length >= 30) throw new Error("这一小时的自动回复已达 30 条上限，避免刷额度");
	const persona = personaById(personaId);
	if (!persona) throw new Error("QQ 使用的人设不存在");
	const provider = providerById(persona.providerId);
	if (!provider) throw new Error("人设没有可用的模型");
	if (provider.kind !== "builtin" && !provider.apiKey) throw new Error("人设的接口还没有密钥");
	const sessionId = useJingyun.getState().findOrCreateQqSession(peer, title, personaId);
	useJingyun.getState().appendMessage(sessionId, {
		id: crypto.randomUUID(),
		role: "user",
		content: text,
		createdAt: Date.now()
	});
	const session = useJingyun.getState().sessions.find((item) => item.id === sessionId);
	const messages = toApi(persona, session ? visibleHistory(session) : [], null);
	const content = (await completeChat({
		...providerRequest(provider, persona.model),
		messages,
		maxTokens: Math.min(500, useJingyun.getState().maxTokens)
	})).content.trim();
	if (!content) throw new Error("模型没有返回可发送的文字");
	qqStamps.push(Date.now());
	useJingyun.getState().appendMessage(sessionId, {
		id: crypto.randomUUID(),
		role: "assistant",
		content,
		model: persona.model,
		providerId: provider.id,
		createdAt: Date.now()
	});
	return content;
}
async function extractMemories(personaId, sessionId) {
	const persona = personaById(personaId);
	const session = useJingyun.getState().sessions.find((item) => item.id === sessionId);
	const provider = persona ? providerById(persona.providerId) : void 0;
	if (!persona || !session || !provider) throw new Error("缺少人设或会话");
	const transcript = visibleHistory(session).slice(-12).map((message) => `${message.role === "user" ? "用户" : "助手"}：${message.content}`).join("\n").slice(0, 6e3);
	if (!transcript) return 0;
	const result = await completeChat({
		...providerRequest(provider, persona.model),
		maxTokens: 300,
		temperature: .2,
		messages: [{
			role: "system",
			content: "只输出 JSON 数组，元素是简短中文事实。最多 3 条。只保留对以后有用的用户信息或约定。没有就输出 []。不要 Markdown。"
		}, {
			role: "user",
			content: transcript
		}]
	});
	const start = result.content.indexOf("[");
	const end = result.content.lastIndexOf("]");
	if (start < 0 || end < start) throw new Error("模型没有返回记忆列表");
	const parsed = JSON.parse(result.content.slice(start, end + 1));
	if (!Array.isArray(parsed)) throw new Error("记忆格式不对");
	const facts = parsed.filter((item) => typeof item === "string" && item.trim().length > 0).slice(0, 3);
	for (const fact of facts) useJingyun.getState().addMemory(personaId, fact.trim());
	return facts.length;
}
async function testProvider(provider) {
	const model = provider.kind === "builtin" ? "grok-4.5" : provider.models[0];
	if (!model) throw new Error("先写一个模型名");
	return (await completeChat({
		...providerRequest(provider, model),
		maxTokens: 32,
		messages: [{
			role: "system",
			content: "只回复一个字：好"
		}, {
			role: "user",
			content: "在吗"
		}]
	})).content.trim() || "（空回复）";
}
var TEXT_EXT = /* @__PURE__ */ new Set([
	"txt",
	"md",
	"markdown",
	"csv",
	"json",
	"log"
]);
function ext(name) {
	const i = name.lastIndexOf(".");
	return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}
async function compressImage(file) {
	const url = URL.createObjectURL(file);
	try {
		const image = await new Promise((resolve, reject) => {
			const el = new Image();
			el.onload = () => resolve(el);
			el.onerror = () => reject(/* @__PURE__ */ new Error("图片无法读取"));
			el.src = url;
		});
		const scale = Math.min(1, 1280 / Math.max(image.width, image.height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(image.width * scale));
		canvas.height = Math.max(1, Math.round(image.height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("无法处理图片");
		ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
		return canvas.toDataURL("image/jpeg", .72);
	} finally {
		URL.revokeObjectURL(url);
	}
}
async function pdfText(buf) {
	const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
	const worker = await import("./pdf.worker.min-BDqvoJpD.mjs");
	pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
	const doc = await pdfjs.getDocument({ data: new Uint8Array(buf) }).promise;
	const pages = [];
	const count = Math.min(doc.numPages, 30);
	for (let i = 1; i <= count; i++) {
		const line = (await (await doc.getPage(i)).getTextContent()).items.map((item) => "str" in item ? item.str : "").join(" ").replace(/\s+/g, " ").trim();
		if (line) pages.push(line);
	}
	return pages.join("\n\n");
}
async function docxText(buf) {
	const mod = await import("../_libs/mammoth+xmlbuilder.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	return (await (mod.default ?? mod).extractRawText({ arrayBuffer: buf })).value || "";
}
async function fileToAttachment(file) {
	if (file.size > 15728640) throw new Error(`${file.name} 超过 15MB`);
	const id = crypto.randomUUID();
	const kind = file.type.startsWith("image/") ? "image" : "text";
	if (kind === "image") return {
		id,
		name: file.name,
		kind,
		dataUrl: await compressImage(file)
	};
	const extension = ext(file.name);
	if (extension === "doc") throw new Error("旧版 .doc 不能直接读，请另存为 .docx");
	let text = "";
	if (extension === "pdf") text = await pdfText(await file.arrayBuffer());
	else if (extension === "docx") text = await docxText(await file.arrayBuffer());
	else if (TEXT_EXT.has(extension) || file.type.startsWith("text/")) text = await file.text();
	else throw new Error(`还不支持 ${file.name}。可用 TXT、Markdown、PDF、DOCX 和常见图片。`);
	text = text.replace(/\u0000/g, "").trim();
	if (!text) throw new Error(`${file.name} 里没有读出文字`);
	if (text.length > 2e4) text = `${text.slice(0, 2e4)}\n\n[已截断，只保留前 20000 字]`;
	return {
		id,
		name: file.name,
		kind: "text",
		text
	};
}
function ctor() {
	if (typeof window === "undefined") return null;
	const w = window;
	return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}
function speechInputAvailable() {
	return Boolean(ctor());
}
function startDictation(handlers) {
	const Ctor = ctor();
	if (!Ctor) {
		handlers.onError("这台设备的浏览器没有语音识别");
		handlers.onEnd();
		return { stop() {} };
	}
	const rec = new Ctor();
	rec.lang = "zh-CN";
	rec.interimResults = true;
	rec.continuous = false;
	rec.onresult = (ev) => {
		let text = "";
		let final = false;
		for (let i = ev.resultIndex; i < ev.results.length; i++) {
			text += ev.results[i][0]?.transcript ?? "";
			if (ev.results[i].isFinal) final = true;
		}
		handlers.onText(text, final);
	};
	rec.onerror = (ev) => {
		handlers.onError({
			"not-allowed": "没有麦克风权限",
			"no-speech": "没有听到声音",
			network: "语音识别需要网络，这次失败了",
			aborted: "已停止"
		}[ev.error] || `语音识别失败：${ev.error}`);
	};
	rec.onend = () => handlers.onEnd();
	rec.start();
	return { stop: () => rec.stop() };
}
var cloudAudio = null;
var cloudUrl = "";
function localVoices() {
	if (typeof speechSynthesis === "undefined") return [];
	return speechSynthesis.getVoices();
}
function stopSpeech() {
	if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
	if (cloudAudio) {
		cloudAudio.pause();
		cloudAudio.src = "";
		cloudAudio = null;
	}
	if (cloudUrl) {
		URL.revokeObjectURL(cloudUrl);
		cloudUrl = "";
	}
}
function pauseSpeech() {
	if (cloudAudio && !cloudAudio.paused) {
		cloudAudio.pause();
		return;
	}
	if (typeof speechSynthesis !== "undefined" && speechSynthesis.speaking) speechSynthesis.pause();
}
function resumeSpeech() {
	if (cloudAudio && cloudAudio.paused && cloudAudio.src) {
		cloudAudio.play();
		return;
	}
	if (typeof speechSynthesis !== "undefined") speechSynthesis.resume();
}
function speakLocal(text, voice, onEnd) {
	if (typeof speechSynthesis === "undefined") {
		onEnd();
		throw new Error("这台设备不能本机朗读");
	}
	speechSynthesis.cancel();
	const utter = new SpeechSynthesisUtterance(text.slice(0, 4e3));
	utter.lang = "zh-CN";
	utter.rate = voice.rate;
	utter.pitch = voice.pitch;
	const match = speechSynthesis.getVoices().find((item) => item.voiceURI === voice.voiceURI);
	if (match) utter.voice = match;
	utter.onend = onEnd;
	utter.onerror = onEnd;
	speechSynthesis.speak(utter);
}
async function speakCloud(text, onEnd) {
	stopSpeech();
	const res = await fetch(apiUrl("/api/ai/tts"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			text: text.slice(0, 400),
			voice: "eve"
		})
	});
	if (!res.ok) {
		const json = await res.json().catch(() => ({}));
		throw new Error(json.error || "语音合成失败");
	}
	const blob = await res.blob();
	cloudUrl = URL.createObjectURL(blob);
	cloudAudio = new Audio(cloudUrl);
	cloudAudio.onended = () => {
		onEnd();
		stopSpeech();
	};
	await cloudAudio.play();
}
var MODES = [
	{
		id: null,
		label: "对话"
	},
	{
		id: "write",
		label: "写作"
	},
	{
		id: "code",
		label: "编程"
	},
	{
		id: "translate",
		label: "翻译"
	}
];
function ChatView() {
	const sessions = useJingyun((s) => s.sessions);
	const activeSessionId = useJingyun((s) => s.activeSessionId);
	const personas = useJingyun((s) => s.personas);
	const providers = useJingyun((s) => s.providers);
	const compare = useJingyun((s) => s.compare);
	const compareProviderId = useJingyun((s) => s.compareProviderId);
	const compareModel = useJingyun((s) => s.compareModel);
	const toolsArmed = useJingyun((s) => s.toolsArmed);
	const generating = useJingyun((s) => s.generating);
	const speaking = useJingyun((s) => s.speaking);
	const builtinReady = useJingyun((s) => s.builtinReady);
	const pendingTool = useJingyun((s) => s.pendingTool);
	const session = sessions.find((item) => item.id === activeSessionId) ?? sessions[0];
	const [text, setText] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)(null);
	const [attachments, setAttachments] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const scroller = (0, import_react.useRef)(null);
	const stick = (0, import_react.useRef)(true);
	const dictation = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const imageRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!stick.current) return;
		const el = scroller.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [
		session?.messages,
		generating,
		session?.id
	]);
	async function addFiles(list, imagesOnly = false) {
		if (!list?.length) return;
		setError("");
		const next = [];
		for (const file of Array.from(list)) {
			if (imagesOnly && !file.type.startsWith("image/")) continue;
			try {
				next.push(await fileToAttachment(file));
			} catch (err) {
				setError(err instanceof Error ? err.message : "文件读取失败");
			}
		}
		setAttachments((curr) => [...curr, ...next].slice(0, 4));
	}
	async function send() {
		if (!session) return;
		setError("");
		const payload = text;
		const files = attachments;
		setText("");
		setAttachments([]);
		try {
			await sendInSession({
				sessionId: session.id,
				text: payload,
				attachments: files,
				mode,
				compare
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "发送失败");
		}
	}
	function toggleMic() {
		if (listening) {
			dictation.current?.stop();
			return;
		}
		if (!speechInputAvailable()) {
			setError("这个浏览器没有语音输入。手机 Chrome 通常可用，部分内置浏览器不支持。");
			return;
		}
		setListening(true);
		dictation.current = startDictation({
			onText: (said, final) => {
				setText((curr) => final ? `${curr}${said}` : curr);
				if (!final) setNote(said);
				else setNote("");
			},
			onError: (message) => setError(message),
			onEnd: () => setListening(false)
		});
	}
	function readMessage(content, cloud) {
		setError("");
		useJingyun.getState().setSpeaking(true);
		const done = () => useJingyun.getState().setSpeaking(false);
		if (cloud) {
			speakCloud(content, done).catch((err) => {
				done();
				setError(err instanceof Error ? err.message : "朗读失败");
			});
			return;
		}
		try {
			speakLocal(content, useJingyun.getState().voice, done);
		} catch (err) {
			done();
			setError(err instanceof Error ? err.message : "朗读失败");
		}
	}
	if (!session) return null;
	const persona = personas.find((item) => item.id === session.personaId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 overflow-x-auto px-3 py-2",
				children: [sessions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": item.id === session.id,
					onClick: () => useJingyun.getState().selectSession(item.id),
					children: [item.origin?.type === "qq" ? "QQ · " : "", item.title]
				}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip",
					onClick: () => useJingyun.getState().newSession(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "mr-1 inline size-4",
						"aria-hidden": "true"
					}), "新对话"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-3 pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "persona-select",
						children: "当前人设"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "persona-select",
						className: "field max-w-48",
						value: session.personaId,
						onChange: (ev) => useJingyun.getState().setSessionPersona(session.id, ev.target.value),
						children: personas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.name
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-sm text-muted",
						children: persona?.model
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ml-auto text-sm text-muted underline-offset-2 hover:underline",
						onClick: () => useJingyun.getState().clearSession(session.id),
						children: "清空"
					})
				]
			}),
			builtinReady === false && persona?.providerId === "builtin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-3 mb-2 rounded-sm border border-line px-3 py-2 text-sm text-muted",
				children: "内置 Grok 当前不可用。到设置里添加你自己的接口地址和密钥。"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-3",
				onScroll: (ev) => {
					const el = ev.currentTarget;
					stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
				},
				children: [session.messages.filter((message) => message.role !== "tool").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-8 text-center text-sm text-muted",
					children: "这则对话还是空的。写一句，或附上图片和文件。"
				}) : null, session.messages.map((message) => {
					if (message.role === "tool") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-sm border border-line px-3 py-2 text-sm text-muted",
						children: [
							"工具 ",
							message.toolName,
							"：",
							message.content.slice(0, 280)
						]
					}, message.id);
					const mine = message.role === "user";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cx("max-w-[92%] rounded-lg px-3 py-2", mine ? "ml-auto bg-accent text-accent-fg" : "bg-elev border border-line"),
						children: [
							message.compareKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-1 text-xs opacity-70",
								children: [
									"模型 ",
									message.compareKey === "a" ? "A" : "B",
									" · ",
									message.model
								]
							}) : null,
							message.content ? mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "whitespace-pre-wrap break-words",
								children: message.content
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: message.content }) : null,
							message.pending && !message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "正在写…"
							}) : null,
							message.attachments?.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs opacity-80",
								children: [
									file.kind === "image" ? "图片" : "文件",
									" · ",
									file.name,
									file.dataUrl && file.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: file.dataUrl,
										alt: file.name,
										className: "mt-2 max-h-40 rounded-sm"
									}) : null
								]
							}, file.id)),
							message.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-danger",
								children: message.error
							}) : null,
							!mine && message.content && !message.pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "text-sm text-muted",
										onClick: () => void navigator.clipboard.writeText(message.content),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
											className: "mr-1 inline size-3.5",
											"aria-hidden": "true"
										}), "复制"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "text-sm text-muted",
										onClick: () => readMessage(message.content, false),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
											className: "mr-1 inline size-3.5",
											"aria-hidden": "true"
										}), "朗读"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-sm text-muted",
										onClick: () => readMessage(message.content, true),
										children: "Grok 语音"
									})
								]
							}) : null
						]
					}, message.id);
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 pb-1 text-sm text-danger",
				children: error
			}) : null,
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-3 pb-1 text-sm text-muted",
				children: ["听到：", note]
			}) : null,
			pendingTool ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mb-2 rounded-lg border border-line bg-elev p-3",
				role: "dialog",
				"aria-label": "工具权限",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"允许 ",
							pendingTool.serverName,
							" 调用 ",
							pendingTool.tool,
							"？"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-2 max-h-24 overflow-auto font-mono text-xs text-muted",
						children: pendingTool.args
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => decideTool(true),
							children: "允许这一次"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => decideTool(false),
							children: "拒绝"
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex gap-2 overflow-x-auto",
						children: [
							MODES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								"aria-pressed": mode === item.id,
								onClick: () => setMode(item.id),
								children: item.label
							}, item.label)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								"aria-pressed": compare,
								onClick: () => useJingyun.getState().setCompare(!compare),
								children: "对比"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								"aria-pressed": toolsArmed,
								onClick: () => useJingyun.getState().setToolsArmed(!toolsArmed),
								children: "工具"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "chip",
								onClick: () => {
									extractMemories(session.personaId, session.id).then((count) => setNote(count ? `已写入 ${count} 条记忆` : "这轮没有值得长期记住的内容")).catch((err) => setError(err instanceof Error ? err.message : "提取失败"));
								},
								children: "记入记忆"
							})
						]
					}),
					compare ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: compareProviderId,
							onChange: (ev) => {
								const provider = providers.find((item) => item.id === ev.target.value);
								useJingyun.getState().setCompareTarget(ev.target.value, provider?.models[0] || "");
							},
							children: providers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: compareModel,
							onChange: (ev) => useJingyun.getState().setCompareTarget(compareProviderId, ev.target.value),
							children: (providers.find((item) => item.id === useJingyun.getState().compareProviderId)?.models ?? []).map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: model,
								children: model
							}, model))
						})]
					}) : null,
					attachments.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 flex flex-wrap gap-2",
						children: attachments.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "chip",
							onClick: () => setAttachments((curr) => curr.filter((item) => item.id !== file.id)),
							children: [file.name, " · 移除"]
						}, file.id))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								hidden: true,
								accept: ".txt,.md,.markdown,.pdf,.docx,.csv,.json,.log,text/plain",
								onChange: (ev) => void addFiles(ev.target.files)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: imageRef,
								type: "file",
								hidden: true,
								accept: "image/*",
								onChange: (ev) => void addFiles(ev.target.files, true)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost size-11 px-0",
								"aria-label": "上传文件",
								onClick: () => fileRef.current?.click(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "mx-auto size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost size-11 px-0",
								"aria-label": "识图",
								onClick: () => imageRef.current?.click(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "mx-auto size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cx("btn btn-ghost size-11 px-0", listening && "border-focus"),
								"aria-label": "语音输入",
								onClick: toggleMic,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "mx-auto size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field min-h-11 flex-1 py-2",
								rows: 2,
								placeholder: "写给鲸云",
								value: text,
								onChange: (ev) => setText(ev.target.value),
								onKeyDown: (ev) => {
									if (ev.key === "Enter" && !ev.shiftKey && !ev.nativeEvent.isComposing) {
										ev.preventDefault();
										send();
									}
								}
							}),
							generating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-primary size-11 px-0",
								"aria-label": "停止生成",
								onClick: () => stopGeneration(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "mx-auto size-4" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-primary size-11 px-0",
								"aria-label": "发送",
								onClick: () => void send(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "mx-auto size-4" })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex gap-2",
						children: speaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => pauseSpeech(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "mr-1 inline size-4" }), "暂停"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => resumeSpeech(),
								children: "继续"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => {
									stopSpeech();
									useJingyun.getState().setSpeaking(false);
								},
								children: "停止朗读"
							})
						] }) : null
					})
				]
			})
		]
	});
}
var ACTIONS = [
	{
		id: "idle",
		label: "待机"
	},
	{
		id: "wave",
		label: "挥手"
	},
	{
		id: "think",
		label: "思考"
	},
	{
		id: "smile",
		label: "微笑"
	},
	{
		id: "surprise",
		label: "惊讶"
	}
];
function HoloView() {
	const canvasRef = (0, import_react.useRef)(null);
	const handleRef = (0, import_react.useRef)(null);
	const action = useJingyun((s) => s.holoAction);
	const speaking = useJingyun((s) => s.speaking);
	const generating = useJingyun((s) => s.generating);
	const follow = useJingyun((s) => s.holoFollow);
	const personaName = useJingyun((s) => s.personas.find((item) => item.id === s.activePersonaId)?.name || "鲸云");
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let dead = false;
		let handle = null;
		const onResize = () => handle?.resize();
		import("./holo-scene-DFTjn9__.mjs").then((mod) => {
			if (dead || !canvasRef.current) return;
			handle = mod.mountHolo(canvasRef.current);
			handle.setAction(useJingyun.getState().holoAction);
			handleRef.current = handle;
			window.addEventListener("resize", onResize);
		});
		return () => {
			dead = true;
			window.removeEventListener("resize", onResize);
			handle?.dispose();
			handleRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		handleRef.current?.setAction(action);
	}, [action]);
	(0, import_react.useEffect)(() => {
		handleRef.current?.setSpeaking(follow && (speaking || generating));
	}, [
		follow,
		speaking,
		generating
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "chamber relative min-h-0 flex-1 overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "h-full w-full touch-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan absolute inset-x-8 top-0 h-16" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute inset-x-0 top-4 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-wide text-muted",
						children: personaName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: "拖动旋转，双指缩放"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 overflow-x-auto px-3 py-3",
			children: [ACTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "chip",
				"aria-pressed": action === item.id,
				onClick: () => useJingyun.getState().setHoloAction(item.id),
				children: item.label
			}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				"aria-pressed": follow,
				className: "chip",
				onClick: () => useJingyun.getState().setHoloFollow(!follow),
				children: follow ? "跟随说话" : "不跟随"
			})]
		})]
	});
}
var seen = /* @__PURE__ */ new Set();
function remember(id) {
	if (!id || seen.has(id)) return false;
	seen.add(id);
	if (seen.size > 500) seen.delete(seen.values().next().value || "");
	return true;
}
function tokens(value) {
	return value.split(/[\s,，]+/).map((item) => item.trim()).filter(Boolean);
}
function allow(cfg, message) {
	if (message.selfId && message.userId === message.selfId) return false;
	const black = tokens(cfg.blacklist);
	if (black.includes(message.userId) || message.groupId && black.includes(message.groupId)) return false;
	const white = tokens(cfg.whitelist);
	if (white.length && !white.includes(message.userId) && !(message.groupId && white.includes(message.groupId))) return false;
	if (message.channel === "private") return cfg.privateReply;
	if (!cfg.groupReply) return false;
	if (cfg.atOnly && !message.atBot) return false;
	return true;
}
async function handleInbound(message) {
	const cfg = useJingyun.getState().qq;
	if (!allow(cfg, message)) return;
	if (!message.text.trim()) return;
	const peer = message.channel === "group" ? `g:${message.groupId}` : `u:${message.userId}`;
	const title = message.channel === "group" ? `QQ 群 ${message.groupId}` : `QQ ${message.userId}`;
	useJingyun.getState().pushQqLog("info", `收到${message.channel === "group" ? "群" : "私"}消息 ${message.userId}：${message.text.slice(0, 80)}`);
	try {
		const reply = await answerForBot(cfg.personaId, peer, title, message.text);
		await runtime.send(message, reply);
		useJingyun.getState().pushQqLog("info", `已回复 ${message.userId}`);
	} catch (err) {
		useJingyun.getState().pushQqLog("error", err instanceof Error ? err.message : "回复失败");
	}
}
function textOf(message, raw) {
	if (typeof message === "string") return message.replace(/\[CQ:[^\]]+\]/g, "").trim();
	if (Array.isArray(message)) return message.map((seg) => {
		if (!seg || typeof seg !== "object") return "";
		const item = seg;
		return item.type === "text" ? item.data?.text || "" : "";
	}).join("").trim();
	return raw.replace(/\[CQ:[^\]]+\]/g, "").trim();
}
function atBot(message, raw, selfId) {
	if (selfId && (raw.includes(`[CQ:at,qq=${selfId}]`) || raw.includes(`[CQ:at,qq=${selfId},`))) return true;
	if (!Array.isArray(message)) return false;
	return message.some((seg) => {
		if (!seg || typeof seg !== "object") return false;
		const item = seg;
		return item.type === "at" && String(item.data?.qq ?? "") === selfId;
	});
}
var OneBotAdapter = class {
	ws = null;
	desired = false;
	delay = 2e3;
	timer = 0;
	selfId = "";
	start(cfg, hooks) {
		this.stopSocket();
		this.desired = true;
		this.delay = 2e3;
		if (!cfg.wsUrl.trim()) {
			hooks.onStatus({
				state: "error",
				detail: "先填写 OneBot WebSocket 地址"
			});
			this.desired = false;
			return;
		}
		let url;
		try {
			url = new URL(cfg.wsUrl.trim());
		} catch {
			hooks.onStatus({
				state: "error",
				detail: "WebSocket 地址不合法"
			});
			this.desired = false;
			return;
		}
		if (url.protocol !== "ws:" && url.protocol !== "wss:") {
			hooks.onStatus({
				state: "error",
				detail: "地址需要以 ws:// 或 wss:// 开头"
			});
			this.desired = false;
			return;
		}
		if (location.protocol === "https:" && url.protocol === "ws:") {
			hooks.onStatus({
				state: "error",
				detail: "当前是 https 页面，浏览器会拦截 ws://。请改用 wss://。"
			});
			this.desired = false;
			return;
		}
		if (cfg.accessToken && !url.searchParams.has("access_token")) url.searchParams.set("access_token", cfg.accessToken);
		this.open(url.toString(), hooks);
	}
	stop() {
		this.desired = false;
		this.stopSocket();
		useJingyun.getState().setQqStatus({
			state: "stopped",
			detail: "已停止"
		});
	}
	stopSocket() {
		window.clearTimeout(this.timer);
		this.ws?.close();
		this.ws = null;
	}
	open(url, hooks) {
		hooks.onStatus({
			state: "connecting",
			detail: "正在连接 OneBot…"
		});
		let ws;
		try {
			ws = new WebSocket(url);
		} catch (err) {
			hooks.onStatus({
				state: "error",
				detail: err instanceof Error ? err.message : "无法创建连接"
			});
			return;
		}
		this.ws = ws;
		ws.onopen = () => {
			this.delay = 2e3;
			hooks.onStatus({
				state: "online",
				detail: "已连接，等待登录信息"
			});
			hooks.onLog("info", "OneBot 已连接");
			ws.send(JSON.stringify({
				action: "get_login_info",
				params: {},
				echo: "login"
			}));
		};
		ws.onmessage = (ev) => {
			this.onFrame(String(ev.data), hooks);
		};
		ws.onerror = () => hooks.onLog("error", "WebSocket 出错");
		ws.onclose = () => {
			if (!this.desired) return;
			hooks.onStatus({
				state: "error",
				detail: `${Math.round(this.delay / 1e3)} 秒后重连`
			});
			this.timer = window.setTimeout(() => {
				if (this.desired) this.open(url, hooks);
			}, this.delay);
			this.delay = Math.min(this.delay * 2, 3e4);
		};
	}
	onFrame(raw, hooks) {
		let frame;
		try {
			frame = JSON.parse(raw);
		} catch {
			return;
		}
		if (frame.echo === "login" || frame.echo === "send") {
			const data = frame.data;
			if (frame.echo === "login" && data?.user_id) {
				this.selfId = String(data.user_id);
				hooks.onStatus({
					state: "online",
					detail: data.nickname ? `${data.nickname}（${this.selfId}）` : `QQ ${this.selfId}`,
					selfId: this.selfId,
					nickname: data.nickname
				});
			}
			if (frame.echo === "send" && frame.status && frame.status !== "ok" && frame.retcode && frame.retcode !== 0) hooks.onLog("error", `发送失败：${JSON.stringify(frame).slice(0, 180)}`);
			return;
		}
		if (frame.post_type === "meta_event") return;
		if (frame.post_type !== "message") return;
		const selfId = String(frame.self_id ?? this.selfId ?? "");
		if (selfId) this.selfId = selfId;
		const messageType = frame.message_type === "group" ? "group" : "private";
		const id = String(frame.message_id ?? "");
		if (!remember(id)) return;
		const message = {
			id,
			channel: messageType,
			userId: String(frame.user_id ?? ""),
			groupId: frame.group_id ? String(frame.group_id) : void 0,
			text: textOf(frame.message, String(frame.raw_message ?? "")),
			atBot: atBot(frame.message, String(frame.raw_message ?? ""), selfId),
			selfId
		};
		hooks.onMessage(message);
	}
	send(message, text) {
		if (!this.ws || this.ws.readyState !== WebSocket.OPEN) throw new Error("OneBot 不在线，回复没有发出");
		const action = message.channel === "group" ? "send_group_msg" : "send_private_msg";
		const params = message.channel === "group" ? {
			group_id: Number(message.groupId),
			message: text
		} : {
			user_id: Number(message.userId),
			message: text
		};
		this.ws.send(JSON.stringify({
			action,
			params,
			echo: "send"
		}));
	}
};
var HttpAdapter = class {
	desired = false;
	timer = 0;
	start(cfg, hooks) {
		this.stop();
		if (!cfg.pollUrl || !cfg.sendUrl) {
			hooks.onStatus({
				state: "error",
				detail: "请填写事件轮询地址和发送地址"
			});
			return;
		}
		this.desired = true;
		hooks.onStatus({
			state: "online",
			detail: "正在轮询 HTTP 事件"
		});
		hooks.onLog("info", "HTTP 适配器已启动");
		const tick = async () => {
			if (!this.desired) return;
			try {
				const res = await fetch(cfg.pollUrl, { headers: headerMap(cfg.httpHeaderText) });
				if (!res.ok) throw new Error(`轮询返回 ${res.status}`);
				const json = await res.json();
				for (const event of json.events ?? []) {
					if (!event?.id || !remember(String(event.id))) continue;
					hooks.onMessage({
						id: String(event.id),
						channel: event.channel === "group" ? "group" : "private",
						userId: String(event.userId ?? ""),
						groupId: event.groupId ? String(event.groupId) : void 0,
						text: String(event.text ?? ""),
						atBot: Boolean(event.atBot)
					});
				}
			} catch (err) {
				hooks.onStatus({
					state: "error",
					detail: err instanceof Error ? err.message : "轮询失败"
				});
				hooks.onLog("error", err instanceof Error ? err.message : "轮询失败");
			}
			if (this.desired) this.timer = window.setTimeout(() => void tick(), 3e3);
		};
		tick();
	}
	stop() {
		this.desired = false;
		window.clearTimeout(this.timer);
		useJingyun.getState().setQqStatus({
			state: "stopped",
			detail: "已停止"
		});
	}
	async send(cfg, message, text) {
		const res = await fetch(cfg.sendUrl, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...headerMap(cfg.httpHeaderText)
			},
			body: JSON.stringify({
				channel: message.channel,
				userId: message.userId,
				groupId: message.groupId,
				text
			})
		});
		if (!res.ok) throw new Error(`发送接口返回 ${res.status}`);
	}
};
function headerMap(text) {
	const headers = {};
	for (const line of text.split(/\r?\n/)) {
		const i = line.indexOf(":");
		if (i > 0) headers[line.slice(0, i).trim()] = line.slice(i + 1).trim();
	}
	return headers;
}
var onebot = new OneBotAdapter();
var http = new HttpAdapter();
var runtime = { async send(message, text) {
	const cfg = useJingyun.getState().qq;
	if (cfg.adapter === "http") await http.send(cfg, message, text);
	else onebot.send(message, text);
} };
function hooks() {
	return {
		onStatus: (status) => useJingyun.getState().setQqStatus(status),
		onLog: (level, message) => useJingyun.getState().pushQqLog(level, message),
		onMessage: (message) => void handleInbound(message)
	};
}
function startBot() {
	const cfg = useJingyun.getState().qq;
	stopBot(false);
	if (cfg.adapter === "http") http.start(cfg, hooks());
	else onebot.start(cfg, hooks());
}
function stopBot(log = true) {
	onebot.stop();
	http.stop();
	if (log) useJingyun.getState().pushQqLog("info", "桥接已停止");
}
function restartBot() {
	useJingyun.getState().pushQqLog("info", "正在重启");
	startBot();
}
var TABS = [
	{
		id: "search",
		label: "搜索"
	},
	{
		id: "image",
		label: "绘图"
	},
	{
		id: "files",
		label: "文件"
	},
	{
		id: "mcp",
		label: "MCP"
	},
	{
		id: "qq",
		label: "QQ"
	}
];
function LabView() {
	const tab = useJingyun((s) => s.labTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto px-3 py-2",
			children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "chip",
				"aria-pressed": tab === item.id,
				onClick: () => useJingyun.getState().setLabTab(item.id),
				children: item.label
			}, item.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scroll-thin min-h-0 flex-1 overflow-y-auto px-3 pb-4",
			children: [
				tab === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchPane, {}) : null,
				tab === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePane, {}) : null,
				tab === "files" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePane, {}) : null,
				tab === "mcp" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(McpPane, {}) : null,
				tab === "qq" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QqPane, {}) : null
			]
		})]
	});
}
function SearchPane() {
	const search = useJingyun((s) => s.search);
	const [query, setQuery] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		setBusy(true);
		setError("");
		try {
			const res = await fetch(apiUrl("/api/search"), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					provider: search.provider,
					query,
					apiKey: search.apiKey,
					endpoint: search.endpoint
				})
			});
			const json = await res.json();
			if (!res.ok || json.error) throw new Error(json.error || "搜索失败");
			setHits(json.results ?? []);
			if (!json.results?.length) setError("没有结果。可以换关键词，或改用带密钥的搜索服务。");
		} catch (err) {
			setError(err instanceof Error ? err.message : "搜索失败");
		} finally {
			setBusy(false);
		}
	}
	async function summarize() {
		if (!hits.length) return;
		const state = useJingyun.getState();
		const block = hits.map((hit, i) => `${i + 1}. ${hit.title}\n${hit.url}\n${hit.snippet}`).join("\n\n");
		await sendInSession({
			sessionId: state.activeSessionId,
			text: `请根据这些搜索结果回答「${query}」。给出结论，并保留来源链接。\n\n${block}`
		});
		state.setView("chat");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "搜索服务" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field mb-3",
					value: search.provider,
					onChange: (ev) => useJingyun.getState().setSearch({ provider: ev.target.value }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "wiki",
							children: "维基百科（免密钥）"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "tavily",
							children: "Tavily"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "brave",
							children: "Brave"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "serper",
							children: "Serper"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "custom",
							children: "自定义 JSON 接口"
						})
					]
				}),
				search.provider !== "wiki" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "API Key" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					type: "password",
					value: search.apiKey,
					onChange: (ev) => useJingyun.getState().setSearch({ apiKey: ev.target.value })
				})] }) : null,
				search.provider === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "接口地址" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mb-3",
						placeholder: "https://example.com/search",
						value: search.endpoint,
						onChange: (ev) => useJingyun.getState().setSearch({ endpoint: ev.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 text-sm text-muted",
						children: [
							"需要返回 ",
							"{ results: [{ title, url, snippet }] }",
							"。地址必须是公网。"
						]
					})
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "搜索词" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: query,
						onChange: (ev) => setQuery(ev.target.value),
						onKeyDown: (ev) => {
							if (ev.key === "Enter") run();
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						disabled: busy,
						onClick: () => void run(),
						children: busy ? "搜索中" : "搜索"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: error
				}) : null
			] }),
			hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: hit.url,
					target: "_blank",
					rel: "noreferrer",
					className: "font-medium underline-offset-2 hover:underline",
					children: hit.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: hit.snippet
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: hit.source
				})
			] }, hit.url)),
			hits.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => void summarize(),
				children: "交给当前人设总结"
			}) : null
		]
	});
}
function ImagePane() {
	const personas = useJingyun((s) => s.personas);
	const activePersonaId = useJingyun((s) => s.activePersonaId);
	const persona = personas.find((item) => item.id === activePersonaId) ?? personas[0];
	const provider = persona ? providerById(persona.providerId) : void 0;
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [images, setImages] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		if (!provider) return;
		setBusy(true);
		setError("");
		try {
			const res = await fetch(apiUrl("/api/ai/image"), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					mode: provider.kind === "builtin" ? "builtin" : "proxy",
					baseUrl: provider.baseUrl,
					apiKey: provider.apiKey,
					model: provider.imageModel,
					prompt
				})
			});
			const json = await res.json();
			if (!res.ok || json.error) throw new Error(json.error || "绘图失败");
			setImages(json.images ?? []);
		} catch (err) {
			setError(err instanceof Error ? err.message : "绘图失败");
		} finally {
			setBusy(false);
		}
	}
	async function sendImage(image) {
		const dataUrl = image.url || (image.b64 ? `data:image/png;base64,${image.b64}` : "");
		if (!dataUrl) return;
		const attachment = {
			id: crypto.randomUUID(),
			name: "生成的图片",
			kind: "image",
			dataUrl
		};
		const state = useJingyun.getState();
		await sendInSession({
			sessionId: state.activeSessionId,
			text: "请看看这张图。",
			attachments: [attachment]
		});
		state.setView("chat");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: "使用当前人设的服务商。内置走 Grok 绘图；自己的接口走 OpenAI 兼容的 images 接口，模型名在设置里填。"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "field mb-3",
			placeholder: "想生成的画面",
			value: prompt,
			onChange: (ev) => setPrompt(ev.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "primary",
			disabled: busy || !prompt.trim(),
			onClick: () => void run(),
			children: busy ? "生成中" : "生成图片"
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-3",
			children: images.map((image, index) => {
				const src = image.url || (image.b64 ? `data:image/png;base64,${image.b64}` : "");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: "生成结果",
					className: "max-h-80 rounded-lg"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex gap-2",
					children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "btn btn-ghost",
						href: src,
						download: `jingyun-${index + 1}.png`,
						children: "下载"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void sendImage(image),
						children: "发给对话分析"
					})]
				})] }, index);
			})
		})
	] });
}
function FilePane() {
	const [file, setFile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: "支持 PDF、DOCX、TXT、Markdown。旧版二进制 DOC 请先另存为 DOCX。文件在这台设备上解析，不会单独上传保存。"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field mb-3",
			type: "file",
			accept: ".pdf,.docx,.txt,.md,.markdown",
			onChange: (ev) => {
				const picked = ev.target.files?.[0];
				if (!picked) return;
				fileToAttachment(picked).then(setFile).catch((err) => {
					setFile(null);
					setError(err instanceof Error ? err.message : "读取失败");
				});
			}
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-sm text-danger",
			children: error
		}) : null,
		file?.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mb-3 max-h-48 overflow-auto whitespace-pre-wrap rounded-sm bg-bg p-3 text-sm",
			children: file.text.slice(0, 1500)
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "primary",
			disabled: !file,
			onClick: () => {
				if (!file) return;
				const state = useJingyun.getState();
				sendInSession({
					sessionId: state.activeSessionId,
					text: `请总结并分析文件「${file.name}」。`,
					attachments: [file]
				}).then(() => state.setView("chat"));
			},
			children: "让当前人设分析"
		})
	] });
}
function McpPane() {
	const servers = useJingyun((s) => s.mcpServers);
	const logs = useJingyun((s) => s.toolLogs);
	const [draft, setDraft] = (0, import_react.useState)({
		name: "",
		url: "",
		headerText: ""
	});
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	function add() {
		if (!draft.url.trim()) {
			setError("先填写 MCP 地址");
			return;
		}
		const server = {
			id: crypto.randomUUID(),
			name: draft.name.trim() || "MCP",
			url: draft.url.trim(),
			headerText: draft.headerText,
			enabled: true,
			tools: [],
			toolPermission: {}
		};
		useJingyun.getState().upsertMcp(server);
		setDraft({
			name: "",
			url: "",
			headerText: ""
		});
	}
	async function discover(server) {
		setBusy(server.id);
		setError("");
		try {
			const tools = await discoverTools(server);
			const toolPermission = { ...server.toolPermission };
			for (const tool of tools) if (!toolPermission[tool.name]) toolPermission[tool.name] = "ask";
			useJingyun.getState().upsertMcp({
				...server,
				tools,
				toolPermission
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "发现工具失败");
		} finally {
			setBusy("");
		}
	}
	function setPerm(server, tool, permission) {
		useJingyun.getState().upsertMcp({
			...server,
			toolPermission: {
				...server.toolPermission,
				[tool]: permission
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "连接公网 HTTP MCP。本地 stdio 服务这里到不了。发现工具后，回对话打开「工具」，模型才能调用。默认每次询问。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "名称" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					value: draft.name,
					onChange: (ev) => setDraft({
						...draft,
						name: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "地址" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					placeholder: "https://example.com/mcp",
					value: draft.url,
					onChange: (ev) => setDraft({
						...draft,
						url: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "请求头，一行一个" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "field mb-3",
					placeholder: "Authorization: Bearer ...",
					value: draft.headerText,
					onChange: (ev) => setDraft({
						...draft,
						headerText: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: add,
					children: "添加服务"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: error
				}) : null
			] }),
			servers.map((server) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: server.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-danger",
						onClick: () => useJingyun.getState().removeMcp(server.id),
						children: "删除"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 break-all text-sm text-muted",
					children: server.url
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mb-2 flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: server.enabled,
						onChange: (ev) => useJingyun.getState().upsertMcp({
							...server,
							enabled: ev.target.checked
						})
					}), "启用"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy === server.id,
					onClick: () => void discover(server),
					children: busy === server.id ? "发现中" : "发现工具"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: server.tools.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tool.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field w-28",
							value: server.toolPermission[tool.name] || "ask",
							onChange: (ev) => setPerm(server, tool.name, ev.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ask",
									children: "询问"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "allow",
									children: "允许"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "deny",
									children: "拒绝"
								})
							]
						})]
					}, tool.name))
				})
			] }, server.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 font-medium",
					children: "执行记录"
				}),
				logs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "还没有调用。"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: [...logs].reverse().slice(0, 20).map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: log.ok ? "text-ok" : "text-danger",
								children: log.ok ? "成功" : "失败"
							}),
							" ",
							log.server,
							" / ",
							log.tool,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: log.result.slice(0, 180)
							})
						]
					}, log.id))
				})
			] })
		]
	});
}
function QqPane() {
	const qq = useJingyun((s) => s.qq);
	const status = useJingyun((s) => s.qqStatus);
	const logs = useJingyun((s) => s.qqLogs);
	const personas = useJingyun((s) => s.personas);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["状态：", status.detail]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-subtle",
					children: "适配器可替换。刷新或离开页面会断开，网页不能在后台常驻。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "适配器" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field mb-3",
					value: qq.adapter,
					onChange: (ev) => useJingyun.getState().setQq({ adapter: ev.target.value }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "onebot11",
						children: "OneBot 11 正向 WebSocket"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "http",
						children: "HTTP 事件适配器"
					})]
				}),
				qq.adapter === "onebot11" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "WebSocket 地址" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mb-3",
						placeholder: "wss://your-napcat.example/onebot",
						value: qq.wsUrl,
						onChange: (ev) => useJingyun.getState().setQq({ wsUrl: ev.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Access Token" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mb-3",
						type: "password",
						value: qq.accessToken,
						onChange: (ev) => useJingyun.getState().setQq({ accessToken: ev.target.value })
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "事件轮询地址" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mb-3",
						placeholder: "https://example.com/events",
						value: qq.pollUrl,
						onChange: (ev) => useJingyun.getState().setQq({ pollUrl: ev.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "发送地址" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mb-3",
						placeholder: "https://example.com/send",
						value: qq.sendUrl,
						onChange: (ev) => useJingyun.getState().setQq({ sendUrl: ev.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "请求头" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "field mb-3",
						value: qq.httpHeaderText,
						onChange: (ev) => useJingyun.getState().setQq({ httpHeaderText: ev.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 text-sm text-muted",
						children: [
							"轮询应返回 ",
							"{ events: [{ id, channel, userId, groupId, text, atBot }] }",
							"。发送使用 POST，正文含 channel、userId、groupId、text。DSH 本身没有这个固定接口，不能假装已经接上。"
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "回复用人设" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field mb-3",
					value: qq.personaId,
					onChange: (ev) => useJingyun.getState().setQq({ personaId: ev.target.value }),
					children: personas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: qq.privateReply,
								onChange: (ev) => useJingyun.getState().setQq({ privateReply: ev.target.checked })
							}), "私聊自动回复"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: qq.groupReply,
								onChange: (ev) => useJingyun.getState().setQq({ groupReply: ev.target.checked })
							}), "群聊自动回复"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: qq.atOnly,
								onChange: (ev) => useJingyun.getState().setQq({ atOnly: ev.target.checked })
							}), "群聊只在 @ 机器人时回复"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "白名单，QQ 号或群号，空则不限制" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					value: qq.whitelist,
					onChange: (ev) => useJingyun.getState().setQq({ whitelist: ev.target.value })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "黑名单" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					value: qq.blacklist,
					onChange: (ev) => useJingyun.getState().setQq({ blacklist: ev.target.value })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => startBot(),
							children: "启动"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => stopBot(),
							children: "停止"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => restartBot(),
							children: "重启"
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 font-medium",
				children: "做不到的部分"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "list-disc space-y-1 pl-4 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "不能在应用里安装 Termux、PRoot Ubuntu 或拉起 NapCat。" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "QQ 扫码登录发生在协议端，不在这里。" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "反向 WebSocket（让协议端连进来）网页做不了稳定服务。" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "要让回复走 DeepSeek Harness，把 DSH 的 OpenAI 兼容地址填进设置里的服务商，再选到人设上。" })
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium",
					children: "日志"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm text-muted",
					onClick: () => useJingyun.getState().clearQqLogs(),
					children: "清空"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 font-mono text-xs",
				children: [...logs].reverse().slice(0, 40).map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: log.level === "error" ? "text-danger" : "text-muted",
					children: [
						new Date(log.at).toLocaleTimeString(),
						" ",
						log.message
					]
				}, log.id))
			})] })
		]
	});
}
function PersonaView() {
	const personas = useJingyun((s) => s.personas);
	const providers = useJingyun((s) => s.providers);
	const activePersonaId = useJingyun((s) => s.activePersonaId);
	const [selected, setSelected] = (0, import_react.useState)(activePersonaId);
	const current = personas.find((item) => item.id === selected) ?? personas[0];
	const [draft, setDraft] = (0, import_react.useState)(current ?? null);
	const [memoryText, setMemoryText] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const next = useJingyun.getState().personas.find((item) => item.id === selected);
		if (next) setDraft({
			...next,
			memories: next.memories
		});
	}, [selected]);
	if (!current || !draft) return null;
	function create() {
		const id = crypto.randomUUID();
		const persona = {
			id,
			name: "新人设",
			personality: "",
			systemPrompt: "你是一个清楚、诚实的助手。",
			providerId: BUILTIN_ID,
			model: "grok-4.5",
			voiceURI: "",
			memories: []
		};
		useJingyun.getState().upsertPersona(persona);
		setSelected(id);
	}
	const provider = providers.find((item) => item.id === draft.providerId) ?? providers[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: [personas.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": item.id === current.id,
					onClick: () => setSelected(item.id),
					children: item.name
				}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: create,
					children: "新建"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "名字" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					value: draft.name,
					onChange: (ev) => setDraft({
						...draft,
						name: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "性格" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					value: draft.personality,
					onChange: (ev) => setDraft({
						...draft,
						personality: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "提示词" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "field mb-3",
					value: draft.systemPrompt,
					onChange: (ev) => setDraft({
						...draft,
						systemPrompt: ev.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "服务商" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field mb-3",
					value: draft.providerId,
					onChange: (ev) => {
						const next = providers.find((item) => item.id === ev.target.value);
						setDraft({
							...draft,
							providerId: ev.target.value,
							model: next?.models[0] || draft.model
						});
					},
					children: providers.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.id,
						children: item.name
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "模型" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field mb-3",
					value: draft.model,
					onChange: (ev) => setDraft({
						...draft,
						model: ev.target.value
					}),
					children: (provider?.models.length ? provider.models : [draft.model]).map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: model,
						children: model
					}, model))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => useJingyun.getState().upsertPersona({
							...draft,
							memories: current.memories
						}),
						children: "保存人设"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => useJingyun.getState().removePersona(current.id),
						children: "删除"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "长期记忆"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "只属于这个人设。对话里点「记入记忆」也会写到这里。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: memoryText,
						placeholder: "写一条要记住的事实",
						onChange: (ev) => setMemoryText(ev.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							if (!memoryText.trim()) return;
							useJingyun.getState().addMemory(current.id, memoryText.trim());
							setMemoryText("");
						},
						children: "添加"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2",
					children: [current.memories.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "还没有记忆。"
					}) : null, current.memories.map((memory) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-sm border border-line p-2",
						children: [editing === memory.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							defaultValue: memory.text,
							onBlur: (ev) => {
								useJingyun.getState().updateMemory(current.id, {
									...memory,
									text: ev.target.value
								});
								setEditing(null);
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: memory.text
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm text-muted",
								onClick: () => setEditing(memory.id),
								children: "编辑"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm text-danger",
								onClick: () => useJingyun.getState().removeMemory(current.id, memory.id),
								children: "删除"
							})]
						})]
					}, memory.id))]
				})
			] })
		]
	});
}
var THEMES = [
	{
		id: "tide",
		label: "潮汐"
	},
	{
		id: "day",
		label: "白昼"
	},
	{
		id: "ink",
		label: "墨"
	}
];
function SettingsView() {
	const theme = useJingyun((s) => s.theme);
	const providers = useJingyun((s) => s.providers);
	const voice = useJingyun((s) => s.voice);
	const maxTokens = useJingyun((s) => s.maxTokens);
	const [voices, setVoices] = (0, import_react.useState)([]);
	const [passphrase, setPassphrase] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [testing, setTesting] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const load = () => setVoices(localVoices());
		load();
		window.speechSynthesis?.addEventListener("voiceschanged", load);
		return () => window.speechSynthesis?.removeEventListener("voiceschanged", load);
	}, []);
	function download(filename, text) {
		const blob = new Blob([text], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = filename;
		a.click();
		URL.revokeObjectURL(url);
	}
	async function exportEncrypted() {
		if (passphrase.trim().length < 4) {
			setMessage("口令至少 4 位");
			return;
		}
		download("jingyun-backup.json", await encryptJson(useJingyun.getState().snapshot(), passphrase));
		setMessage("已导出加密备份");
	}
	function exportPlain() {
		download("jingyun-backup-plain.json", JSON.stringify({
			format: "jingyun-backup",
			v: 1,
			kdf: "none",
			state: useJingyun.getState().snapshot()
		}, null, 2));
		setMessage("已导出明文备份，里面有密钥，别外传");
	}
	async function importFile(file) {
		try {
			const text = await file.text();
			const data = JSON.parse(text).kdf === "none" ? JSON.parse(text).state : await decryptJson(text, passphrase);
			if (!data?.providers || !data.personas || !data.sessions) throw new Error("备份里没有完整数据");
			useJingyun.getState().replacePersisted(data);
			document.documentElement.dataset.theme = data.theme;
			setMessage("已恢复");
		} catch (err) {
			setMessage(err instanceof Error ? err.message : "恢复失败");
		}
	}
	function addProvider() {
		const provider = {
			id: crypto.randomUUID(),
			name: "我的接口",
			kind: "openai",
			baseUrl: "https://api.openai.com/v1",
			apiKey: "",
			models: ["gpt-4o-mini"],
			imageModel: "dall-e-3",
			transport: "proxy"
		};
		useJingyun.getState().upsertProvider(provider);
	}
	function update(provider, patch) {
		useJingyun.getState().upsertProvider({
			...provider,
			...patch
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scroll-thin min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-lg font-medium",
				children: "主题"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": theme === item.id,
					onClick: () => useJingyun.getState().setTheme(item.id),
					children: item.label
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "模型服务商"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "密钥在本机用 AES-GCM 加密后保存。内置 Grok 不需要你的密钥，但会使用应用额度，发布后任何打开的人都能消耗它。只想自己用时，改填自己的接口。"
				}),
				providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 rounded-lg border border-line p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "名称" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mb-2",
							value: provider.name,
							disabled: provider.id === BUILTIN_ID,
							onChange: (ev) => update(provider, { name: ev.target.value })
						}),
						provider.kind === "openai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "接口地址，填到 /v1" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mb-2",
								value: provider.baseUrl,
								onChange: (ev) => update(provider, { baseUrl: ev.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "API Key" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mb-2",
								type: "password",
								value: provider.apiKey,
								onChange: (ev) => update(provider, { apiKey: ev.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "连接方式" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "field mb-2",
								value: provider.transport,
								onChange: (ev) => update(provider, { transport: ev.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "proxy",
									children: "服务器代理（公网，避开跨域）"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "direct",
									children: "浏览器直连（本地或允许跨域的地址）"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "模型名，每行一个" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "field mb-2",
								value: provider.models.join("\n"),
								onChange: (ev) => update(provider, { models: ev.target.value.split(/\n+/).map((item) => item.trim()).filter(Boolean) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "绘图模型名，可空" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mb-2",
								value: provider.imageModel,
								onChange: (ev) => update(provider, { imageModel: ev.target.value })
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "对话模型 grok-4.5，绘图模型 grok-imagine-image。不能改成别的模型来花内置额度。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: testing === provider.id,
								onClick: () => {
									setTesting(provider.id);
									setMessage("");
									testProvider(provider).then((text) => setMessage(`${provider.name} 有响应：${text}`)).catch((err) => setMessage(err instanceof Error ? err.message : "测试失败")).finally(() => setTesting(""));
								},
								children: testing === provider.id ? "测试中" : "测试连接"
							}), provider.id !== "builtin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => useJingyun.getState().removeProvider(provider.id),
								children: "删除"
							}) : null]
						})
					]
				}, provider.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: addProvider,
					children: "添加服务商"
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: message
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "回复长度"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full",
					type: "range",
					min: 128,
					max: 2048,
					step: 64,
					value: maxTokens,
					onChange: (ev) => useJingyun.getState().setMaxTokens(Number(ev.target.value))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"内置模型在服务端仍限制为 800。当前设置 ",
						maxTokens,
						"。"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "本机语音"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "声音" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field mb-3",
					value: voice.voiceURI,
					onChange: (ev) => useJingyun.getState().setVoice({ voiceURI: ev.target.value }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "系统默认"
					}), voices.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: item.voiceURI,
						children: [
							item.name,
							" · ",
							item.lang
						]
					}, item.voiceURI))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["语速 ", voice.rate.toFixed(1)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mb-2 w-full",
					type: "range",
					min: .6,
					max: 1.4,
					step: .1,
					value: voice.rate,
					onChange: (ev) => useJingyun.getState().setVoice({ rate: Number(ev.target.value) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["音高 ", voice.pitch.toFixed(1)] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full",
					type: "range",
					min: .6,
					max: 1.4,
					step: .1,
					value: voice.pitch,
					onChange: (ev) => useJingyun.getState().setVoice({ pitch: Number(ev.target.value) })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "备份"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "导出或恢复用的口令" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field mb-3",
					type: "password",
					value: passphrase,
					onChange: (ev) => setPassphrase(ev.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => void exportEncrypted(),
							children: "加密导出"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: exportPlain,
							children: "明文导出"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "btn btn-ghost",
							children: ["恢复", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "sr-only",
								type: "file",
								accept: "application/json,.json",
								onChange: (ev) => {
									const file = ev.target.files?.[0];
									if (file) importFile(file);
								}
							})]
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg font-medium",
					children: "交付边界"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "你要的是包名 com.jingyun.ai 的 Kotlin + Jetpack Compose 安装包，以及 GitHub Actions 编出来的 APK。这里给出的是能直接使用的鲸云：对话流式输出、多人设和独立记忆、可旋转的 3D 角色、识图和绘图、文件分析、语音、搜索、MCP、OneBot 都是真的调用。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-2 list-disc space-y-1 pl-4 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "没有编译 APK，也没有 Android 工程。这个环境只能运行网页应用。" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "不能在手机里安装或管理 Termux / PRoot，也不能代替协议端扫码登录 QQ。" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "MCP 只支持公网 HTTP，不支持本机 stdio。" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "内置模型有长度和每小时自动回复次数限制，避免把额度打空。" })
					]
				})
			] })
		]
	});
}
var NAV = [
	{
		id: "chat",
		label: "对话",
		icon: MessageCircle
	},
	{
		id: "persona",
		label: "人设",
		icon: UserRound
	},
	{
		id: "holo",
		label: "全息",
		icon: Box
	},
	{
		id: "lab",
		label: "能力",
		icon: Layers
	},
	{
		id: "settings",
		label: "设置",
		icon: Settings
	}
];
function App() {
	const view = useJingyun((s) => s.view);
	const theme = useJingyun((s) => s.theme);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		useJingyun.persist.rehydrate();
		fetch(apiUrl("/api/ai/status")).then((res) => res.json()).then((data) => useJingyun.getState().setBuiltinReady(Boolean(data.builtin))).catch(() => useJingyun.getState().setBuiltinReady(false));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh max-w-6xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden w-52 shrink-0 flex-col border-r border-line px-3 py-4 md:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-2 px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhaleMark, { className: "size-8 text-fg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-medium leading-tight",
					children: "鲸云"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "JingYun"
				})] })]
			}), NAV.map((item) => {
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: cx("mb-1 flex min-h-11 items-center gap-2 rounded-sm px-3 text-left", view === item.id ? "bg-accent text-accent-fg" : "text-muted"),
					onClick: () => useJingyun.getState().setView(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						"aria-hidden": "true"
					}), item.label]
				}, item.id);
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-2 border-b border-line px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhaleMark, { className: "size-7 text-fg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "鲸云"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex min-h-0 flex-1 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: view === "chat" ? "flex min-h-0 flex-1 flex-col" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {})
						}),
						view === "persona" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonaView, {}) : null,
						view === "holo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoloView, {}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: view === "lab" ? "flex min-h-0 flex-1 flex-col" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabView, {})
						}),
						view === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "grid grid-cols-5 border-t border-line pb-[env(safe-area-inset-bottom)] md:hidden",
					"aria-label": "主要",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const on = view === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: cx("flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs", on ? "text-fg" : "text-subtle"),
							onClick: () => useJingyun.getState().setView(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": "true"
							}), item.label]
						}, item.id);
					})
				})
			]
		})]
	});
}
var SplitComponent = App;
//#endregion
export { SplitComponent as component };
