//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BIfuBkPB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/mcp",
			"/api/search",
			"/api/ai/chat",
			"/api/ai/image",
			"/api/ai/status",
			"/api/ai/tts"
		],
		preloads: ["/assets/index-BUzs1ktR.js", "/assets/rolldown-runtime-C0FnF6B9.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUzs1ktR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CxuscVOi.js"]
	}
} });
//#endregion
export { tsrStartManifest };
